import{b as Is,a as O,f as N,c as mi}from"../chunks/Dqx9dRzP.js";import{x as Ia,N as vl,h as cn,E as Gi,z as Yi,b as Pa,i as r,P as gl,S as ml,U as Ds,V as Da,C as Vr,aC as so,aJ as pl,au as Es,K as Fr,aP as Zn,J as Ma,aQ as bl,M as hl,ab as xl,aR as yl,aI as Qa,aS as _l,aT as wl,_ as Sl,ag as Ts,aU as Il,G as oo,I as lo,aV as Ea,aW as Dl,aG as El,H as Tl,aD as co,aX as uo,Y as fo,aY as Ol,t as H,y as Nl,aZ as kl,aK as Al,aE as Cl,w as zl,a_ as Rl,a$ as Ll,W as Pl,a as rr,X as vo,j as Ml,s as Fl,b0 as Vl,b1 as jl,b2 as Wl,b3 as go,b4 as Hl,b5 as Ul,b6 as Gl,aM as Yl,b7 as Bl,p as Jr,m as qr,v as d,o as f,q as l,av as er,$ as y,aN as fe,aO as W,b8 as Fa,f as Xt,a5 as Mt,u as pn,n as _r,b9 as jr}from"../chunks/Bva6h0g7.js";import{d as Zr,a as S,e as Zt,s as M}from"../chunks/Q8nYRNvD.js";import{i as ie,s as bn,a as Kr,c as Va,p as Yt,b as Mi,d as Os}from"../chunks/D_xsFZQB.js";import{g as Er,w as Xr}from"../chunks/MeCSEhQ9.js";/* empty css                */function Fe(e,t){return t}function Jl(e,t,n){for(var i=[],s=t.length,a,o=t.length,u=0;u<s;u++){let I=t[u];lo(I,()=>{if(a){if(a.pending.delete(I),a.done.add(I),a.pending.size===0){var b=e.outrogroups;ja(Qa(a.done)),b.delete(a),b.size===0&&(e.outrogroups=null)}}else o-=1},!1)}if(o===0){var c=i.length===0&&n!==null;if(c){var p=n,g=p.parentNode;El(g),g.append(p),e.items.clear()}ja(t,!c)}else a={pending:new Set(t),done:new Set},(e.outrogroups??(e.outrogroups=new Set)).add(a)}function ja(e,t=!0){for(var n=0;n<e.length;n++)Tl(e[n],t)}var Ns;function xe(e,t,n,i,s,a=null){var o=e,u=new Map,c=(t&uo)!==0;if(c){var p=e;o=cn?Gi(Yi(p)):p.appendChild(Ia())}cn&&Pa();var g=null,I=xl(()=>{var C=n();return yl(C)?C:C==null?[]:Qa(C)}),b,h=!0;function E(){T.fallback=g,ql(T,b,o,t,i),g!==null&&(b.length===0?(g.f&Zn)===0?oo(g):(g.f^=Zn,pi(g,null,o)):lo(g,()=>{g=null}))}var F=vl(()=>{b=r(I);var C=b.length;let V=!1;if(cn){var Y=gl(o)===ml;Y!==(C===0)&&(o=Ds(),Gi(o),Da(!1),V=!0)}for(var Q=new Set,ye=Fr,Ne=hl(),_e=0;_e<C;_e+=1){cn&&Vr.nodeType===so&&Vr.data===pl&&(o=Vr,V=!0,Da(!1));var Ce=b[_e],Ve=i(Ce,_e),Se=h?null:u.get(Ve);Se?(Se.v&&Es(Se.v,Ce),Se.i&&Es(Se.i,_e),Ne&&ye.unskip_effect(Se.e)):(Se=Zl(u,h?o:Ns??(Ns=Ia()),Ce,Ve,_e,s,t,n),h||(Se.e.f|=Zn),u.set(Ve,Se)),Q.add(Ve)}if(C===0&&a&&!g&&(h?g=Ma(()=>a(o)):(g=Ma(()=>a(Ns??(Ns=Ia()))),g.f|=Zn)),C>Q.size&&bl(),cn&&C>0&&Gi(Ds()),!h)if(Ne){for(const[oe,ne]of u)Q.has(oe)||ye.skip_effect(ne.e);ye.oncommit(E),ye.ondiscard(()=>{})}else E();V&&Da(!0),r(I)}),T={effect:F,items:u,outrogroups:null,fallback:g};h=!1,cn&&(o=Vr)}function di(e){for(;e!==null&&(e.f&Dl)===0;)e=e.next;return e}function ql(e,t,n,i,s){var Se,oe,ne,ae,G,P,re,Z,ce;var a=(i&Ol)!==0,o=t.length,u=e.items,c=di(e.effect.first),p,g=null,I,b=[],h=[],E,F,T,C;if(a)for(C=0;C<o;C+=1)E=t[C],F=s(E,C),T=u.get(F).e,(T.f&Zn)===0&&((oe=(Se=T.nodes)==null?void 0:Se.a)==null||oe.measure(),(I??(I=new Set)).add(T));for(C=0;C<o;C+=1){if(E=t[C],F=s(E,C),T=u.get(F).e,e.outrogroups!==null)for(const ee of e.outrogroups)ee.pending.delete(T),ee.done.delete(T);if((T.f&Zn)!==0)if(T.f^=Zn,T===c)pi(T,null,n);else{var V=g?g.next:c;T===e.effect.last&&(e.effect.last=T.prev),T.prev&&(T.prev.next=T.next),T.next&&(T.next.prev=T.prev),$n(e,g,T),$n(e,T,V),pi(T,V,n),g=T,b=[],h=[],c=di(g.next);continue}if((T.f&Ea)!==0&&(oo(T),a&&((ae=(ne=T.nodes)==null?void 0:ne.a)==null||ae.unfix(),(I??(I=new Set)).delete(T))),T!==c){if(p!==void 0&&p.has(T)){if(b.length<h.length){var Y=h[0],Q;g=Y.prev;var ye=b[0],Ne=b[b.length-1];for(Q=0;Q<b.length;Q+=1)pi(b[Q],Y,n);for(Q=0;Q<h.length;Q+=1)p.delete(h[Q]);$n(e,ye.prev,Ne.next),$n(e,g,ye),$n(e,Ne,Y),c=Y,g=Ne,C-=1,b=[],h=[]}else p.delete(T),pi(T,c,n),$n(e,T.prev,T.next),$n(e,T,g===null?e.effect.first:g.next),$n(e,g,T),g=T;continue}for(b=[],h=[];c!==null&&c!==T;)(p??(p=new Set)).add(c),h.push(c),c=di(c.next);if(c===null)continue}(T.f&Zn)===0&&b.push(T),g=T,c=di(T.next)}if(e.outrogroups!==null){for(const ee of e.outrogroups)ee.pending.size===0&&(ja(Qa(ee.done)),(G=e.outrogroups)==null||G.delete(ee));e.outrogroups.size===0&&(e.outrogroups=null)}if(c!==null||p!==void 0){var _e=[];if(p!==void 0)for(T of p)(T.f&Ea)===0&&_e.push(T);for(;c!==null;)(c.f&Ea)===0&&c!==e.fallback&&_e.push(c),c=di(c.next);var Ce=_e.length;if(Ce>0){var Ve=(i&uo)!==0&&o===0?n:null;if(a){for(C=0;C<Ce;C+=1)(re=(P=_e[C].nodes)==null?void 0:P.a)==null||re.measure();for(C=0;C<Ce;C+=1)(ce=(Z=_e[C].nodes)==null?void 0:Z.a)==null||ce.fix()}Jl(e,_e,Ve)}}a&&fo(()=>{var ee,De;if(I!==void 0)for(T of I)(De=(ee=T.nodes)==null?void 0:ee.a)==null||De.apply()})}function Zl(e,t,n,i,s,a,o,u){var c=(o&_l)!==0?(o&wl)===0?Sl(n,!1,!1):Ts(n):null,p=(o&Il)!==0?Ts(s):null;return{v:c,i:p,e:Ma(()=>(a(t,c??n,p??s,u),()=>{e.delete(i)}))}}function pi(e,t,n){if(e.nodes)for(var i=e.nodes.start,s=e.nodes.end,a=t&&(t.f&Zn)===0?t.nodes.start:n;i!==null;){var o=co(i);if(a.before(i),i===s)return;i=o}}function $n(e,t,n){t===null?e.effect.first=n:t.next=n,n===null?e.effect.last=t:n.prev=t}function Kl(e,t,n=!1,i=!1,s=!1){var a=e,o="";H(()=>{var u=Nl;if(o===(o=t()??"")){cn&&Pa();return}if(u.nodes!==null&&(kl(u.nodes.start,u.nodes.end),u.nodes=null),o!==""){if(cn){Vr.data;for(var c=Pa(),p=c;c!==null&&(c.nodeType!==so||c.data!=="");)p=c,c=co(c);if(c===null)throw Al(),Cl;Is(Vr,p),a=Gi(c);return}var g=n?Rl:i?Ll:void 0,I=zl(n?"svg":i?"math":"template",g);I.innerHTML=o;var b=n||i?I:I.content;if(Is(Yi(b),b.lastChild),n||i)for(;Yi(b);)a.before(Yi(b));else a.before(b)}})}function Bi(e,t,n){Pl(()=>{var i=rr(()=>t(e,n==null?void 0:n())||{});if(n&&(i!=null&&i.update)){var s=!1,a={};vo(()=>{var o=n();Ml(o),s&&Fl(a,o)&&(a=o,i.update(o))}),s=!0}if(i!=null&&i.destroy)return()=>i.destroy()})}const ks=[...` 	
\r\f \v\uFEFF`];function Xl(e,t,n){var i=e==null?"":""+e;if(t&&(i=i?i+" "+t:t),n){for(var s of Object.keys(n))if(n[s])i=i?i+" "+s:s;else if(i.length)for(var a=s.length,o=0;(o=i.indexOf(s,o))>=0;){var u=o+a;(o===0||ks.includes(i[o-1]))&&(u===i.length||ks.includes(i[u]))?i=(o===0?"":i.substring(0,o))+i.substring(u+1):o=u}}return i===""?null:i}function jn(e,t,n,i,s,a){var o=e.__className;if(cn||o!==n||o===void 0){var u=Xl(n,i,a);(!cn||u!==e.getAttribute("class"))&&(u==null?e.removeAttribute("class"):e.className=u),e.__className=n}else if(a&&s!==a)for(var c in a){var p=!!a[c];(s==null||p!==!!s[c])&&e.classList.toggle(c,p)}return a}const Ql=Symbol("is custom element"),$l=Symbol("is html"),ec=go?"link":"LINK",tc=go?"progress":"PROGRESS";function Ee(e){if(cn){var t=!1,n=()=>{if(!t){if(t=!0,e.hasAttribute("value")){var i=e.value;Tt(e,"value",null),e.value=i}if(e.hasAttribute("checked")){var s=e.checked;Tt(e,"checked",null),e.checked=s}}};e.__on_r=n,fo(n),Vl()}}function tt(e,t){var n=$a(e);n.value===(n.value=t??void 0)||e.value===t&&(t!==0||e.nodeName!==tc)||(e.value=t??"")}function mo(e,t){var n=$a(e);n.checked!==(n.checked=t??void 0)&&(e.checked=t)}function Tt(e,t,n,i){var s=$a(e);cn&&(s[t]=e.getAttribute(t),t==="src"||t==="srcset"||t==="href"&&e.nodeName===ec)||s[t]!==(s[t]=n)&&(t==="loading"&&(e[jl]=n),n==null?e.removeAttribute(t):typeof n!="string"&&nc(e).includes(t)?e[t]=n:e.setAttribute(t,n))}function $a(e){return e.__attributes??(e.__attributes={[Ql]:e.nodeName.includes("-"),[$l]:e.namespaceURI===Wl})}var As=new Map;function nc(e){var t=e.getAttribute("is")||e.nodeName,n=As.get(t);if(n)return n;As.set(t,n=[]);for(var i,s=e,a=Element.prototype;a!==s;){i=Ul(s);for(var o in i)i[o].set&&n.push(o);s=Hl(s)}return n}function In(e,t,n=t){var i=new WeakSet;Gl(e,"input",async s=>{var a=s?e.defaultValue:e.value;if(a=Ta(e)?Oa(a):a,n(a),Fr!==null&&i.add(Fr),await Yl(),a!==(a=t())){var o=e.selectionStart,u=e.selectionEnd,c=e.value.length;if(e.value=a??"",u!==null){var p=e.value.length;o===u&&u===c&&p>c?(e.selectionStart=p,e.selectionEnd=p):(e.selectionStart=o,e.selectionEnd=Math.min(u,p))}}}),(cn&&e.defaultValue!==e.value||rr(t)==null&&e.value)&&(n(Ta(e)?Oa(e.value):e.value),Fr!==null&&i.add(Fr)),vo(()=>{var s=t();if(e===document.activeElement){var a=Bl??Fr;if(i.has(a))return}Ta(e)&&s===Oa(e.value)||e.type==="date"&&!s&&!e.value||s!==e.value&&(e.value=s??"")})}function Ta(e){var t=e.type;return t==="number"||t==="range"}function Oa(e){return e===""?null:+e}const rc=`/**
 * runtime.js — ЕДИНСТВЕННЫЙ ИСТОЧНИК ИГРОВОЙ ЛОГИКИ
 *
 * Используется в двух местах:
 *   1. \`import ... from '$lib/engine/runtime.js?raw'\` в generateHtml.ts
 *      → код вставляется как есть внутрь экспортируемого standalone .html
 *      (должен работать в обычном <script>, без модулей).
 *
 *   2. \`import * as runtime from './engine/runtime.js'\` в gameEngine.ts
 *      → даёт типизированный доступ + editor-only функции поверх.
 *
 * ПРАВИЛА:
 * - Здесь живут **только** функции, нужные для проигрывания истории.
 * - НИКАКИХ редакторских вещей: normalizeLoadedStory, getConditionReferencedKeys,
 *   DnD, буферы, свёртки, suggested*, сохранение UI и т.п.
 * - Функции объявлены как обычные function (чтобы были в глобальной области после inlining).
 * - В конце файла есть блок экспортов — он автоматически вырезается при ?raw.
 *
 * ВСЁ, ЧТО КАСАЕТСЯ МЕХАНИКИ ИГРЫ (броски, тиры, эффекты, условия, диалоги),
 * ИЗМЕНЯЕТСЯ ТОЛЬКО В ЭТОМ ФАЙЛЕ.
 */

function rollDice(diceNotation, vars) {
  let expr = diceNotation;
  Object.entries(vars || {}).forEach(([key, value]) => {
    expr = expr.replace(new RegExp(\`\\\\b\${key}\\\\b\`, 'gi'), String(value));
  });
  expr = expr.replace(/\\s+/g, '');
  const termMatches = expr.match(/[+-]?(?:\\d+d\\d+|\\d+)/gi) || [];
  if (termMatches.length === 0) return 10;
  let total = 0;
  for (let raw of termMatches) {
    let sign = 1;
    if (raw.startsWith('-')) {
      sign = -1;
      raw = raw.slice(1);
    } else if (raw.startsWith('+')) {
      raw = raw.slice(1);
    }
    if (raw.includes('d')) {
      const [numStr, sidesStr] = raw.split('d');
      const num = parseInt(numStr, 10) || 1;
      const sides = parseInt(sidesStr, 10) || 6;
      for (let i = 0; i < num; i++) {
        total += sign * (Math.floor(Math.random() * sides) + 1);
      }
    } else {
      total += sign * (parseInt(raw, 10) || 0);
    }
  }
  return total;
}

function applyEffects(effects, state) {
  if (!effects) return { variables: {...state.variables}, items: {...state.items} };
  const variables = {...state.variables};
  const items = {...state.items};
  const effectsList = effects.split(',').map(e => e.trim()).filter(Boolean);
  for (const effect of effectsList) {
    if (effect.startsWith('addItem:') || effect.startsWith('removeItem:')) {
      const parts = effect.split(':');
      const action = parts[0];
      const itemName = parts[1];
      const qty = parseInt(parts[2] || '1', 10) || 1;
      if (itemName) {
        const current = items[itemName] ?? 0;
        items[itemName] = action === 'addItem' ? current + qty : Math.max(0, current - qty);
      }
    } else {
      const [key, valStr] = effect.split(':');
      if (key && valStr !== undefined) {
        const val = parseInt(valStr, 10);
        if (!isNaN(val)) variables[key] = (variables[key] || 0) + val;
      }
    }
  }
  return { variables, items };
}

function tokenizeCondition(str) {
  const tokens = [];
  let i = 0;
  const len = str.length;
  while (i < len) {
    if (/\\s/.test(str[i])) { i++; continue; }
    if (str[i] === '(') { tokens.push({ type: 'LPAREN' }); i++; continue; }
    if (str[i] === ')') { tokens.push({ type: 'RPAREN' }); i++; continue; }
    if (str.startsWith('>=', i)) { tokens.push({ type: 'OP', value: '>=' }); i += 2; continue; }
    if (str.startsWith('<=', i)) { tokens.push({ type: 'OP', value: '<=' }); i += 2; continue; }
    if (str.startsWith('==', i)) { tokens.push({ type: 'OP', value: '==' }); i += 2; continue; }
    if (str[i] === '>') { tokens.push({ type: 'OP', value: '>' }); i++; continue; }
    if (str[i] === '<') { tokens.push({ type: 'OP', value: '<' }); i++; continue; }
    if (str.startsWith('and', i) && (i + 3 >= len || /[\\s()]/.test(str[i + 3]))) { tokens.push({ type: 'AND' }); i += 3; continue; }
    if (str.startsWith('or', i) && (i + 2 >= len || /[\\s()]/.test(str[i + 2]))) { tokens.push({ type: 'OR' }); i += 2; continue; }
    if (str.startsWith('not', i) && (i + 3 >= len || /[\\s()]/.test(str[i + 3]))) { tokens.push({ type: 'NOT' }); i += 3; continue; }
    if (str[i] === "'" || str[i] === '"') {
      const q = str[i]; let j = i + 1; let val = '';
      while (j < len && str[j] !== q) { val += str[j]; j++; }
      if (j < len) j++;
      tokens.push({ type: 'KEY', value: val }); i = j; continue;
    }
    if (/[a-zA-Zа-яА-ЯёЁ0-9_]/.test(str[i])) {
      let j = i;
      while (j < len && /[a-zA-Zа-яА-ЯёЁ0-9_]/.test(str[j])) j++;
      const word = str.slice(i, j);
      tokens.push({ type: 'KEY', value: word }); i = j; continue;
    }
    i++;
  }
  return tokens;
}

function evaluateCondition(condition, state) {
  if (!condition) return true;
  const tokens = tokenizeCondition(condition.trim());
  if (tokens.length === 0) return true;
  let pos = 0;

  function parseOr() {
    let val = parseAnd();
    while (pos < tokens.length && tokens[pos].type === 'OR') {
      pos++; const right = parseAnd(); val = val || right;
    }
    return val;
  }
  function parseAnd() {
    let val = parseNot();
    while (pos < tokens.length && tokens[pos].type === 'AND') {
      pos++; const right = parseNot(); val = val && right;
    }
    return val;
  }
  function parseNot() {
    if (pos < tokens.length && tokens[pos].type === 'NOT') {
      pos++; return !parseNot();
    }
    return parsePrimary();
  }
  function parsePrimary() {
    if (pos < tokens.length && tokens[pos].type === 'LPAREN') {
      pos++; const val = parseOr();
      if (pos < tokens.length && tokens[pos].type === 'RPAREN') pos++;
      return val;
    }
    if (pos >= tokens.length) return true; // malformed -> graceful true
    let key = tokens[pos].value;
    if ((key.startsWith("'") && key.endsWith("'")) || (key.startsWith('"') && key.endsWith('"'))) {
      key = key.slice(1, -1);
    }
    pos++;
    if (pos >= tokens.length || tokens[pos].type !== 'OP') return true; // invalid syntax -> graceful true
    const op = tokens[pos].value; pos++;
    if (pos >= tokens.length) return true;
    const valStr = tokens[pos].value; pos++;
    const value = parseInt(valStr, 10);
    if (isNaN(value)) return true;

    const varExists = key in state.variables;
    const itemExists = key in state.items;

    if (!varExists && !itemExists) {
      return false; // characteristic or item does not exist -> condition is false
    }

    if (varExists) {
      const v = state.variables[key];
      if (op === '>') return v > value;
      if (op === '>=') return v >= value;
      if (op === '<') return v < value;
      if (op === '<=') return v <= value;
      if (op === '==') return v === value;
    }
    if (itemExists) {
      const count = state.items[key] ?? 0;
      if (op === '>') return count > value;
      if (op === '>=') return count >= value;
      if (op === '<') return count < value;
      if (op === '<=') return count <= value;
      if (op === '==') return count === value;
    }
    return false;
  }
  return parseOr();
}

function getNextDialogueStep(afterNpcLineIndex, npcResponses, state) {
  if (!npcResponses || npcResponses.length === 0) {
    return afterNpcLineIndex + 1;
  }
  for (let idx = afterNpcLineIndex; idx < npcResponses.length; idx++) {
    const resp = npcResponses[idx];
    if (!resp.condition || evaluateCondition(resp.condition, state)) {
      return idx + 1;
    }
  }
  return npcResponses.length + 1;
}

function getDialogueNpcNameForStep(scene, step) {
  if (!scene) return undefined;
  let name;
  let emotion;
  if (step === 0) {
    name = scene.npcName;
    emotion = scene.npcEmotion;
  } else {
    const resp = scene.npcResponses?.[step - 1];
    name = resp?.npcName || scene.npcName;
    emotion = resp?.emotion;
  }
  if (!name) return undefined;
  if (emotion) return \`\${name} (\${emotion})\`;
  return name;
}

function formatDialogueLine(speakerName, text, isPlayer) {
  if (!text) return '';
  if (isPlayer) {
    return \`Вы: \${text}\`;
  }
  const prefix = speakerName ? speakerName + ': ' : '';
  return prefix + text;
}

function processDisplayText(text, state, characterName = 'Герой') {
  if (!text) return '';
  return text
    .replace(/\\{(\\w+):[+-]?\\d+\\}/g, '')
    .replace(/\\{(addItem|removeItem):[^}]+\\}/g, '')
    .replace(/\\{(\\w+)\\}/g, (match, key) => {
      if (key === 'characterName') {
        return characterName || 'Герой';
      }
      if (key in state.variables) {
        return String(state.variables[key]);
      }
      return match;
    });
}

function applyInlineSceneEffects(text, state) {
  if (!text) return { ...state };
  const itemRegex = /\\{(addItem|removeItem):([^:]+):(\\d+)\\}/g;
  let match;
  let changed = false;
  const newItems = { ...state.items };
  while ((match = itemRegex.exec(text)) !== null) {
    const [, action, itemName, qtyStr] = match;
    const qty = parseInt(qtyStr, 10) || 1;
    const current = newItems[itemName] ?? 0;
    if (action === 'addItem') {
      newItems[itemName] = current + qty;
    } else {
      newItems[itemName] = Math.max(0, current - qty);
    }
    changed = true;
  }
  if (!changed) {
    return { ...state };
  }
  return {
    variables: { ...state.variables },
    items: newItems,
  };
}

function getNextSceneId(choice, varsForRoll, threshold = 12) {
  let nextId = choice.next || '';
  let rollResult;
  if (choice.roll) {
    rollResult = rollDice(choice.roll, varsForRoll);
    const success = rollResult >= threshold;
    nextId = success && choice.onSuccess ? choice.onSuccess : (choice.onFail || choice.next || '');
  }
  // Do not force 'end' here; caller (makeChoice equivalent) decides (dialogue stay vs end game).
  return { nextId, rollResult };
}

function getDialogueAwareNext(choice, currentSceneId, isDialogue) {
  if (isDialogue && !choice.next) {
    return currentSceneId;
  }
  return choice.next || 'end';
}

// === Многоуровневые пороги (0/25/50/85/100) ===
function getDiceMax(diceNotation, vars) {
  let expr = diceNotation;
  Object.entries(vars || {}).forEach(([key, value]) => {
    expr = expr.replace(new RegExp(\`\\\\b\${key}\\\\b\`, 'gi'), String(value));
  });
  expr = expr.replace(/\\s+/g, '');
  const termMatches = expr.match(/[+-]?(?:\\d+d\\d+|\\d+)/gi) || [];
  if (termMatches.length === 0) return 10;
  let max = 0;
  for (let raw of termMatches) {
    let sign = 1;
    if (raw.startsWith('-')) {
      sign = -1;
      raw = raw.slice(1);
    } else if (raw.startsWith('+')) {
      raw = raw.slice(1);
    }
    if (raw.includes('d')) {
      const [numStr, sidesStr] = raw.split('d');
      const num = parseInt(numStr, 10) || 1;
      const sides = parseInt(sidesStr, 10) || 6;
      max += sign * (num * sides);
    } else {
      max += sign * (parseInt(raw, 10) || 0);
    }
  }
  return max;
}

function getTargetForPercent(diceNotation, vars, percent) {
  const max = getDiceMax(diceNotation, vars);
  if (max <= 0) return 1;
  return Math.max(1, Math.ceil(max * (percent / 100)));
}

function evaluateRollOutcome(choice, vars, forceTier = null) {
  if (!choice.roll) {
    return {
      rollValue: 0,
      nextId: choice.next || '',
      effects: choice.effects,
    };
  }

  // Support forced tier for testing in preview (bypasses random roll)
  if (forceTier != null && choice.rollTiers) {
    const tierKey = String(forceTier);
    const tierData = choice.rollTiers[tierKey] || {};
    // Compute a plausible fake roll value that would land in this tier
    const max = getDiceMax(choice.roll, vars);
    let fakePercent = 50;
    if (forceTier === 0) fakePercent = 12;
    else if (forceTier === 25) fakePercent = 37;
    else if (forceTier === 50) fakePercent = 67;
    else if (forceTier === 85) fakePercent = 92;
    else if (forceTier === 100) fakePercent = 98;
    const fakeRoll = max > 0 ? Math.floor((max * fakePercent) / 100) : 0;

    return {
      rollValue: fakeRoll,
      tier: forceTier,
      nextId: tierData.next || choice.next || '',
      effects: tierData.effects || choice.effects,
    };
  }

  const rollValue = rollDice(choice.roll, vars);

  if (!choice.rollTiers) {
    // roll без rollTiers — только для отображения в алерте, переход по next
    return {
      rollValue,
      nextId: choice.next || '',
      effects: choice.effects,
    };
  }

  // Новая система многоуровневых порогов (диапазоны успеха от макса броска)
  // - 0% <= roll < 25% от макса → тир "0"
  // - 25% <= roll < 50% от макса → тир "25%"
  // - и т.д. до 100% (крит)
  const tierBands = [
    { key: '100', min: 95 },
    { key: '85', min: 85 },
    { key: '50', min: 50 },
    { key: '25', min: 25 },
    { key: '0', min: 0 },
  ];
  let achievedTier;
  let tierNext;
  let tierEffects;

  const max = getDiceMax(choice.roll, vars);
  const percentile = max > 0 ? (rollValue / max) * 100 : 0;

  let candidateKey;
  for (const band of tierBands) {
    if (percentile >= band.min) {
      candidateKey = band.key;
      break;
    }
  }

  if (candidateKey) {
    const tierData = choice.rollTiers[candidateKey];
    if (tierData && ((tierData.next && tierData.next.trim()) || (tierData.effects && tierData.effects.trim()))) {
      achievedTier = parseInt(candidateKey);
      tierNext = tierData.next;
      tierEffects = tierData.effects;
    }
  }

  let finalNext;
  if (achievedTier != null) {
    finalNext = tierNext || choice.next || 'end';
  } else {
    finalNext = choice.next || 'end';
  }

  let finalEffects;
  if (tierEffects && tierEffects.trim()) {
    finalEffects = tierEffects;
  } else {
    finalEffects = choice.effects;
  }

  return {
    rollValue,
    tier: achievedTier,
    nextId: finalNext,
    effects: finalEffects || undefined,
  };
}

function appendDialogueTurn(history, npcName, npcText, playerText) {
  const turn = formatDialogueLine(npcName, npcText) + '<br><br>' + formatDialogueLine(undefined, playerText, true);
  return (history ? history + '<br><br>' : '') + turn;
}

// --- EXPORTS FOR BUNDLER ONLY ---
// Everything below this marker is stripped when this file is loaded via ?raw
// and inlined into the <script> of a standalone HTML export (classic script, not module).
// This prevents "export declarations may only appear at top level of a module".
// The function declarations above stay and become available globally to the player code.
export {
  rollDice,
  applyEffects,
  evaluateCondition,
  tokenizeCondition,
  processDisplayText,
  applyInlineSceneEffects,
  getDiceMax,
  getTargetForPercent,
  evaluateRollOutcome,
  getNextDialogueStep,
  getDialogueNpcNameForStep,
  formatDialogueLine,
  getNextSceneId,
  getDialogueAwareNext,
  appendDialogueTurn
};
`;function ic(e){const t=JSON.stringify(e,null,2);let n=rc.replace(/\/\/ --- EXPORTS FOR BUNDLER ONLY[\s\S]*$/,"").trim();return`<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${(e.title||"Интерактивная история").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}</title>
  <style>
    /* ====================== КАСТОМНЫЕ СТИЛИ ИСТОРИИ ====================== */
    .btn-save {
  background: linear-gradient(to right, #059669, #0f766e);
  color: white;
  font-weight: 600;
  padding: 0.75rem 1.75rem;
  border-radius: 1rem;
  box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.3);
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  border: none;
  cursor: pointer;
}

.btn-save:hover {
  background: linear-gradient(to right, #10b981, #14b8a6);
  transform: translateY(-2px);
  box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.3);
}

.btn-save:active {
  transform: scale(0.95);
}

    body { 
      font-family: Georgia, serif; 
      background: #1a120b; 
      color: #f5e6c4; 
      line-height: 1.6; 
      margin: 0; 
      padding: 0; 
    }
    
    .choice { 
      transition: all 0.2s; 
      color: #fcd34d !important; 
      font-weight: 600; 
      font-size: 1.1rem; 
    }
    .choice:hover { 
      transform: translateX(12px); 
      background-color: #1e40af !important; 
    }

    .slot { 
      transition: all 0.15s; 
      min-height: 70px; 
      padding: 1.25rem 1rem; 
    }
    .slot:hover { background-color: #27272a; }

    /* ====================== TAILWIND УТИЛИТЫ (из all-tailwind-classes-full-min.css) ====================== */
    .flex { display: flex; }
    .flex-col { flex-direction: column; }
    .flex-wrap { flex-wrap: wrap; }
    .grid { display: grid; }
    .grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    .flex-1 { flex: 1 1 0%; }

    .gap-3 { gap: 0.75rem; }
    .gap-4 { gap: 1rem; }
    .gap-6 { gap: 1.5rem; }
    .gap-x-8 { column-gap: 2rem; }
    .gap-y-2 { row-gap: 0.5rem; }

    .justify-center { justify-content: center; }
    .justify-between { justify-content: space-between; }
    .items-center { align-items: center; }

    .p-4 { padding: 1rem; }
    .p-5 { padding: 1.25rem; }
    .p-6 { padding: 1.5rem; }
    .p-12 { padding: 3rem; }
    .px-6 { padding-left: 1.5rem; padding-right: 1.5rem; }
    .px-16 { padding-left: 4rem; padding-right: 4rem; }
    .py-6 { padding-top: 1.5rem; padding-bottom: 1.5rem; }
    .py-12 { padding-top: 3rem; padding-bottom: 3rem; }

    .mt-8 { margin-top: 2rem; }
    .mt-10 { margin-top: 2.5rem; }
    .mb-2 { margin-bottom: 0.5rem; }
    .mb-4 { margin-bottom: 1rem; }
    .mb-6 { margin-bottom: 1.5rem; }
    .mb-8 { margin-bottom: 2rem; }

    .max-w-3xl { max-width: 48rem; }
    .max-w-md { max-width: 28rem; }
    .w-full { width: 100%; }
    .min-h-screen { min-height: 100vh; }
    .min-h-\\[85vh\\] { min-height: 85vh; }
    .min-h-\\[45vh\\] { min-height: 45vh; }

    /* Цвета */
    .bg-\\[\\#1a120b\\] { background-color: #1a120b; }
    .bg-\\[\\#2a1f17\\] { background-color: #2a1f17; }
    .bg-zinc-900 { background-color: #18181b; }
    .bg-zinc-900\\/80 { background-color: rgba(24,24,27,0.8); }
    .bg-zinc-800 { background-color: #27272a; }
    .bg-zinc-700 { background-color: #3f3f46; }
    .bg-zinc-950 { background-color: #09090b; }
    .bg-emerald-950\\/50 { background-color: rgba(5 150 105 / 0.5); }
    .bg-emerald-600 { background-color: #059669; }
    .bg-emerald-500 { background-color: #10b981; }
    .bg-amber-600 { background-color: #d97706; }
    .bg-amber-500 { background-color: #f59e0b; }
    .bg-blue-600 { background-color: #2563eb; }
    .bg-black\\/80 { background-color: rgba(0,0,0,0.8); }

    /* Hover цвета */
    .hover\\:bg-emerald-500:hover { background-color: #10b981; }
    .hover\\:bg-amber-500:hover { background-color: #f59e0b; }
    .hover\\:bg-blue-600:hover { background-color: #2563eb; }
    .hover\\:bg-zinc-700:hover { background-color: #3f3f46; }

    /* Текст */
    .text-amber-300 { color: #fcd34d; }
    .text-emerald-400 { color: #34d399; }
    .text-amber-400 { color: #fbbf24; }
    .text-zinc-400 { color: #a1a1aa; }
    .text-xs { font-size: 0.75rem; }
    .text-sm { font-size: 0.875rem; }
    .text-lg { font-size: 1.125rem; }
    .text-xl { font-size: 1.25rem; }
    .text-2xl { font-size: 1.5rem; }
    .text-4xl { font-size: 2.25rem; }
    .text-5xl { font-size: 3rem; }
    .text-\\[120px\\] { font-size: 120px; }

    .font-bold { font-weight: 700; }
    .font-medium { font-weight: 500; }
    .font-serif { font-family: Georgia, serif; }
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .leading-relaxed { line-height: 1.625; }
    .uppercase { text-transform: uppercase; }
    .opacity-60 { opacity: 0.6; }
    .truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

    /* Градиент */
    .bg-gradient-to-r { background-image: linear-gradient(to right, var(--tw-gradient-stops)); }
    .from-emerald-600 { --tw-gradient-from: #059669; --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to, rgb(5 150 105 / 0)); }
    .to-teal-600 { --tw-gradient-to: #0f766e; }
    .hover\\:from-emerald-500:hover { --tw-gradient-from: #10b981; }
    .hover\\:to-teal-500:hover { --tw-gradient-to: #14b8a6; }

    /* Эффекты */
    .transition-all { transition: all 0.15s cubic-bezier(0.4, 0, 0.2, 1); }
    .active\\:scale-95:active { transform: scale(0.95); }

    .border { border-width: 1px; }
    .border-amber-900 { border-color: #78350f; }
    .border-zinc-700 { border-color: #3f3f46; }
    .border-emerald-600 { border-color: #059669; }
    .rounded-2xl { border-radius: 1rem; }
    .rounded-3xl { border-radius: 1.5rem; }
    .shadow-2xl { box-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.4); }

    .fixed { position: fixed; }
    .inset-0 { inset: 0; }
    .z-50 { z-index: 50; }
    .mx-auto { margin-left: auto; margin-right: auto; }
  </style>
</head>
<body class="min-h-screen p-8 bg-[#1a120b]">
  <div class="max-w-3xl mx-auto">
    <div id="game" class="bg-[#2a1f17] rounded-3xl p-12 shadow-2xl border border-amber-900 min-h-[85vh] flex flex-col"></div>
  </div>

  <script>
    const story = ${t};
    
    // === Единая игровая логика из gameEngine (single source of truth) ===
    ${n}

    let currentId = story.startScene;
    if (!story.scenes?.some(s => s.id === currentId)) {
      currentId = story.scenes?.[0]?.id || 'end';
    }

    let vars = {...story.variables};
    let items = {...(story.items || {})};
    let currentSlot = 1;

    // Для диалогов: накопленная история (вопрос НПС + ответ игрока + ...)
    let dialogueHistory = '';
    let currentDialogueStep = 0;

    const STORAGE_KEY = 'ist-game-save-slot-';
    const AUTO_SAVE_KEY = 'ist-game-autosave';

    function getSlotKey(slot) { return STORAGE_KEY + slot; }

    function saveToSlot(slot) {
      const now = Date.now();
      // Clean dialogue state if not currently in a dialogue scene (to avoid carrying stale history to non-dialogue saves)
      let saveDialogueHistory = dialogueHistory;
      let saveCurrentDialogueStep = currentDialogueStep;
      const currentSceneForSave = story.scenes.find(s => s.id === currentId);
      if (!currentSceneForSave?.isDialogue) {
        saveDialogueHistory = '';
        saveCurrentDialogueStep = 0;
      }
      const data = { sceneId: currentId, variables: {...vars}, items: {...items}, dialogueHistory: saveDialogueHistory, currentDialogueStep: saveCurrentDialogueStep, timestamp: new Date(now).toLocaleString('ru-RU'), timestampMs: now };
      localStorage.setItem(getSlotKey(slot), JSON.stringify(data));
      currentSlot = slot;
      render();
    }

    function quickSave() {
      saveToSlot(currentSlot);
      alert('💾 Сохранено в слот ' + currentSlot);
    }

    function loadSlot(slot) {
      const str = localStorage.getItem(getSlotKey(slot));
      if (!str) return alert('❌ Слот ' + slot + ' пустой');
      const data = JSON.parse(str);
      currentId = data.sceneId;
      // Only restore dialogue state if the loaded scene is actually a dialogue scene.
      // This prevents stale dialogueHistory from previous saves from polluting non-dialogue or wrong context.
      const loadedScene = story.scenes.find(s => s.id === currentId);
      if (loadedScene?.isDialogue) {
        dialogueHistory = data.dialogueHistory || '';
        currentDialogueStep = data.currentDialogueStep || 0;
      } else {
        dialogueHistory = '';
        currentDialogueStep = 0;
      }
      vars = {...data.variables};
      items = {...data.items};
      currentSlot = slot;
      autoSave();
      render();
      alert('✅ Загружен слот ' + slot);
    }

    function getAllSlots() {
      const slots = [];
      for (let i = 1; i <= 4; i++) {
        const str = localStorage.getItem(getSlotKey(i));
        slots.push(str ? JSON.parse(str) : null);
      }
      return slots;
    }

    // === Автосохранение (отдельный слот, не затирает 1-4) ===
    function autoSave() {
      const now = Date.now();
      // Clean dialogue state if not currently in a dialogue scene (to avoid carrying stale history to non-dialogue saves)
      let saveDialogueHistory = dialogueHistory;
      let saveCurrentDialogueStep = currentDialogueStep;
      const currentSceneForSave = story.scenes.find(s => s.id === currentId);
      if (!currentSceneForSave?.isDialogue) {
        saveDialogueHistory = '';
        saveCurrentDialogueStep = 0;
      }
      const data = { sceneId: currentId, variables: {...vars}, items: {...items}, dialogueHistory: saveDialogueHistory, currentDialogueStep: saveCurrentDialogueStep, timestamp: new Date(now).toLocaleString('ru-RU'), timestampMs: now };
      localStorage.setItem(AUTO_SAVE_KEY, JSON.stringify(data));
    }

    function loadAutoSave() {
      const str = localStorage.getItem(AUTO_SAVE_KEY);
      if (!str) return alert('❌ Автосохранение пустое');
      const data = JSON.parse(str);
      currentId = data.sceneId;
      // Only restore dialogue state if the loaded scene is actually a dialogue scene.
      // This prevents stale dialogueHistory from previous saves from polluting non-dialogue or wrong context.
      const loadedScene = story.scenes.find(s => s.id === currentId);
      if (loadedScene?.isDialogue) {
        dialogueHistory = data.dialogueHistory || '';
        currentDialogueStep = data.currentDialogueStep || 0;
      } else {
        dialogueHistory = '';
        currentDialogueStep = 0;
      }
      vars = {...data.variables};
      items = {...data.items};
      render();
      alert('✅ Загружено автосохранение');
    }

    function render() {
      let scene = story.scenes.find(s => s.id === currentId);
      if (!scene && story.scenes?.length > 0) {
        scene = story.scenes[0];
        currentId = scene.id;
      }
      if (!scene) return showEnding();

      // В диалоге используем историю диалога (вопрос + ответы), иначе обычный текст
      let displayText = scene.text;
      if (scene.isDialogue && dialogueHistory) {
        displayText = dialogueHistory;
      }

      // Применяем inline-эффекты из текста сцены (addItem/removeItem в описании)
      // Для диалога НЕ применяем ко всей накопленной истории (displayText), иначе при загрузке
      // из сохранения вся история репарсится и инлайновые эффекты применяются повторно,
      // что ломает conditional реплики и приводит к преждевременному ендгейму.
      let inlineSource = scene.text;
      if (scene.isDialogue && dialogueHistory) {
        inlineSource = scene.text; // только текущий "живой" текст сцены
      }
      const stateAfterInline = applyInlineSceneEffects(inlineSource, { variables: vars, items: items });
      vars = stateAfterInline.variables;
      items = stateAfterInline.items;

      const currentStateForFilter = { variables: vars, items: items };
      const visibleChoices = scene.choices.filter(choice => {
        const condOk = evaluateCondition(choice.condition, currentStateForFilter);
        if (!scene.isDialogue) return condOk;
        const step = choice.npcLineIndex || 0;
        return condOk && step === currentDialogueStep;
      });

      let html = \`
        <h1 class="text-4xl mb-8 text-amber-300 font-bold text-center">\${story.title}</h1>

        <!-- Характеристики -->
        <div class="bg-zinc-900/80 p-4 rounded-2xl mb-6 flex gap-6 justify-center text-sm">
          \${Object.entries(vars).filter(([k, v]) => v !== 0).map(([k, v]) => \`
            <div class="text-center">
              <div class="text-xs opacity-60 uppercase">\${k}</div>
              <div class="text-2xl font-bold text-emerald-400">\${v}</div>
            </div>
          \`).join('')}
        </div>

        <!-- Инвентарь -->
        <div class="bg-zinc-900/80 p-4 rounded-2xl mb-8">
          <div class="text-xs opacity-60 uppercase mb-2">🎒 Инвентарь</div>
          <div class="flex flex-wrap gap-x-8 gap-y-2">
            \${Object.entries(items).filter(([name, count]) => count !== 0).map(([name, count]) => \`
              <div class="text-center">
                <div class="text-sm text-amber-300">\${name}</div>
                <div class="text-2xl font-bold text-amber-400">\${count}</div>
              </div>
            \`).join('')}
          </div>
        </div>

        <!-- Текст сцены / История диалога -->
        <div class="bg-zinc-900 p-12 rounded-3xl shadow-2xl border border-zinc-700 min-h-[45vh] font-serif text-xl leading-relaxed flex-1 whitespace-pre-wrap">
          \${processDisplayText(displayText, { variables: vars, items: items }, story.characterName)}
        </div>
      \`;

      if (visibleChoices.length === 0) {
        html += \`
          <div class="mt-10 text-center py-12">
            <div class="text-[120px] mb-6">🏁</div>
            <h2 class="text-5xl font-bold mb-4 text-amber-300">Конец истории</h2>
            <p class="text-2xl text-zinc-400 max-w-md mx-auto">Ты дошёл до финала этой ветки.<br>Спасибо за игру!</p>
            <button onclick="restartGame()" class="mt-8 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 px-16 py-6 rounded-3xl text-2xl font-medium transition-all active:scale-95">Начать историю заново</button>
          </div>
        \`;
      } else {
        html += \`<div class="mt-10 grid gap-4" id="choices"></div>\`;
      }

      html += \`
        <div class="mt-8 bg-zinc-900 border border-zinc-700 rounded-3xl p-6">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium">💾 Сохранения</h3>
            <div class="flex gap-3">
              <button onclick="quickSave()" class="btn-save">Сохранить</button>
              <button onclick="openSaveModal()" class="btn-save">Сохранить в слот...</button>
            </div>
          </div>
          <div class="grid grid-cols-4 gap-3" id="slots"></div>

          <!-- Автосохранение (отдельный слот) -->
          <div class="mt-6 pt-3 border-t border-zinc-700 flex items-center justify-between text-xs">
            <div id="autosave-info">Автосохранение: ...</div>
            <button onclick="loadAutoSave()" class="btn-save" style="padding: 0.35rem 0.9rem; font-size: 0.7rem; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.2);">Загрузить автосохранение</button>
          </div>
        </div>
      \`;

      document.getElementById('game').innerHTML = html;

      if (visibleChoices.length > 0) renderChoices(visibleChoices);
      renderSlots();
      renderAutoSaveInfo();
    }

    function renderChoices(visibleChoices) {
      const container = document.getElementById('choices');
      container.innerHTML = '';
      const currentScene = story.scenes.find(s => s.id === currentId);
      const isDialogue = !!currentScene?.isDialogue;

      visibleChoices.forEach((choice) => {
        const btn = document.createElement('button');
        btn.className = \`choice w-full bg-zinc-800 hover:bg-blue-600 p-6 rounded-2xl text-left transition text-lg border border-zinc-700\`;
        let displayText = choice.text + (choice.roll ? \` (\${choice.roll})\` : '');
        if (isDialogue) {
          displayText = \`Вы: \${displayText}\`;
        }
        btn.textContent = displayText;
        btn.onclick = () => makeChoice(choice);
        container.appendChild(btn);
      });
    }

    function renderSlots() {
      const container = document.getElementById('slots');
      container.innerHTML = '';
      const slotsData = getAllSlots();
      slotsData.forEach((data, i) => {
        const slotNum = i + 1;
        const btn = document.createElement('button');
        btn.className = \`slot p-5 rounded-2xl border transition text-left \${data ? \`border-emerald-600 bg-emerald-950/50\` : \`border-zinc-700 bg-zinc-950\`}\`;
        btn.innerHTML = \`
          <div class="text-xs opacity-60">Слот \${slotNum}</div>
          \${data ? \`
            <div class="text-sm font-medium text-emerald-400 truncate">\${data.sceneId}</div>
            <div class="text-[10px] opacity-50">\${data.timestamp}</div>
          \` : \`<div class="text-sm text-zinc-500 italic">Пусто</div>\`}
        \`;
        btn.onclick = () => loadSlot(slotNum);
        container.appendChild(btn);
      });
    }

    function renderAutoSaveInfo() {
      const info = document.getElementById('autosave-info');
      if (!info) return;
      const str = localStorage.getItem(AUTO_SAVE_KEY);
      if (str) {
        const data = JSON.parse(str);
        info.innerHTML = \`Автосохранение: <span class="text-emerald-400">\${data.timestamp} — \${data.sceneId}</span>\`;
      } else {
        info.textContent = 'Автосохранение: нет';
      }
    }

    function makeChoice(choice) {
      const stateBefore = { variables: {...vars}, items: {...items} };

      let effectsToApply = choice.effects;
      let nextId = choice.next || '';
      let rollValue;
      let tierLabel = '';

      const currentScene = story.scenes.find(s => s.id === currentId);
      const isDialogue = !!currentScene?.isDialogue;

      if (choice.roll) {
        // Используем новую многоуровневую логику (если rollTiers заданы) + legacy
        const outcome = evaluateRollOutcome(choice, vars);
        effectsToApply = outcome.effects;
        nextId = outcome.nextId;
        rollValue = outcome.rollValue;
        if (outcome.tier != null) tierLabel = ' (' + outcome.tier + '%)';
      }

      // Диалоговый режим: если next не указан — остаёмся в текущей сцене
      if (isDialogue && !nextId) {
        nextId = currentId;
      }

      if (isDialogue) {
        const currentNpcName = getDialogueNpcNameForStep(currentScene, currentDialogueStep);
        const currentNpcText = currentDialogueStep === 0 ? (currentScene?.text || '') : (currentScene?.npcResponses?.[currentDialogueStep-1]?.text || '');
        dialogueHistory = appendDialogueTurn(dialogueHistory, currentNpcName, currentNpcText, choice.text);

        // Применяем эффекты для проверки условий на следующих репликах НПС
        const postState = applyEffects(effectsToApply, { variables: {...vars}, items: {...items} });

        const thisStep = choice.npcLineIndex || 0;
        currentDialogueStep = getNextDialogueStep(thisStep, currentScene?.npcResponses, postState);

        const newNpcName = getDialogueNpcNameForStep(currentScene, currentDialogueStep);
        const newNpcText = currentDialogueStep === 0 ? '' : (currentScene?.npcResponses?.[currentDialogueStep-1]?.text || '');
        if (newNpcText) {
          dialogueHistory = appendDialogueTurn(dialogueHistory, newNpcName, newNpcText, '');
          // Применяем инлайны из новой реплики НПС сразу (чтобы эффекты были в состоянии на момент показа).
          // Это важно для корректной работы conditional следующих реплик и для того, чтобы после load
          // состояние не десинхронизировалось при повторном рендере.
          const inlineFromNewNpc = applyInlineSceneEffects(newNpcText, { variables: vars, items: items });
          vars = inlineFromNewNpc.variables;
          items = inlineFromNewNpc.items;
        }
      }

      const stateAfter = applyEffects(effectsToApply, stateBefore);
      vars = stateAfter.variables;
      items = stateAfter.items;

      if (choice.roll && rollValue !== undefined) {
        alert('🎲 Бросок: ' + choice.roll + ' → ' + rollValue + tierLabel);
      }

      if (nextId && nextId !== currentId) {
        currentId = nextId;
      }
      autoSave();
      if (currentId === 'end' || !story.scenes.some(s => s.id === currentId)) {
        showEnding();
      } else {
        render();
      }
    }

    function showEnding() {
      render();
    }

    window.quickSave = quickSave;
    window.openSaveModal = function() {
      const modal = document.createElement('div');
      modal.className = 'fixed inset-0 bg-black/80 flex items-center justify-center z-50';
      modal.innerHTML = \`
        <div class="bg-zinc-900 rounded-3xl p-8 max-w-md w-full">
          <h3 class="text-xl font-semibold mb-6">Сохранить в слот</h3>
          <div class="grid grid-cols-2 gap-4">
            \${Array.from({length:4}, (_,i)=>i+1).map(slot => \`
              <button onclick="saveToSlot(\${slot});this.parentElement.parentElement.parentElement.remove()" class="p-6 bg-zinc-800 hover:bg-zinc-700 rounded-2xl text-left">
                Слот \${slot}
              </button>
            \`).join('')}
          </div>
          <button onclick="this.parentElement.parentElement.remove()" class="mt-6 w-full py-3 text-zinc-400 hover:text-white">Отмена</button>
        </div>
      \`;
      document.body.appendChild(modal);
    };

    window.restartGame = function() {
      // Полный сброс к изначальной версии истории (как было при первой загрузке без сохранений).
      // Сбрасываем всё in-memory состояние + очищаем автосохранение,
      // чтобы "Начать заново" действительно возвращало чистый старт.
      // Ручные слоты (1-4) при этом не трогаем — это отдельные "сохранения" игрока.
      currentId = story.startScene;
      if (!story.scenes?.some(s => s.id === currentId)) {
        currentId = story.scenes?.[0]?.id || 'end';
      }
      dialogueHistory = '';
      currentDialogueStep = 0;
      vars = {...story.variables};
      items = {...(story.items || {})};
      currentSlot = 1;

      // Очищаем автосохранение, чтобы при перезагрузке страницы тоже началось с чистого листа
      localStorage.removeItem(AUTO_SAVE_KEY);

      render();
    };

    // Автосохранение в отдельный слот (не currentSlot)
    setInterval(() => { if (currentId) { autoSave(); renderAutoSaveInfo(); } }, 30000);

    function parseRussianOrISOTimestamp(tsStr) {
      if (!tsStr) return NaN;
      // Try DD.MM.YYYY, HH:mm:ss (Russian locale)
      const m = tsStr.match(/^(d{2}).(d{2}).(d{4}),s*(d{2}):(d{2}):(d{2})$/);
      if (m) {
        const [_, dd, mm, yyyy, hh, min, ss] = m;
        return new Date(yyyy, parseInt(mm)-1, parseInt(dd), parseInt(hh), parseInt(min), parseInt(ss)).getTime();
      }
      // Fallback to native
      const t = new Date(tsStr).getTime();
      return isNaN(t) ? NaN : t;
    }

    // Auto-resume the most recent save (manual slot or autosave, whichever has later timestamp)
    (function autoResumeLatestSave() {
      let latestData = null;
      let latestTimestamp = 0;
      let isAuto = false;
      let loadedSlot = null;

      // Check manual slots 1-4
      for (let i = 1; i <= 4; i++) {
        const str = localStorage.getItem(getSlotKey(i));
        if (str) {
          try {
            const d = JSON.parse(str);
            if (d && (d.timestampMs || d.timestamp)) {
              let t;
              if (d.timestampMs != null) {
                t = d.timestampMs;
              } else {
                t = parseRussianOrISOTimestamp(d.timestamp);
                if (isNaN(t)) {
                  continue;
                }
              }
              if (t > latestTimestamp) {
                latestTimestamp = t;
                latestData = d;
                isAuto = false;
                loadedSlot = i;
              }
            }
          } catch (e) {
            // ignore bad slot data
          }
        }
      }

      // Check autosave
      const autoStr = localStorage.getItem(AUTO_SAVE_KEY);
      if (autoStr) {
        try {
          const ad = JSON.parse(autoStr);
          if (ad && (ad.timestampMs || ad.timestamp)) {
            let t;
            if (ad.timestampMs != null) {
              t = ad.timestampMs;
            } else {
              t = parseRussianOrISOTimestamp(ad.timestamp);
              if (isNaN(t)) {
                // ignore
              }
            }
            if (t > latestTimestamp) {
              latestTimestamp = t;
              latestData = ad;
              isAuto = true;
              loadedSlot = null;
            }
          }
        } catch (e) {
          // ignore bad autosave data
        }
      }

      if (latestData && latestTimestamp > 0) {
        currentId = latestData.sceneId || story.startScene;
        // Only restore dialogue state if the loaded scene is actually a dialogue scene.
        // This prevents stale dialogueHistory from previous saves from polluting non-dialogue or wrong context.
        const loadedScene = story.scenes.find(s => s.id === currentId);
        if (loadedScene?.isDialogue) {
          dialogueHistory = latestData.dialogueHistory || '';
          currentDialogueStep = latestData.currentDialogueStep || 0;
        } else {
          dialogueHistory = '';
          currentDialogueStep = 0;
        }
        vars = {...(latestData.variables || story.variables)};
        items = {...(latestData.items || story.items)};
        if (!isAuto && loadedSlot) {
          currentSlot = loadedSlot;
        }
        // Silent auto-resume (no alert)
        render();
      } else {
        render();
      }
    })();
  <\/script>
</body>
</html>`}function ac(e,t){let n=e;Object.entries(t||{}).forEach(([a,o])=>{n=n.replace(new RegExp(`\\b${a}\\b`,"gi"),String(o))}),n=n.replace(/\s+/g,"");const i=n.match(/[+-]?(?:\d+d\d+|\d+)/gi)||[];if(i.length===0)return 10;let s=0;for(let a of i){let o=1;if(a.startsWith("-")?(o=-1,a=a.slice(1)):a.startsWith("+")&&(a=a.slice(1)),a.includes("d")){const[u,c]=a.split("d"),p=parseInt(u,10)||1,g=parseInt(c,10)||6;for(let I=0;I<p;I++)s+=o*(Math.floor(Math.random()*g)+1)}else s+=o*(parseInt(a,10)||0)}return s}function sc(e,t){if(!e)return{variables:{...t.variables},items:{...t.items}};const n={...t.variables},i={...t.items},s=e.split(",").map(a=>a.trim()).filter(Boolean);for(const a of s)if(a.startsWith("addItem:")||a.startsWith("removeItem:")){const o=a.split(":"),u=o[0],c=o[1],p=parseInt(o[2]||"1",10)||1;if(c){const g=i[c]??0;i[c]=u==="addItem"?g+p:Math.max(0,g-p)}}else{const[o,u]=a.split(":");if(o&&u!==void 0){const c=parseInt(u,10);isNaN(c)||(n[o]=(n[o]||0)+c)}}return{variables:n,items:i}}function po(e){const t=[];let n=0;const i=e.length;for(;n<i;){if(/\s/.test(e[n])){n++;continue}if(e[n]==="("){t.push({type:"LPAREN"}),n++;continue}if(e[n]===")"){t.push({type:"RPAREN"}),n++;continue}if(e.startsWith(">=",n)){t.push({type:"OP",value:">="}),n+=2;continue}if(e.startsWith("<=",n)){t.push({type:"OP",value:"<="}),n+=2;continue}if(e.startsWith("==",n)){t.push({type:"OP",value:"=="}),n+=2;continue}if(e[n]===">"){t.push({type:"OP",value:">"}),n++;continue}if(e[n]==="<"){t.push({type:"OP",value:"<"}),n++;continue}if(e.startsWith("and",n)&&(n+3>=i||/[\s()]/.test(e[n+3]))){t.push({type:"AND"}),n+=3;continue}if(e.startsWith("or",n)&&(n+2>=i||/[\s()]/.test(e[n+2]))){t.push({type:"OR"}),n+=2;continue}if(e.startsWith("not",n)&&(n+3>=i||/[\s()]/.test(e[n+3]))){t.push({type:"NOT"}),n+=3;continue}if(e[n]==="'"||e[n]==='"'){const s=e[n];let a=n+1,o="";for(;a<i&&e[a]!==s;)o+=e[a],a++;a<i&&a++,t.push({type:"KEY",value:o}),n=a;continue}if(/[a-zA-Zа-яА-ЯёЁ0-9_]/.test(e[n])){let s=n;for(;s<i&&/[a-zA-Zа-яА-ЯёЁ0-9_]/.test(e[s]);)s++;const a=e.slice(n,s);t.push({type:"KEY",value:a}),n=s;continue}n++}return t}function bo(e,t){if(!e)return!0;const n=po(e.trim());if(n.length===0)return!0;let i=0;function s(){let c=a();for(;i<n.length&&n[i].type==="OR";){i++;const p=a();c=c||p}return c}function a(){let c=o();for(;i<n.length&&n[i].type==="AND";){i++;const p=o();c=c&&p}return c}function o(){return i<n.length&&n[i].type==="NOT"?(i++,!o()):u()}function u(){if(i<n.length&&n[i].type==="LPAREN"){i++;const E=s();return i<n.length&&n[i].type==="RPAREN"&&i++,E}if(i>=n.length)return!0;let c=n[i].value;if((c.startsWith("'")&&c.endsWith("'")||c.startsWith('"')&&c.endsWith('"'))&&(c=c.slice(1,-1)),i++,i>=n.length||n[i].type!=="OP")return!0;const p=n[i].value;if(i++,i>=n.length)return!0;const g=n[i].value;i++;const I=parseInt(g,10);if(isNaN(I))return!0;const b=c in t.variables,h=c in t.items;if(!b&&!h)return!1;if(b){const E=t.variables[c];if(p===">")return E>I;if(p===">=")return E>=I;if(p==="<")return E<I;if(p==="<=")return E<=I;if(p==="==")return E===I}if(h){const E=t.items[c]??0;if(p===">")return E>I;if(p===">=")return E>=I;if(p==="<")return E<I;if(p==="<=")return E<=I;if(p==="==")return E===I}return!1}return s()}function oc(e,t,n){if(!t||t.length===0)return e+1;for(let i=e;i<t.length;i++){const s=t[i];if(!s.condition||bo(s.condition,n))return i+1}return t.length+1}function lc(e,t){var s;if(!e)return;let n,i;if(t===0)n=e.npcName,i=e.npcEmotion;else{const a=(s=e.npcResponses)==null?void 0:s[t-1];n=(a==null?void 0:a.npcName)||e.npcName,i=a==null?void 0:a.emotion}if(n)return i?`${n} (${i})`:n}function cc(e,t,n){return t?n?`Вы: ${t}`:(e?e+": ":"")+t:""}function uc(e,t,n="Герой"){return e?e.replace(/\{(\w+):[+-]?\d+\}/g,"").replace(/\{(addItem|removeItem):[^}]+\}/g,"").replace(/\{(\w+)\}/g,(i,s)=>s==="characterName"?n||"Герой":s in t.variables?String(t.variables[s]):i):""}function dc(e,t){if(!e)return{...t};const n=/\{(addItem|removeItem):([^:]+):(\d+)\}/g;let i,s=!1;const a={...t.items};for(;(i=n.exec(e))!==null;){const[,o,u,c]=i,p=parseInt(c,10)||1,g=a[u]??0;o==="addItem"?a[u]=g+p:a[u]=Math.max(0,g-p),s=!0}return s?{variables:{...t.variables},items:a}:{...t}}function Cs(e,t){let n=e;Object.entries(t||{}).forEach(([a,o])=>{n=n.replace(new RegExp(`\\b${a}\\b`,"gi"),String(o))}),n=n.replace(/\s+/g,"");const i=n.match(/[+-]?(?:\d+d\d+|\d+)/gi)||[];if(i.length===0)return 10;let s=0;for(let a of i){let o=1;if(a.startsWith("-")?(o=-1,a=a.slice(1)):a.startsWith("+")&&(a=a.slice(1)),a.includes("d")){const[u,c]=a.split("d"),p=parseInt(u,10)||1,g=parseInt(c,10)||6;s+=o*(p*g)}else s+=o*(parseInt(a,10)||0)}return s}function fc(e,t,n=null){if(!e.roll)return{rollValue:0,nextId:e.next||"",effects:e.effects};if(n!=null&&e.rollTiers){const h=String(n),E=e.rollTiers[h]||{},F=Cs(e.roll,t);let T=50;return n===0?T=12:n===25?T=37:n===50?T=67:n===85?T=92:n===100&&(T=98),{rollValue:F>0?Math.floor(F*T/100):0,tier:n,nextId:E.next||e.next||"",effects:E.effects||e.effects}}const i=ac(e.roll,t);if(!e.rollTiers)return{rollValue:i,nextId:e.next||"",effects:e.effects};const s=[{key:"100",min:95},{key:"85",min:85},{key:"50",min:50},{key:"25",min:25},{key:"0",min:0}];let a,o,u;const c=Cs(e.roll,t),p=c>0?i/c*100:0;let g;for(const h of s)if(p>=h.min){g=h.key;break}if(g){const h=e.rollTiers[g];h&&(h.next&&h.next.trim()||h.effects&&h.effects.trim())&&(a=parseInt(g),o=h.next,u=h.effects)}let I;a!=null?I=o||e.next||"end":I=e.next||"end";let b;return u&&u.trim()?b=u:b=e.effects,{rollValue:i,tier:a,nextId:I,effects:b||void 0}}function zs(e,t){return sc(e,t)}function vc(e,t){return bo(e,t)}function gc(e,t,n="Герой"){return uc(e,t,n)}function mc(e,t){return dc(e,t)}function pc(e,t,n){return fc(e,t,n)}function bc(e,t,n){return oc(e,t,n)}function fi(e,t){return lc(e,t)}function Pr(e,t,n=!1){return cc(e,t,n)}function hc(e){if(!e)return[];try{const t=po(e.trim()),n=[];for(const i of t)if(i.type==="KEY"){let s=i.value;(s.startsWith("'")&&s.endsWith("'")||s.startsWith('"')&&s.endsWith('"'))&&(s=s.slice(1,-1)),/^\d+$/.test(s)||n.push(s)}return n}catch{return[]}}function xc(e,t,n){if(!(e!=null&&e.trim()))return!0;const i=hc(e),s=Object.keys(t||{}),a=Object.keys(n||{});return i.every(o=>s.includes(o)||a.includes(o))}function Ir(e){var s;const t=Array.isArray(e==null?void 0:e.scenes)?e.scenes:[];let n=e==null?void 0:e.startScene;t.some(a=>(a==null?void 0:a.id)===n)||(n=((s=t[0])==null?void 0:s.id)||"scene1");const i=t.map(a=>{const o=(a==null?void 0:a.id)||`scene${Date.now()}`,u=Array.isArray(a==null?void 0:a.choices)?a.choices:[],c=new Set,p=u.map((h,E)=>{let F=(h==null?void 0:h.id)||`${o}-c${E}-${Date.now().toString(36)}`,T=0;for(;c.has(F);)T++,F=`${(h==null?void 0:h.id)||o+"-c"+E}-dedup${T}`;c.add(F);let C=h!=null&&h.rollTiers?{...h.rollTiers}:void 0;if(C)for(const V of["0","25","50","85","100"])C[V]||(C[V]={next:"",effects:""});return{id:F,text:(h==null?void 0:h.text)||"",next:(h==null?void 0:h.next)||"",roll:h==null?void 0:h.roll,onSuccess:h==null?void 0:h.onSuccess,onFail:h==null?void 0:h.onFail,effects:h==null?void 0:h.effects,condition:h==null?void 0:h.condition,rollTiers:C,npcLineIndex:h==null?void 0:h.npcLineIndex}}),g=Array.isArray(a==null?void 0:a.npcResponses)?a.npcResponses:void 0,I=new Set,b=g?g.map((h,E)=>{let F=(h==null?void 0:h.id)||`${o}-nr${E}`,T=0;for(;I.has(F);)T++,F=`${(h==null?void 0:h.id)||o+"-nr"+E}-dedup${T}`;return I.add(F),{id:F,text:(h==null?void 0:h.text)||"",condition:h==null?void 0:h.condition,npcName:h==null?void 0:h.npcName,emotion:h==null?void 0:h.emotion}}):void 0;return{id:o,text:(a==null?void 0:a.text)||"",choices:p,isDialogue:!!(a!=null&&a.isDialogue),npcName:a==null?void 0:a.npcName,npcEmotion:a==null?void 0:a.npcEmotion,npcResponses:b}});return{title:(e==null?void 0:e.title)||"Без названия",startScene:n,scenes:i,variables:(e==null?void 0:e.variables)||{},items:(e==null?void 0:e.items)||{},variableOrigins:(e==null?void 0:e.variableOrigins)||{},itemOrigins:(e==null?void 0:e.itemOrigins)||{},suggestedVariables:Array.isArray(e==null?void 0:e.suggestedVariables)?e.suggestedVariables:[],suggestedItems:Array.isArray(e==null?void 0:e.suggestedItems)?e.suggestedItems:[],suggestedNpcNames:Array.isArray(e==null?void 0:e.suggestedNpcNames)?e.suggestedNpcNames:[],suggestedEmotions:Array.isArray(e==null?void 0:e.suggestedEmotions)?e.suggestedEmotions:[],characterName:e==null?void 0:e.characterName,characterDescription:e==null?void 0:e.characterDescription,deletedScenes:Array.isArray(e==null?void 0:e.deletedScenes)?e.deletedScenes.map(a=>({originalIndex:typeof(a==null?void 0:a.originalIndex)=="number"?a.originalIndex:0,scene:a!=null&&a.scene?Ir({scenes:[a.scene],startScene:a.scene.id,variables:{},items:{},suggestedVariables:[],suggestedItems:[]}).scenes[0]:a==null?void 0:a.scene})):[]}}const Ji="interactive-story-editor-last",ho="interactive-story-editor-backup";let qi;const yc="scene1",Wa={title:"Моя первая интерактивная книга",startScene:yc,scenes:[{id:"scene1",text:"Ты стоишь на опушке тёмного леса. Ветер шепчет твоё имя...",choices:[{id:"scene1-c1",text:"Попытаться тихо проскользнуть мимо (бросок)",next:"scene2",roll:"1d20+strength",rollTiers:{0:{next:"",effects:""},25:{next:"scene2",effects:"health:-2"},50:{next:"scene2",effects:""},85:{next:"scene3",effects:"gold:5"},100:{next:"scene3",effects:"gold:10,addItem:Трофей:1"}}}]},{id:"scene2",text:"Ты едва избежал опасности...",choices:[]},{id:"scene3",text:"Удача была на твоей стороне!",choices:[]},{id:"dialog1",text:`Стражник смотрит на тебя подозрительно.
— Ты кто такой? Что тебе здесь нужно?`,isDialogue:!0,npcName:"Стражник",choices:[{id:"dialog1-a1",text:"Я просто прохожий.",next:""},{id:"dialog1-a2",text:"Мне нужно пройти. (убедить)",next:"",roll:"1d20+strength",rollTiers:{0:{next:"",effects:""},25:{next:""},50:{next:"dialog_success"},85:{next:"dialog_success"},100:{next:"dialog_success"}}},{id:"dialog1-a3",text:"А тебе какое дело? (грубость)",next:"",effects:"health:-10"},{id:"dialog1-a4",text:"Я ищу вора, который украл мой кошелёк. (скрытый ответ)",next:"",condition:"gold < 5"},{id:"dialog1-a5",text:"Уйти молча.",next:""},{id:"dialog1-a6",text:"Хорошо, я подожду.",next:"",npcLineIndex:1},{id:"dialog1-a7",text:"Извини, я просто пошутил.",next:"dialog_success",npcLineIndex:1}],npcResponses:[{id:"dialog1-r1",text:`Стражник прищуривается и подходит ближе:
— Не похоже на правду. Говори толком.`,condition:"",npcName:"Стражник"},{id:"dialog1-r2",text:`Второй стражник (подходя сзади):
— А я тут как раз ищу кого-нибудь для разговора.`,condition:"",npcName:"Второй стражник"}]},{id:"dialog_success",text:"Стражник кивает и пропускает тебя.",choices:[]},{id:"dialog_thief",text:"Стражник хмурится: — Мы уже ищем этого негодяя. Проходи.",choices:[]}],variables:{health:100,gold:10,strength:5},items:{Факел:1,Кинжал:1},variableOrigins:{},itemOrigins:{},suggestedVariables:["health","gold","strength"],suggestedItems:["Факел","Кинжал","Трофей"],suggestedNpcNames:["Стражник","Второй стражник"],suggestedEmotions:["злой","радостный","грустный","спокойный","испуганный","насмешливый"],characterName:"",characterDescription:"",deletedScenes:[]};function _c(){let e;try{const n=localStorage.getItem(Ji);e=Ir(JSON.parse(n||JSON.stringify(Wa)))}catch{e=Ir(JSON.parse(JSON.stringify(Wa)))}const t=Xr(e);return t.subscribe(n=>{try{localStorage.setItem(Ji,JSON.stringify(n,null,2))}catch{}}),qi=setInterval(()=>{try{const n=localStorage.getItem(Ji);n&&localStorage.setItem(ho,n)}catch{}},5e3),t}function wc(){qi!==void 0&&(clearInterval(qi),qi=void 0)}const st=_c(),Pt=Xr("scene1");st.subscribe(e=>{var n;const t=Er(Pt);e.scenes.some(i=>i.id===t)||Pt.set(e.startScene||((n=e.scenes[0])==null?void 0:n.id)||"scene1")});function Na(){localStorage.removeItem(Ji);const e=Ir(JSON.parse(JSON.stringify(Wa)));st.set(e),Pt.set("scene1")}function ka(){try{const e=localStorage.getItem(ho);if(!e){alert("❌ Бэкап ещё не создан (подожди хотя бы 5 секунд)");return}const t=JSON.parse(e),n=Ir(t);st.set(n),Pt.set(n.startScene),alert("✅ Восстановлено из автобэкапа (5-секундной давности)")}catch{alert("❌ Ошибка восстановления бэкапа")}}function vt(e){st.update(e)}function oa(e){vt(t=>({...t,scenes:e(t.scenes)}))}function dt(e,t){oa(n=>n.map(i=>i.id===e?t(i):i))}function Pn(e,t,n){dt(e,i=>({...i,choices:i.choices.map((s,a)=>a===t?n(s):s)}))}function Sc(e){oa(t=>[...t,e])}function Ic(e,t){oa(n=>{const i=n.findIndex(a=>a.id===e);if(i===-1)return[...n,t];const s=[...n];return s.splice(i+1,0,t),s})}function Dc(e){vt(t=>{const n=t.scenes.findIndex(c=>c.id===e);if(n===-1||t.scenes.length<=1)return t;const i=t.scenes[n],s={scene:JSON.parse(JSON.stringify(i)),originalIndex:n},a=t.scenes.filter((c,p)=>p!==n),o=Array.isArray(t.deletedScenes)?t.deletedScenes:[];let u=t.startScene;return t.startScene===e&&a.length>0&&(u=a[0].id),{...t,scenes:a,startScene:u,deletedScenes:[...o,s]}})}function Ec(e){vt(t=>{const n=Array.isArray(t.deletedScenes)?[...t.deletedScenes]:[];if(e<0||e>=n.length)return t;const[i]=n.splice(e,1),s=JSON.parse(JSON.stringify(i.scene)),a=[...t.scenes];let o=i.originalIndex;return o>a.length&&(o=a.length),o<0&&(o=0),a.splice(o,0,s),{...t,scenes:a,deletedScenes:n}})}function Tc(e){vt(t=>{const n=Array.isArray(t.deletedScenes)?t.deletedScenes:[];return e<0||e>=n.length?t:{...t,deletedScenes:n.filter((i,s)=>s!==e)}})}function Rs(e,t,n){const i=n.filter(s=>!String((s==null?void 0:s.id)||"").startsWith("dnd-shadow-placeholder"));dt(e,s=>{const a=t||0,o=b=>(b.npcLineIndex??0)===a,u=s.choices.filter(b=>!o(b)),c=u.filter(b=>(b.npcLineIndex??0)<a),p=u.filter(b=>(b.npcLineIndex??0)>a),g=new Set,I=i.map((b,h)=>{let E=b.id||`${e}-c${Date.now().toString(36)}-${h}`,F=0;for(;g.has(E);)F+=1,E=`${b.id||e+"-c"+h}-fix${F}`;return g.add(E),{...b,id:E}});return{...s,choices:[...c,...I,...p]}})}function Ls(e,t){dt(e,n=>{if(!n.npcResponses||n.npcResponses.length===0)return n;const i=n.npcResponses,s=new Map;i.forEach((c,p)=>{const g=p+1,I=t.findIndex(b=>b.id&&b.id===c.id||b===c);I>=0&&s.set(g,I+1)});const a=n.choices.map(c=>{if(c.npcLineIndex===void 0||c.npcLineIndex<=0)return c;const p=s.get(c.npcLineIndex);return p!==void 0&&p!==c.npcLineIndex?{...c,npcLineIndex:p}:c}),o=new Set,u=t.map((c,p)=>{let g=c.id||`${e}-nr${p}`,I=0;for(;o.has(g);)I+=1,g=`${c.id||e+"-nr"+p}-fix${I}`;return o.add(g),{...c,id:g}});return{...n,npcResponses:u,choices:a}})}function Ps(e,t){const n={...t,id:t.id||`${e}-c${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`};dt(e,i=>({...i,choices:[...i.choices,n]}))}function Oc(e,t){const n={...t,id:t.id||`${e}-c${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`};dt(e,i=>({...i,choices:[...i.choices,n]}))}const xo="kniga-engine-editor-ui",yo="kniga-engine-collapses",_o="kniga-engine-answer-buffer";function Nc(e){return JSON.stringify(e)}function kc(e){if(!e)return{};try{return JSON.parse(e)}catch{return{}}}function Ac(e){try{localStorage.setItem(xo,Nc(e))}catch{}}function Cc(){try{const e=localStorage.getItem(xo);return kc(e)}catch{return{}}}function es(e,t){try{const n={starting:Array.from(e.entries()),npc:Array.from(t)};localStorage.setItem(yo,JSON.stringify(n))}catch{}}function ts(){try{const e=localStorage.getItem(yo);if(!e)return{starting:[],npc:[]};const t=JSON.parse(e);return{starting:t.starting||[],npc:t.npc||[]}}catch{return{starting:[],npc:[]}}}function zc(e){try{localStorage.setItem(_o,JSON.stringify(e))}catch{}}function Rc(){try{const e=localStorage.getItem(_o);let t=e?JSON.parse(e):[];if(!Array.isArray(t))return[];const n=new Set;return t.filter(i=>!i||!i.id||n.has(i.id)?!1:(n.add(i.id),!0))}catch{return[]}}function Lc(e,t){dt(e,n=>({...n,choices:n.choices.filter((i,s)=>s!==t)}))}function Pc(e,t){dt(e,n=>{if(!n.npcResponses||t<0||t>=n.npcResponses.length)return n;const i=[...n.npcResponses];i.splice(t,1);const s=n.choices.map(a=>a.npcLineIndex===void 0?a:a.npcLineIndex===t+1?null:a.npcLineIndex>t+1?{...a,npcLineIndex:a.npcLineIndex-1}:a).filter(Boolean);return{...n,npcResponses:i,choices:s}})}function Mc(e,t){dt(e,n=>{const s={...n.choices[t],id:`${e}-c${Date.now().toString(36)}-dup-${Math.random().toString(36).slice(2,8)}`};return{...n,choices:[...n.choices,s]}})}function Fc(e,t){!e||!t||e===t||(oa(n=>n.map(i=>{if(i.id===e)return{...i,id:t};const s=i.choices.map(a=>{let o={...a};if(a.next===e&&(o.next=t),a.onSuccess===e&&(o.onSuccess=t),a.onFail===e&&(o.onFail=t),o.rollTiers){const u={};for(const[c,p]of Object.entries(o.rollTiers))u[c]={...p},p.next===e&&(u[c].next=t);o.rollTiers=u}return o});return{...i,choices:s}})),vt(n=>n.startScene===e?{...n,startScene:t}:n),vt(n=>{let i=!1;const s={...n.variableOrigins||{}};for(const[o,u]of Object.entries(s))u===e&&(s[o]=t,i=!0);const a={...n.itemOrigins||{}};for(const[o,u]of Object.entries(a))u===e&&(a[o]=t,i=!0);return i?{...n,variableOrigins:s,itemOrigins:a}:n}))}function Fi(e){e&&vt(t=>({...t,suggestedVariables:[...t.suggestedVariables||[],e]}))}function Ms(e){e&&vt(t=>({...t,suggestedItems:[...t.suggestedItems||[],e]}))}function Fs(e){e&&vt(t=>{const n=t.suggestedNpcNames||[];return n.includes(e)?t:{...t,suggestedNpcNames:[...n,e]}})}function Vs(e){e&&vt(t=>{const n=t.suggestedEmotions||[];return n.includes(e)?t:{...t,suggestedEmotions:[...n,e]}})}function Wn(e){vt(t=>{const n={...t.items||{}},i=e(n);return{...t,items:i}})}function ir(e){vt(t=>{const n={...t.variables||{}},i=e(n);return{...t,variables:i}})}function Vc(e,t,n){!e||!n||vt(i=>{const s={...i.variables||{},[e]:t},a={...i.variableOrigins||{},[e]:n},o=(i.suggestedVariables||[]).includes(e)?i.suggestedVariables:[...i.suggestedVariables||[],e];return{...i,variables:s,variableOrigins:a,suggestedVariables:o}})}function jc(e,t,n){!e||!n||vt(i=>{const s={...i.items||{},[e]:t},a={...i.itemOrigins||{},[e]:n},o=(i.suggestedItems||[]).includes(e)?i.suggestedItems:[...i.suggestedItems||[],e];return{...i,items:s,itemOrigins:a,suggestedItems:o}})}function Wc(e,t){if(!e||!t)return;const n=t.trim();!n||n===e||vt(i=>{const s={...i.variables||{}};if(!(e in s))return i;const a=s[e];delete s[e],s[n]=a;const o={...i.variableOrigins||{}};o[e]!==void 0&&(o[n]=o[e],delete o[e]);let u=[...i.suggestedVariables||[]];const c=u.indexOf(e);return c!==-1&&(u[c]=n),{...i,variables:s,variableOrigins:o,suggestedVariables:u}})}function Hc(e,t){if(!e||!t)return;const n=t.trim();!n||n===e||vt(i=>{const s={...i.items||{}};if(!(e in s))return i;const a=s[e];delete s[e],s[n]=a;const o={...i.itemOrigins||{}};o[e]!==void 0&&(o[n]=o[e],delete o[e]);let u=[...i.suggestedItems||[]];const c=u.indexOf(e);return c!==-1&&(u[c]=n),{...i,items:s,itemOrigins:o,suggestedItems:u}})}function Uc(e){e&&(ir(t=>{const n={...t};return delete n[e],n}),vt(t=>{if(!t.variableOrigins)return t;const n={...t.variableOrigins};delete n[e];const i=(t.suggestedVariables||[]).filter(s=>s!==e);return{...t,variableOrigins:n,suggestedVariables:i}}))}function Gc(e){e&&(Wn(t=>{const n={...t};return delete n[e],n}),vt(t=>{if(!t.itemOrigins)return t;const n={...t.itemOrigins};delete n[e];const i=(t.suggestedItems||[]).filter(s=>s!==e);return{...t,itemOrigins:n,suggestedItems:i}}))}function wo(e,t){if(!t){Wn(n=>({...n,...e}));return}vt(n=>{const i={...n.items||{}},s={...n.itemOrigins||{}},a=[...n.suggestedItems||[]];let o=!1;for(const[u,c]of Object.entries(e))!(u in i)&&(s[u]=t,a.includes(u)||a.push(u),o=!0),i[u]!==c&&(i[u]=c,o=!0);return o?{...n,items:i,itemOrigins:s,suggestedItems:a}:n})}function So(e,t){if(!t){ir(n=>({...n,...e}));return}vt(n=>{const i={...n.variables||{}},s={...n.variableOrigins||{}},a=[...n.suggestedVariables||[]];let o=!1;for(const[u,c]of Object.entries(e))!(u in i)&&(s[u]=t,a.includes(u)||a.push(u),o=!0),i[u]!==c&&(i[u]=c,o=!0);return o?{...n,variables:i,variableOrigins:s,suggestedVariables:a}:n})}function Yc(){vt(e=>{var u;const t=e.startScene||(((u=e.scenes[0])==null?void 0:u.id)??""),n=e.scenes.findIndex(c=>c.id===t),i={},s={},a={},o={};return Object.entries(e.variables||{}).forEach(([c,p])=>{var I;const g=(I=e.variableOrigins)==null?void 0:I[c];if(!g)i[c]=p;else{const b=e.scenes.findIndex(h=>h.id===g);b>=0&&b<=n&&(i[c]=p,s[c]=g)}}),Object.entries(e.items||{}).forEach(([c,p])=>{var I;const g=(I=e.itemOrigins)==null?void 0:I[c];if(!g)a[c]=p;else{const b=e.scenes.findIndex(h=>h.id===g);b>=0&&b<=n&&(a[c]=p,o[c]=g)}}),{...e,variables:i,items:a,variableOrigins:s,itemOrigins:o}})}const hi=Xr(Rc());hi.subscribe(e=>{try{zc(e||[])}catch{}});const Si=Xr(new Map(ts().starting||[]));Si.subscribe(e=>{try{es(e,Er(Ii))}catch{}});const Ii=Xr(new Set(ts().npc||[]));Ii.subscribe(e=>{try{es(Er(Si),e)}catch{}});function Bc(e,t,n,i){if(typeof t=="function"?e!==t||!i:!t.has(e))throw new TypeError("Cannot read private member from an object whose class did not declare it");return n==="m"?i:n==="a"?i.call(e):i?i.value:t.get(e)}function Jc(e,t,n,i,s){if(typeof t=="function"?e!==t||!0:!t.has(e))throw new TypeError("Cannot write private member to an object whose class did not declare it");return t.set(e,n),n}var Zi;const xn="__TAURI_TO_IPC_KEY__";function qc(e,t=!1){return window.__TAURI_INTERNALS__.transformCallback(e,t)}async function z(e,t={},n){return window.__TAURI_INTERNALS__.invoke(e,t,n)}class Zc{get rid(){return Bc(this,Zi,"f")}constructor(t){Zi.set(this,void 0),Jc(this,Zi,t)}async close(){return z("plugin:resources|close",{rid:this.rid})}}Zi=new WeakMap;var js;(function(e){e[e.Audio=1]="Audio",e[e.Cache=2]="Cache",e[e.Config=3]="Config",e[e.Data=4]="Data",e[e.LocalData=5]="LocalData",e[e.Document=6]="Document",e[e.Download=7]="Download",e[e.Picture=8]="Picture",e[e.Public=9]="Public",e[e.Video=10]="Video",e[e.Resource=11]="Resource",e[e.Temp=12]="Temp",e[e.AppConfig=13]="AppConfig",e[e.AppData=14]="AppData",e[e.AppLocalData=15]="AppLocalData",e[e.AppCache=16]="AppCache",e[e.AppLog=17]="AppLog",e[e.Desktop=18]="Desktop",e[e.Executable=19]="Executable",e[e.Font=20]="Font",e[e.Home=21]="Home",e[e.Runtime=22]="Runtime",e[e.Template=23]="Template"})(js||(js={}));var Ws;(function(e){e[e.Start=0]="Start",e[e.Current=1]="Current",e[e.End=2]="End"})(Ws||(Ws={}));async function Kc(e,t){if(e instanceof URL&&e.protocol!=="file:")throw new TypeError("Must be a file URL.");const n=await z("plugin:fs|read_text_file",{path:e instanceof URL?e.toString():e,options:t}),i=n instanceof ArrayBuffer?n:Uint8Array.from(n);return new TextDecoder().decode(i)}async function Aa(e,t,n){if(e instanceof URL&&e.protocol!=="file:")throw new TypeError("Must be a file URL.");const i=new TextEncoder;await z("plugin:fs|write_text_file",i.encode(t),{headers:{path:encodeURIComponent(e instanceof URL?e.toString():e),options:JSON.stringify(n)}})}async function Xc(e={}){return typeof e=="object"&&Object.freeze(e),await z("plugin:dialog|open",{options:e})}async function Ca(e={}){return typeof e=="object"&&Object.freeze(e),await z("plugin:dialog|save",{options:e})}function Hs(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);t&&(i=i.filter(function(s){return Object.getOwnPropertyDescriptor(e,s).enumerable})),n.push.apply(n,i)}return n}function Qi(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]!=null?arguments[t]:{};t%2?Hs(Object(n),!0).forEach(function(i){Gr(e,i,n[i])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Hs(Object(n)).forEach(function(i){Object.defineProperty(e,i,Object.getOwnPropertyDescriptor(n,i))})}return e}function Wr(e){"@babel/helpers - typeof";return Wr=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Wr(e)}function Gr(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Qc(e,t){if(e==null)return{};var n={},i=Object.keys(e),s,a;for(a=0;a<i.length;a++)s=i[a],!(t.indexOf(s)>=0)&&(n[s]=e[s]);return n}function $c(e,t){if(e==null)return{};var n=Qc(e,t),i,s;if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(s=0;s<a.length;s++)i=a[s],!(t.indexOf(i)>=0)&&Object.prototype.propertyIsEnumerable.call(e,i)&&(n[i]=e[i])}return n}function eu(e,t){return nu(e)||iu(e,t)||ns(e,t)||su()}function hn(e){return tu(e)||ru(e)||ns(e)||au()}function tu(e){if(Array.isArray(e))return Ha(e)}function nu(e){if(Array.isArray(e))return e}function ru(e){if(typeof Symbol<"u"&&e[Symbol.iterator]!=null||e["@@iterator"]!=null)return Array.from(e)}function iu(e,t){var n=e==null?null:typeof Symbol<"u"&&e[Symbol.iterator]||e["@@iterator"];if(n!=null){var i=[],s=!0,a=!1,o,u;try{for(n=n.call(e);!(s=(o=n.next()).done)&&(i.push(o.value),!(t&&i.length===t));s=!0);}catch(c){a=!0,u=c}finally{try{!s&&n.return!=null&&n.return()}finally{if(a)throw u}}return i}}function ns(e,t){if(e){if(typeof e=="string")return Ha(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if(n==="Object"&&e.constructor&&(n=e.constructor.name),n==="Map"||n==="Set")return Array.from(e);if(n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return Ha(e,t)}}function Ha(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,i=new Array(t);n<t;n++)i[n]=e[n];return i}function au(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function su(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Ti(e,t){var n=typeof Symbol<"u"&&e[Symbol.iterator]||e["@@iterator"];if(!n){if(Array.isArray(e)||(n=ns(e))||t){n&&(e=n);var i=0,s=function(){};return{s,n:function(){return i>=e.length?{done:!0}:{done:!1,value:e[i++]}},e:function(c){throw c},f:s}}throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var a=!0,o=!1,u;return{s:function(){n=n.call(e)},n:function(){var c=n.next();return a=c.done,c},e:function(c){o=!0,u=c},f:function(){try{!a&&n.return!=null&&n.return()}finally{if(o)throw u}}}}var ou="finalize",lu="consider";function Yr(e,t,n){e.dispatchEvent(new CustomEvent(ou,{detail:{items:t,info:n}}))}function or(e,t,n){e.dispatchEvent(new CustomEvent(lu,{detail:{items:t,info:n}}))}var la="draggedEntered",Oi="draggedLeft",ca="draggedOverIndex",rs="draggedLeftDocument",$i={LEFT_FOR_ANOTHER:"leftForAnother",OUTSIDE_OF_ANY:"outsideOfAny"};function cu(e,t,n){e.dispatchEvent(new CustomEvent(la,{detail:{indexObj:t,draggedEl:n}}))}function uu(e,t,n){e.dispatchEvent(new CustomEvent(Oi,{detail:{draggedEl:t,type:$i.LEFT_FOR_ANOTHER,theOtherDz:n}}))}function du(e,t){e.dispatchEvent(new CustomEvent(Oi,{detail:{draggedEl:t,type:$i.OUTSIDE_OF_ANY}}))}function fu(e,t,n){e.dispatchEvent(new CustomEvent(ca,{detail:{indexObj:t,draggedEl:n}}))}function vu(e){window.dispatchEvent(new CustomEvent(rs,{detail:{draggedEl:e}}))}var Bt={DRAG_STARTED:"dragStarted",DRAGGED_ENTERED:la,DRAGGED_ENTERED_ANOTHER:"dragEnteredAnother",DRAGGED_OVER_INDEX:ca,DRAGGED_LEFT:Oi,DRAGGED_LEFT_ALL:"draggedLeftAll",DROPPED_INTO_ZONE:"droppedIntoZone",DROPPED_INTO_ANOTHER:"droppedIntoAnother",DROPPED_OUTSIDE_OF_ANY:"droppedOutsideOfAny",DRAG_STOPPED:"dragStopped"},$t={POINTER:"pointer",KEYBOARD:"keyboard"},ua="isDndShadowItem",da="data-is-dnd-shadow-item-internal",gu="data-is-dnd-shadow-item-hint",Io="id:dnd-shadow-placeholder-0000",mu="dnd-action-dragged-el",wt="id",Ua=0;function Do(){Ua++}function Eo(){if(Ua===0)throw new Error("Bug! trying to decrement when there are no dropzones");Ua--}var is=typeof window>"u";function Ga(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0,n,i=t?hu(e):e.getBoundingClientRect(),s=getComputedStyle(e),a=s.transform;if(a){var o,u,c,p;if(a.startsWith("matrix3d("))n=a.slice(9,-1).split(/, /),o=+n[0],u=+n[5],c=+n[12],p=+n[13];else if(a.startsWith("matrix("))n=a.slice(7,-1).split(/, /),o=+n[0],u=+n[3],c=+n[4],p=+n[5];else return i;var g=s.transformOrigin,I=i.x-c-(1-o)*parseFloat(g),b=i.y-p-(1-u)*parseFloat(g.slice(g.indexOf(" ")+1)),h=o?i.width/o:e.offsetWidth,E=u?i.height/u:e.offsetHeight;return{x:I,y:b,width:h,height:E,top:b,right:I+h,bottom:b+E,left:I}}else return i}function Ya(e){var t=Ga(e);return{top:t.top+window.scrollY,bottom:t.bottom+window.scrollY,left:t.left+window.scrollX,right:t.right+window.scrollX}}function To(e){var t=e.getBoundingClientRect();return{top:t.top+window.scrollY,bottom:t.bottom+window.scrollY,left:t.left+window.scrollX,right:t.right+window.scrollX}}function Oo(e){return{x:(e.left+e.right)/2,y:(e.top+e.bottom)/2}}function pu(e,t){return Math.sqrt(Math.pow(e.x-t.x,2)+Math.pow(e.y-t.y,2))}function xi(e,t){return e.y<=t.bottom&&e.y>=t.top&&e.x>=t.left&&e.x<=t.right}function No(e){return Oo(To(e))}function Us(e,t){var n=No(t);return pu(e,n)}function bu(e){var t=To(e);return t.right<0||t.left>document.documentElement.scrollWidth||t.bottom<0||t.top>document.documentElement.scrollHeight}function hu(e){for(var t=e.getBoundingClientRect(),n={top:t.top,bottom:t.bottom,left:t.left,right:t.right},i=!1,s=!1,a=e.parentElement;a&&a!==document.body;){var o=window.getComputedStyle(a),u=o.overflowY,c=o.overflowX,p=u==="scroll"||u==="auto",g=c==="scroll"||c==="auto";if(p||g){var I=a.getBoundingClientRect();if(p){var b=Math.max(n.top,I.top),h=Math.min(n.bottom,I.bottom);(b!==n.top||h!==n.bottom)&&(i=!0),n.top=b,n.bottom=h}if(g){var E=Math.max(n.left,I.left),F=Math.min(n.right,I.right);(E!==n.left||F!==n.right)&&(s=!0),n.left=E,n.right=F}}a=a.parentElement}return i||s?{top:n.top,bottom:n.bottom,left:n.left,right:n.right,width:Math.max(0,n.right-n.left),height:Math.max(0,n.bottom-n.top)}:{top:t.top,bottom:t.bottom,left:t.left,right:t.right,width:Math.max(0,t.right-t.left),height:Math.max(0,t.bottom-t.top)}}var Hr;function as(){Hr=new Map}as();function xu(e){var t=Array.from(e.children).findIndex(function(n){return n.getAttribute(da)});if(t>=0)return Hr.has(e)||Hr.set(e,new Map),Hr.get(e).set(t,Ya(e.children[t])),t}function yu(e,t){var n=Ya(t);if(!xi(e,n))return null;var i=t.children;if(i.length===0)return{index:0,isProximityBased:!0};for(var s=xu(t),a=0;a<i.length;a++){var o=Ya(i[a]);if(xi(e,o)){var u=Hr.has(t)&&Hr.get(t).get(a);return u&&!xi(e,u)?{index:s,isProximityBased:!1}:{index:a,isProximityBased:!1}}}for(var c=Number.MAX_VALUE,p=void 0,g=0;g<i.length;g++){var I=Us(e,i[g]);I<c&&(c=I,p=g)}if(i.length>0){var b=i.length,h=i[b-1],E=h.cloneNode(!1);E.style.visibility="hidden",E.style.pointerEvents="none",t.appendChild(E);var F=Us(e,E);F<c&&(p=b),t.removeChild(E)}return{index:p,isProximityBased:!0}}function vi(e){return JSON.stringify(e,null,2)}function ea(e){if(!e)throw new Error("cannot get depth of a falsy node");return ko(e,0)}function ko(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:0;return e.parentElement?ko(e.parentElement,t+1):t-1}function _u(e,t){if(Object.keys(e).length!==Object.keys(t).length)return!1;for(var n in e)if(!{}.hasOwnProperty.call(t,n)||t[n]!==e[n])return!1;return!0}function wu(e,t){if(e.length!==t.length)return!1;for(var n=0;n<e.length;n++)if(e[n]!==t[n])return!1;return!0}var Su=200,Gs=10,Ba;function Iu(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:Su,i=arguments.length>3?arguments[3]:void 0,s=arguments.length>4?arguments[4]:void 0,a,o,u=!1,c,p=Array.from(t).sort(function(I,b){return ea(b)-ea(I)});function g(){var I=s(),b=i.multiScrollIfNeeded();if(!b&&c&&Math.abs(c.x-I.x)<Gs&&Math.abs(c.y-I.y)<Gs){Ba=window.setTimeout(g,n);return}if(bu(e)){vu(e);return}c=I;var h=!1,E=Ti(p),F;try{for(E.s();!(F=E.n()).done;){var T=F.value;b&&as();var C=yu(I,T);if(C!==null){var V=C.index;h=!0,T!==a?(a&&uu(a,e,T),cu(T,C,e),a=T):V!==o&&(fu(T,C,e),o=V);break}}}catch(Y){E.e(Y)}finally{E.f()}!h&&u&&a?(du(a,e),a=void 0,o=void 0,u=!1):u=!0,Ba=window.setTimeout(g,n)}g()}function Du(){clearTimeout(Ba),as()}var gi=30;function Eu(){var e;function t(){e={directionObj:void 0,stepPx:0}}t();function n(a){var o=e,u=o.directionObj,c=o.stepPx;u&&(a.scrollBy(u.x*c,u.y*c),window.requestAnimationFrame(function(){return n(a)}))}function i(a){return gi-a}function s(a,o){if(!o)return!1;var u=Tu(a,o),c=!!e.directionObj;if(u===null)return c&&t(),!1;var p=!1,g=!1;return o.scrollHeight>o.clientHeight&&(u.bottom<gi?(p=!0,e.directionObj={x:0,y:1},e.stepPx=i(u.bottom)):u.top<gi&&(p=!0,e.directionObj={x:0,y:-1},e.stepPx=i(u.top)),!c&&p)||o.scrollWidth>o.clientWidth&&(u.right<gi?(g=!0,e.directionObj={x:1,y:0},e.stepPx=i(u.right)):u.left<gi&&(g=!0,e.directionObj={x:-1,y:0},e.stepPx=i(u.left)),!c&&g)?(n(o),!0):(t(),!1)}return{scrollIfNeeded:s,resetScrolling:t}}function Tu(e,t){var n=t===document.scrollingElement?{top:0,bottom:window.innerHeight,left:0,right:window.innerWidth}:t.getBoundingClientRect();return xi(e,n)?{top:e.y-n.top,bottom:n.bottom-e.y,left:e.x-n.left,right:n.right-e.x}:null}function Ou(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:[],t=arguments.length>1?arguments[1]:void 0,n=ku(e),i=Array.from(n).sort(function(c,p){return ea(p)-ea(c)}),s=Eu(),a=s.scrollIfNeeded,o=s.resetScrolling;function u(){var c=t();if(!c||!i)return!1;for(var p=i.filter(function(b){return xi(c,b.getBoundingClientRect())||b===document.scrollingElement}),g=0;g<p.length;g++){var I=a(c,p[g]);if(I)return!0}return!1}return{multiScrollIfNeeded:n.size>0?u:function(){return!1},destroy:function(){return o()}}}function Nu(e){if(!e)return[];for(var t=[],n=e;n;){var i=window.getComputedStyle(n),s=i.overflow;s.split(" ").some(function(a){return a.includes("auto")||a.includes("scroll")})&&t.push(n),n=n.parentElement}return t}function ku(e){var t=new Set,n=Ti(e),i;try{for(n.s();!(i=n.n()).done;){var s=i.value;Nu(s).forEach(function(a){return t.add(a)})}}catch(a){n.e(a)}finally{n.f()}return(document.scrollingElement.scrollHeight>document.scrollingElement.clientHeight||document.scrollingElement.scrollWidth>document.scrollingElement.clientHeight)&&t.add(document.scrollingElement),t}function Au(e){var t=e.cloneNode(!0),n=[],i=e.tagName==="SELECT",s=i?[e]:hn(e.querySelectorAll("select")),a=Ti(s),o;try{for(a.s();!(o=a.n()).done;){var u=o.value;n.push(u.value)}}catch(Y){a.e(Y)}finally{a.f()}if(s.length>0)for(var c=i?[t]:hn(t.querySelectorAll("select")),p=0;p<c.length;p++){var g=c[p],I=n[p],b=g.querySelector('option[value="'.concat(I,'"'));b&&b.setAttribute("selected",!0)}var h=e.tagName==="CANVAS",E=h?[e]:hn(e.querySelectorAll("canvas"));if(E.length>0)for(var F=h?[t]:hn(t.querySelectorAll("canvas")),T=0;T<F.length;T++){var C=E[T],V=F[T];V.width=C.width,V.height=C.height,C.width>0&&C.height>0&&V.getContext("2d").drawImage(C,0,0)}return t}var Di=Object.freeze({USE_COMPUTED_STYLE_INSTEAD_OF_BOUNDING_RECT:"USE_COMPUTED_STYLE_INSTEAD_OF_BOUNDING_RECT"}),Cu=Gr({},Di.USE_COMPUTED_STYLE_INSTEAD_OF_BOUNDING_RECT,!1);function Ao(e){if(!Di[e])throw new Error("Can't get non existing feature flag ".concat(e,"! Supported flags: ").concat(Object.keys(Di)));return Cu[e]}var zu=.2;function wr(e){return"".concat(e," ").concat(zu,"s ease")}function Ru(e,t){var n=e.getBoundingClientRect(),i=Au(e);Co(e,i),i.id=mu,i.style.position="fixed";var s=n.top,a=n.left;if(i.style.top="".concat(s,"px"),i.style.left="".concat(a,"px"),t){var o=Oo(n);s-=o.y-t.y,a-=o.x-t.x,window.setTimeout(function(){i.style.top="".concat(s,"px"),i.style.left="".concat(a,"px")},0)}return i.style.margin="0",i.style.boxSizing="border-box",i.style.height="".concat(n.height,"px"),i.style.width="".concat(n.width,"px"),i.style.transition="".concat(wr("top"),", ").concat(wr("left"),", ").concat(wr("background-color"),", ").concat(wr("opacity"),", ").concat(wr("color")," "),window.setTimeout(function(){return i.style.transition+=", ".concat(wr("width"),", ").concat(wr("height"))},0),i.style.zIndex="9999",i.style.cursor="grabbing",i}function Lu(e){e.style.cursor="grab"}function Pu(e,t,n,i){Co(t,e);var s=t.getBoundingClientRect(),a=e.getBoundingClientRect(),o=s.width-a.width,u=s.height-a.height;if(o||u){var c={left:(n-a.left)/a.width,top:(i-a.top)/a.height};Ao(Di.USE_COMPUTED_STYLE_INSTEAD_OF_BOUNDING_RECT)||(e.style.height="".concat(s.height,"px"),e.style.width="".concat(s.width,"px")),e.style.left="".concat(parseFloat(e.style.left)-c.left*o,"px"),e.style.top="".concat(parseFloat(e.style.top)-c.top*u,"px")}}function Co(e,t){var n=window.getComputedStyle(e);Array.from(n).filter(function(i){return i.startsWith("background")||i.startsWith("padding")||i.startsWith("font")||i.startsWith("text")||i.startsWith("align")||i.startsWith("justify")||i.startsWith("display")||i.startsWith("flex")||i.startsWith("border")||i==="opacity"||i==="color"||i==="list-style-type"||Ao(Di.USE_COMPUTED_STYLE_INSTEAD_OF_BOUNDING_RECT)&&(i==="width"||i==="height")}).forEach(function(i){return t.style.setProperty(i,n.getPropertyValue(i),n.getPropertyPriority(i))})}function Mu(e,t){e.draggable=!1,e.ondragstart=function(){return!1},t?(e.style.userSelect="",e.style.WebkitUserSelect="",e.style.cursor=""):(e.style.userSelect="none",e.style.WebkitUserSelect="none",e.style.cursor="grab")}function zo(e){e.style.display="none",e.style.position="fixed",e.style.zIndex="-5"}function Fu(e){e.style.visibility="hidden",e.setAttribute(da,"true")}function Vu(e){e.style.visibility="",e.removeAttribute(da)}function Ki(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:function(){},n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:function(){return[]};e.forEach(function(i){var s=t(i);Object.keys(s).forEach(function(a){i.style[a]=s[a]}),n(i).forEach(function(a){return i.classList.add(a)})})}function ta(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:function(){},n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:function(){return[]};e.forEach(function(i){var s=t(i);Object.keys(s).forEach(function(a){i.style[a]=""}),n(i).forEach(function(a){return i.classList.contains(a)&&i.classList.remove(a)})})}function ju(e){var t=e.style.minHeight;e.style.minHeight=window.getComputedStyle(e).getPropertyValue("height");var n=e.style.minWidth;return e.style.minWidth=window.getComputedStyle(e).getPropertyValue("width"),function(){e.style.minHeight=t,e.style.minWidth=n}}var Wu="--any--",Hu=100,Uu=20,Vi=3,Gu=80,Ys={outline:"rgba(255, 255, 102, 0.7) solid 2px"},Bs="data-is-dnd-original-dragged-item",Kt,_t,Qt,fa,Ke,va,sr,Nt,Mn,St,tr=!1,ss=!1,os,Ni=!1,Xi=[],yi,Fn,bi=!1,ls=!1,En=new Map,ft=new Map,za=new WeakMap;function Yu(e,t){En.has(t)||En.set(t,new Set),En.get(t).has(e)||(En.get(t).add(e),Do())}function Js(e,t){En.get(t).delete(e),Eo(),En.get(t).size===0&&En.delete(t)}function Bu(){var e=En.get(fa),t=Ti(e),n;try{for(t.s();!(n=t.n()).done;){var i=n.value;i.addEventListener(la,Ro),i.addEventListener(Oi,Lo),i.addEventListener(ca,Po)}}catch(u){t.e(u)}finally{t.f()}window.addEventListener(rs,Br);var s=Math.max.apply(Math,hn(Array.from(e.keys()).map(function(u){return ft.get(u).dropAnimationDurationMs}))),a=s===0?Uu:Math.max(s,Hu);yi=Ou(e,function(){return St});var o=ls?function(){return{x:St.x+window.scrollX,y:St.y+window.scrollY}}:function(){return No(_t)};Iu(_t,e,a*1.07,yi,o)}function Ju(){var e=En.get(fa),t=Ti(e),n;try{for(t.s();!(n=t.n()).done;){var i=n.value;i.removeEventListener(la,Ro),i.removeEventListener(Oi,Lo),i.removeEventListener(ca,Po)}}catch(s){t.e(s)}finally{t.f()}window.removeEventListener(rs,Br),yi&&(yi.destroy(),yi=void 0),Du()}function ga(e){return e.findIndex(function(t){return!!t[ua]})}function qu(e){var t;return Qi(Qi({},e),{},(t={},Gr(t,ua,!0),Gr(t,wt,Io),t))}function Ro(e){var t=ft.get(e.currentTarget),n=t.items,i=t.dropFromOthersDisabled;if(!(i&&e.currentTarget!==Ke)){if(Ni=!1,n=n.filter(function(u){return u[wt]!==sr[wt]&&u[wt]!==Io}),Ke!==e.currentTarget){var s=ft.get(Ke).items,a=s.filter(function(u){return!u[ua]});or(Ke,a,{trigger:Bt.DRAGGED_ENTERED_ANOTHER,id:Qt[wt],source:$t.POINTER})}var o=e.detail.indexObj.index;Nt=e.currentTarget,n.splice(o,0,sr),or(e.currentTarget,n,{trigger:Bt.DRAGGED_ENTERED,id:Qt[wt],source:$t.POINTER})}}function Lo(e){if(tr){var t=ft.get(e.currentTarget),n=t.items,i=t.dropFromOthersDisabled;if(!(i&&e.currentTarget!==Ke&&e.currentTarget!==Nt)){var s=hn(n),a=ga(s);a!==-1&&s.splice(a,1);var o=Nt;Nt=void 0;var u=e.detail,c=u.type,p=u.theOtherDz;if(c===$i.OUTSIDE_OF_ANY||c===$i.LEFT_FOR_ANOTHER&&p!==Ke&&ft.get(p).dropFromOthersDisabled){Ni=!0,Nt=Ke;var g=o===Ke?s:hn(ft.get(Ke).items);g.splice(va,0,sr),or(Ke,g,{trigger:Bt.DRAGGED_LEFT_ALL,id:Qt[wt],source:$t.POINTER})}or(e.currentTarget,s,{trigger:Bt.DRAGGED_LEFT,id:Qt[wt],source:$t.POINTER})}}}function Po(e){var t=ft.get(e.currentTarget),n=t.items,i=t.dropFromOthersDisabled;if(!(i&&e.currentTarget!==Ke)){var s=hn(n);Ni=!1;var a=e.detail.indexObj.index,o=ga(s);o!==-1&&s.splice(o,1),s.splice(a,0,sr),or(e.currentTarget,s,{trigger:Bt.DRAGGED_OVER_INDEX,id:Qt[wt],source:$t.POINTER})}}function na(e){e.preventDefault();var t=e.touches?e.touches[0]:e;St={x:t.clientX,y:t.clientY},_t.style.transform="translate3d(".concat(St.x-Mn.x,"px, ").concat(St.y-Mn.y,"px, 0)")}function Br(){ss=!0,window.removeEventListener("mousemove",na),window.removeEventListener("touchmove",na),window.removeEventListener("mouseup",Br),window.removeEventListener("touchend",Br),Ju(),Lu(_t),Nt||(Nt=Ke);var e=ft.get(Nt),t=e.items,n=e.type;ta(En.get(n),function(a){return ft.get(a).dropTargetStyle},function(a){return ft.get(a).dropTargetClasses});var i=ga(t);i===-1&&Nt===Ke&&(i=va),t=t.map(function(a){return a[ua]?Qt:a});function s(){os(),Yr(Nt,t,{trigger:Ni?Bt.DROPPED_OUTSIDE_OF_ANY:Bt.DROPPED_INTO_ZONE,id:Qt[wt],source:$t.POINTER}),Nt!==Ke&&Yr(Ke,ft.get(Ke).items,{trigger:Bt.DROPPED_INTO_ANOTHER,id:Qt[wt],source:$t.POINTER});var a=Array.from(Nt.children).find(function(o){return o.getAttribute(da)});a&&Vu(a),Xu()}ft.get(Nt).dropAnimationDisabled?s():Zu(i,s)}function Zu(e,t){var n=e>-1?Ga(Nt.children[e],!1):Ga(Nt,!1),i={x:n.left-parseFloat(_t.style.left),y:n.top-parseFloat(_t.style.top)},s=ft.get(Nt),a=s.dropAnimationDurationMs,o="transform ".concat(a,"ms ease");_t.style.transition=_t.style.transition?_t.style.transition+","+o:o,_t.style.transform="translate3d(".concat(i.x,"px, ").concat(i.y,"px, 0)"),window.setTimeout(t,a)}function Ku(e,t){Xi.push({dz:e,destroy:t}),window.requestAnimationFrame(function(){zo(e),document.body.appendChild(e)})}function Xu(){_t&&_t.remove&&_t.remove(),Kt&&Kt.remove&&Kt.remove(),_t=void 0,Kt=void 0,Qt=void 0,fa=void 0,Ke=void 0,va=void 0,sr=void 0,Nt=void 0,Mn=void 0,St=void 0,tr=!1,ss=!1,os=void 0,Ni=!1,Fn&&clearTimeout(Fn),Fn=void 0,bi=!1,ls=!1,Xi.length&&(Xi.forEach(function(e){var t=e.dz,n=e.destroy;n(),t.remove()}),Xi=[])}function Qu(e,t){var n=!1,i={items:void 0,type:void 0,flipDurationMs:0,dragDisabled:!1,morphDisabled:!1,dropFromOthersDisabled:!1,dropTargetStyle:Ys,dropTargetClasses:[],transformDraggedElement:function(){},centreDraggedOnCursor:!1,useCursorForDetection:!1,dropAnimationDisabled:!1,delayTouchStartMs:0},s=new Map;function a(){window.addEventListener("mousemove",c,{passive:!1}),window.addEventListener("touchmove",c,{passive:!1,capture:!1}),window.addEventListener("mouseup",u,{passive:!1}),window.addEventListener("touchend",u,{passive:!1})}function o(){window.removeEventListener("mousemove",c),window.removeEventListener("touchmove",c),window.removeEventListener("mouseup",u),window.removeEventListener("touchend",u),Fn&&(clearTimeout(Fn),Fn=void 0,bi=!1)}function u(b){if(o(),Kt=void 0,Mn=void 0,St=void 0,b.type==="touchend"){var h=new Event("click",{bubbles:!0,cancelable:!0});b.target.dispatchEvent(h)}}function c(b){var h=!!b.touches,E=h?b.touches[0]:b;if(h&&i.delayTouchStartMs>0&&!bi){St={x:E.clientX,y:E.clientY},(Math.abs(St.x-Mn.x)>=Vi||Math.abs(St.y-Mn.y)>=Vi)&&(Fn&&(clearTimeout(Fn),Fn=void 0),u(b));return}b.preventDefault(),St={x:E.clientX,y:E.clientY},(Math.abs(St.x-Mn.x)>=Vi||Math.abs(St.y-Mn.y)>=Vi)&&(o(),g())}function p(b){if(!(b.target!==b.currentTarget&&(b.target.value!==void 0||b.target.isContentEditable))&&!b.button&&!tr){var h=!!b.touches,E=h&&i.delayTouchStartMs>0;E||b.preventDefault(),b.stopPropagation();var F=h?b.touches[0]:b;Mn={x:F.clientX,y:F.clientY},St=Qi({},Mn),Kt=b.currentTarget,E&&(bi=!1,Fn=window.setTimeout(function(){Kt&&(bi=!0,o(),g())},i.delayTouchStartMs)),a()}}function g(){tr=!0;var b=s.get(Kt);va=b,Ke=Kt.parentElement;var h=Ke.closest("dialog")||Ke.closest("[popover]")||Ke.getRootNode(),E=h.body||h,F=i.items,T=i.type,C=i.centreDraggedOnCursor,V=i.useCursorForDetection,Y=hn(F);Qt=Y[b],fa=T,sr=qu(Qt),ls=V,_t=Ru(Kt,C&&St),E.appendChild(_t);function Q(){Kt.parentElement?window.requestAnimationFrame(Q):(Kt.setAttribute(Bs,!0),E.appendChild(Kt),Bu(),zo(Kt),sr[wt]=Qt[wt],_t.focus())}window.requestAnimationFrame(Q),Ki(Array.from(En.get(i.type)).filter(function(ye){return ye===Ke||!ft.get(ye).dropFromOthersDisabled}),function(ye){return ft.get(ye).dropTargetStyle},function(ye){return ft.get(ye).dropTargetClasses}),Y.splice(b,1,sr),os=ju(Ke),or(Ke,Y,{trigger:Bt.DRAG_STARTED,id:Qt[wt],source:$t.POINTER}),window.addEventListener("mousemove",na,{passive:!1}),window.addEventListener("touchmove",na,{passive:!1,capture:!1}),window.addEventListener("mouseup",Br,{passive:!1}),window.addEventListener("touchend",Br,{passive:!1})}function I(b){var h=b.items,E=h===void 0?void 0:h,F=b.flipDurationMs,T=F===void 0?0:F,C=b.type,V=C===void 0?Wu:C,Y=b.dragDisabled,Q=Y===void 0?!1:Y,ye=b.morphDisabled,Ne=ye===void 0?!1:ye,_e=b.dropFromOthersDisabled,Ce=_e===void 0?!1:_e,Ve=b.dropTargetStyle,Se=Ve===void 0?Ys:Ve,oe=b.dropTargetClasses,ne=oe===void 0?[]:oe,ae=b.transformDraggedElement,G=ae===void 0?function(){}:ae,P=b.centreDraggedOnCursor,re=P===void 0?!1:P,Z=b.useCursorForDetection,ce=Z===void 0?!1:Z,ee=b.dropAnimationDisabled,De=ee===void 0?!1:ee,je=b.delayTouchStart,Re=je===void 0?!1:je;i.dropAnimationDurationMs=T;var ze=0;Re===!0?ze=Gu:typeof Re=="number"&&isFinite(Re)&&Re>=0&&(ze=Re),i.delayTouchStartMs=ze,i.type&&V!==i.type&&Js(e,i.type),i.type=V,i.items=hn(E),i.dragDisabled=Q,i.morphDisabled=Ne,i.transformDraggedElement=G,i.centreDraggedOnCursor=re,i.useCursorForDetection=ce,i.dropAnimationDisabled=De,n&&tr&&!ss&&(!_u(Se,i.dropTargetStyle)||!wu(ne,i.dropTargetClasses))&&(ta([e],function(){return i.dropTargetStyle},function(){return ne}),Ki([e],function(){return Se},function(){return ne})),i.dropTargetStyle=Se,i.dropTargetClasses=hn(ne);function Xe(ke,gt){return ft.get(ke)?ft.get(ke)[gt]:i[gt]}n&&tr&&i.dropFromOthersDisabled!==Ce&&(Ce?ta([e],function(ke){return Xe(ke,"dropTargetStyle")},function(ke){return Xe(ke,"dropTargetClasses")}):Ki([e],function(ke){return Xe(ke,"dropTargetStyle")},function(ke){return Xe(ke,"dropTargetClasses")})),i.dropFromOthersDisabled=Ce,ft.set(e,i),Yu(e,V);for(var Ue=tr?ga(i.items):-1,Te=0;Te<e.children.length;Te++){var he=e.children[Te];if(Mu(he,Q),Te===Ue){Ne||Pu(_t,he,St.x,St.y),i.transformDraggedElement(_t,Qt,Te),Fu(he);continue}he.removeEventListener("mousedown",za.get(he)),he.removeEventListener("touchstart",za.get(he)),Q||(he.addEventListener("mousedown",p),he.addEventListener("touchstart",p),za.set(he,p)),s.set(he,Te),n||(n=!0)}}return I(t),{update:function(h){I(h)},destroy:function(){function h(){Js(e,ft.get(e).type),ft.delete(e)}tr&&!e.closest("[".concat(Bs,"]"))?Ku(e,h):h()}}}var ji,Ja={DND_ZONE_ACTIVE:"dnd-zone-active",DND_ZONE_DRAG_DISABLED:"dnd-zone-drag-disabled"},Mo=(ji={},Gr(ji,Ja.DND_ZONE_ACTIVE,"Tab to one the items and press space-bar or enter to start dragging it"),Gr(ji,Ja.DND_ZONE_DRAG_DISABLED,"This is a disabled drag and drop list"),ji),$u="dnd-action-aria-alert",xt;function qa(){xt||(xt=document.createElement("div"),(function(){xt.id=$u,xt.style.position="fixed",xt.style.bottom="0",xt.style.left="0",xt.style.zIndex="-5",xt.style.opacity="0",xt.style.height="0",xt.style.width="0",xt.setAttribute("role","alert")})(),document.body.prepend(xt),Object.entries(Mo).forEach(function(e){var t=eu(e,2),n=t[0],i=t[1];return document.body.prepend(nd(n,i))}))}function ed(){return is?null:(document.readyState==="complete"?qa():window.addEventListener("DOMContentLoaded",qa),Qi({},Ja))}function td(){is||!xt||(Object.keys(Mo).forEach(function(e){var t;return(t=document.getElementById(e))===null||t===void 0?void 0:t.remove()}),xt.remove(),xt=void 0)}function nd(e,t){var n=document.createElement("div");return n.id=e,n.innerHTML="<p>".concat(t,"</p>"),n.style.display="none",n.style.position="fixed",n.style.zIndex="-5",n}function Ur(e){if(!is){xt||qa(),xt.innerHTML="";var t=document.createTextNode(e);xt.appendChild(t),xt.style.display="none",xt.style.display="inline"}}var rd="--any--",qs={outline:"rgba(255, 255, 102, 0.7) solid 2px"},mn=!1,Za,Ft,Dr="",Sr,Vn,ar="",ra=new WeakSet,Zs=new WeakMap,Ks=new WeakMap,Ka=new Map,Ot=new Map,Dn=new Map,ia;function id(e,t){Dn.size===0&&(ia=ed(),window.addEventListener("keydown",Fo),window.addEventListener("click",Vo)),Dn.has(t)||Dn.set(t,new Set),Dn.get(t).has(e)||(Dn.get(t).add(e),Do())}function Xs(e,t){Ft===e&&Ei(),Dn.get(t).delete(e),Eo(),Dn.get(t).size===0&&Dn.delete(t),Dn.size===0&&(window.removeEventListener("keydown",Fo),window.removeEventListener("click",Vo),ia=void 0,td())}function Fo(e){if(mn)switch(e.key){case"Escape":{Ei();break}}}function Vo(){mn&&(ra.has(document.activeElement)||Ei())}function ad(e){if(mn){var t=e.currentTarget;if(t!==Ft){Dr=t.getAttribute("aria-label")||"";var n=Ot.get(Ft),i=n.items,s=i.find(function(I){return I[wt]===Vn}),a=i.indexOf(s),o=i.splice(a,1)[0],u=Ot.get(t),c=u.items,p=u.autoAriaDisabled;t.getBoundingClientRect().top<Ft.getBoundingClientRect().top||t.getBoundingClientRect().left<Ft.getBoundingClientRect().left?(c.push(o),p||Ur("Moved item ".concat(ar," to the end of the list ").concat(Dr))):(c.unshift(o),p||Ur("Moved item ".concat(ar," to the beginning of the list ").concat(Dr)));var g=Ft;Yr(g,i,{trigger:Bt.DROPPED_INTO_ANOTHER,id:Vn,source:$t.KEYBOARD}),Yr(t,c,{trigger:Bt.DROPPED_INTO_ZONE,id:Vn,source:$t.KEYBOARD}),Ft=t}}}function jo(){Ka.forEach(function(e,t){var n=e.update;return n(Ot.get(t))})}function Ei(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:!0;Ot.get(Ft).autoAriaDisabled||Ur("Stopped dragging item ".concat(ar)),ra.has(document.activeElement)&&document.activeElement.blur(),e&&or(Ft,Ot.get(Ft).items,{trigger:Bt.DRAG_STOPPED,id:Vn,source:$t.KEYBOARD}),ta(Dn.get(Za),function(t){return Ot.get(t).dropTargetStyle},function(t){return Ot.get(t).dropTargetClasses}),Sr=null,Vn=null,ar="",Za=null,Ft=null,Dr="",mn=!1,jo()}function sd(e,t){var n={items:void 0,type:void 0,dragDisabled:!1,zoneTabIndex:0,zoneItemTabIndex:0,dropFromOthersDisabled:!1,dropTargetStyle:qs,dropTargetClasses:[],autoAriaDisabled:!1};function i(g,I,b){g.length<=1||g.splice(b,1,g.splice(I,1,g[b])[0])}function s(g){switch(g.key){case"Enter":case" ":{if((g.target.disabled!==void 0||g.target.href||g.target.isContentEditable)&&!ra.has(g.target))return;g.preventDefault(),g.stopPropagation(),mn?Ei():a(g);break}case"ArrowDown":case"ArrowRight":{if(!mn)return;g.preventDefault(),g.stopPropagation();var I=Ot.get(e),b=I.items,h=Array.from(e.children),E=h.indexOf(g.currentTarget);E<h.length-1&&(n.autoAriaDisabled||Ur("Moved item ".concat(ar," to position ").concat(E+2," in the list ").concat(Dr)),i(b,E,E+1),Yr(e,b,{trigger:Bt.DROPPED_INTO_ZONE,id:Vn,source:$t.KEYBOARD}));break}case"ArrowUp":case"ArrowLeft":{if(!mn)return;g.preventDefault(),g.stopPropagation();var F=Ot.get(e),T=F.items,C=Array.from(e.children),V=C.indexOf(g.currentTarget);V>0&&(n.autoAriaDisabled||Ur("Moved item ".concat(ar," to position ").concat(V," in the list ").concat(Dr)),i(T,V,V-1),Yr(e,T,{trigger:Bt.DROPPED_INTO_ZONE,id:Vn,source:$t.KEYBOARD}));break}}}function a(g){u(g.currentTarget),Ft=e,Za=n.type,mn=!0;var I=Array.from(Dn.get(n.type)).filter(function(h){return h===Ft||!Ot.get(h).dropFromOthersDisabled});if(Ki(I,function(h){return Ot.get(h).dropTargetStyle},function(h){return Ot.get(h).dropTargetClasses}),!n.autoAriaDisabled){var b="Started dragging item ".concat(ar,". Use the arrow keys to move it within its list ").concat(Dr);I.length>1&&(b+=", or tab to another list in order to move the item into it"),Ur(b)}or(e,Ot.get(e).items,{trigger:Bt.DRAG_STARTED,id:Vn,source:$t.KEYBOARD}),jo()}function o(g){mn&&g.currentTarget!==Sr&&(g.stopPropagation(),Ei(!1),a(g))}function u(g){var I=Ot.get(e),b=I.items,h=Array.from(e.children),E=h.indexOf(g);Sr=g,Sr.tabIndex=n.zoneItemTabIndex,Vn=b[E][wt],ar=h[E].getAttribute("aria-label")||""}function c(g){var I=g.items,b=I===void 0?[]:I,h=g.type,E=h===void 0?rd:h,F=g.dragDisabled,T=F===void 0?!1:F,C=g.zoneTabIndex,V=C===void 0?0:C,Y=g.zoneItemTabIndex,Q=Y===void 0?0:Y,ye=g.dropFromOthersDisabled,Ne=ye===void 0?!1:ye,_e=g.dropTargetStyle,Ce=_e===void 0?qs:_e,Ve=g.dropTargetClasses,Se=Ve===void 0?[]:Ve,oe=g.autoAriaDisabled,ne=oe===void 0?!1:oe;n.items=hn(b),n.dragDisabled=T,n.dropFromOthersDisabled=Ne,n.zoneTabIndex=V,n.zoneItemTabIndex=Q,n.dropTargetStyle=Ce,n.dropTargetClasses=Se,n.autoAriaDisabled=ne,n.type&&E!==n.type&&Xs(e,n.type),n.type=E,id(e,E),ne||(e.setAttribute("role","list"),e.setAttribute("aria-describedby",T?ia.DND_ZONE_DRAG_DISABLED:ia.DND_ZONE_ACTIVE)),Ot.set(e,n),mn?e.tabIndex=e===Ft||Sr.contains(e)||n.dropFromOthersDisabled||Ft&&n.type!==Ot.get(Ft).type?-1:0:e.tabIndex=n.zoneTabIndex,e.addEventListener("focus",ad);for(var ae=function(re){var Z=e.children[re];ra.add(Z),Z.tabIndex=mn?-1:n.zoneItemTabIndex,ne||Z.setAttribute("role","listitem"),Z.removeEventListener("keydown",Zs.get(Z)),Z.removeEventListener("click",Ks.get(Z)),T||(Z.addEventListener("keydown",s),Zs.set(Z,s),Z.addEventListener("click",o),Ks.set(Z,o)),mn&&n.items[re][wt]===Vn&&(Sr=Z,Sr.tabIndex=n.zoneItemTabIndex,Z.focus())},G=0;G<e.children.length;G++)ae(G)}c(t);var p={update:function(I){c(I)},destroy:function(){Xs(e,n.type),Ot.delete(e),Ka.delete(e)}};return Ka.set(e,p),p}var od=["items","flipDurationMs","type","dragDisabled","morphDisabled","dropFromOthersDisabled","zoneTabIndex","zoneItemTabIndex","dropTargetStyle","dropTargetClasses","transformDraggedElement","autoAriaDisabled","centreDraggedOnCursor","useCursorForDetection","delayTouchStart","dropAnimationDisabled"];function gn(e,t){if(ld(e))return{update:function(){},destroy:function(){}};Qs(t);var n=Qu(e,t),i=sd(e,t);return{update:function(a){Qs(a),n.update(a),i.update(a)},destroy:function(){n.destroy(),i.destroy()}}}function ld(e){return!!e.closest("[".concat(gu,'="true"]'))}function Qs(e){var t=e.items;e.flipDurationMs,e.type,e.dragDisabled,e.morphDisabled,e.dropFromOthersDisabled;var n=e.zoneTabIndex,i=e.zoneItemTabIndex;e.dropTargetStyle;var s=e.dropTargetClasses;e.transformDraggedElement,e.autoAriaDisabled,e.centreDraggedOnCursor,e.useCursorForDetection;var a=e.delayTouchStart;e.dropAnimationDisabled;var o=$c(e,od);if(Object.keys(o).length>0&&console.warn("dndzone will ignore unknown options",o),!t)throw new Error("no 'items' key provided to dndzone");var u=t.find(function(g){return!{}.hasOwnProperty.call(g,wt)});if(u)throw new Error("missing '".concat(wt,"' property for item ").concat(vi(u)));if(s&&!Array.isArray(s))throw new Error("dropTargetClasses should be an array but instead it is a ".concat(Wr(s),", ").concat(vi(s)));if(n&&!$s(n))throw new Error("zoneTabIndex should be a number but instead it is a ".concat(Wr(n),", ").concat(vi(n)));if(i&&!$s(i))throw new Error("zoneItemTabIndex should be a number but instead it is a ".concat(Wr(i),", ").concat(vi(i)));if(a!==void 0&&a!==!1){var c=a===!0,p=typeof a=="number"&&isFinite(a)&&a>=0;if(!c&&!p)throw new Error("delayTouchStart should be a boolean (true/false) or a non-negative number but instead it is a ".concat(Wr(a),", ").concat(vi(a)))}}function $s(e){return!isNaN(e)&&(function(t){return(t|0)===t})(parseFloat(e))}var cd=N('<div role="listitem" class="flex items-center mb-1 group"><span class="drag-handle px-1 text-zinc-400 hover:text-zinc-200 cursor-grab active:cursor-grabbing select-none font-mono text-sm" title="Перетащить сцену">||</span> <button> </button> <button class="ml-1 px-2 py-1 text-emerald-400 hover:text-emerald-300 opacity-0 group-hover:opacity-100 transition text-lg leading-none" title="Добавить сцену после этой">+</button> <button class="ml-0.5 px-2 py-1 text-rose-400 hover:text-rose-300 opacity-0 group-hover:opacity-100 transition text-lg leading-none" title="Удалить сцену (в корзину)">🗑</button></div>'),ud=N('<div class="flex items-center justify-between py-0.5 group"><span class="text-zinc-400 truncate pr-2"> </span> <div class="flex gap-1 opacity-70 group-hover:opacity-100"><button class="px-1.5 text-emerald-400 hover:text-emerald-300" title="Восстановить на прежнее место">↩</button> <button class="px-1.5 text-rose-400 hover:text-rose-300" title="Удалить навсегда">✕</button></div></div>'),dd=N('<div class="ml-1 mt-1 pl-2 border-l border-zinc-700 text-sm"></div>'),fd=N('<div class="ml-1 mt-1 pl-2 text-xs text-zinc-500 border-l border-zinc-700">Нет удалённых сцен</div>'),vd=N('<div class="w-72 border-r border-zinc-800 p-4 overflow-auto bg-zinc-900 flex flex-col h-full"><div class="flex items-center gap-3 mb-6"><span class="text-3xl">📖</span> <input class="flex-1 bg-transparent text-xl font-bold focus:outline-none"/></div> <button class="w-full mb-4 bg-emerald-600 hover:bg-emerald-500 py-3 rounded-xl flex items-center justify-center gap-2 font-medium">+ Новая сцена</button> <div role="list" aria-label="Список сцен" class="flex-1 overflow-auto pr-2"></div> <div class="mt-3 pt-2 border-t border-zinc-700"><button class="w-full flex items-center justify-between px-2 py-1.5 text-sm text-rose-400 hover:text-rose-300 hover:bg-zinc-800 rounded transition" title="Показать/скрыть удалённые сцены"><span class="flex items-center gap-2">🗑 Удалённые сцены <span class="text-xs opacity-60"> </span></span> <span class="text-xs"> </span></button> <!></div> <div class="mt-auto pt-8 border-t border-zinc-700"><button class="w-full bg-violet-600 hover:bg-violet-500 py-4 rounded-2xl font-medium flex items-center justify-center gap-3 text-lg shadow-2xl transition">📤 Экспорт в HTML-игру</button> <p class="text-center text-xs text-zinc-500 mt-2">Standalone версия для игроков</p></div></div>');function gd(e,t){Jr(t,!0);const n=()=>bn(st,"$storyStore",s),i=()=>bn(Pt,"$currentSceneId",s),[s,a]=Kr();function o(oe){st.update(ne=>({...ne,scenes:oe.detail.items}))}function u(oe){st.update(ne=>({...ne,scenes:oe.detail.items}))}let c=fe(!1),p=W(()=>n().deletedScenes||[]);var g=vd(),I=f(g),b=d(f(I),2);Ee(b),l(I);var h=d(I,2),E=d(h,2);xe(E,5,()=>n().scenes,oe=>oe.id,(oe,ne)=>{var ae=cd(),G=d(f(ae),2),P=f(G,!0);l(G);var re=d(G,2),Z=d(re,2);l(ae),H(()=>{jn(G,1,`flex-1 text-left px-4 py-3 rounded-xl transition-all ${r(ne).id===i()?"bg-blue-600 shadow-lg":"hover:bg-zinc-800"}`),M(P,r(ne).id)}),S("click",G,()=>t.selectScene(r(ne).id)),S("click",re,()=>t.addSceneAfter(r(ne).id)),S("click",Z,()=>t.deleteScene(r(ne).id)),O(oe,ae)}),l(E),Bi(E,(oe,ne)=>gn==null?void 0:gn(oe,ne),()=>({items:n().scenes,flipDurationMs:200,type:"scene"}));var F=d(E,2),T=f(F),C=f(T),V=d(f(C)),Y=f(V);l(V),l(C);var Q=d(C,2),ye=f(Q,!0);l(Q),l(T);var Ne=d(T,2);{var _e=oe=>{var ne=dd();xe(ne,23,()=>r(p),ae=>ae.scene.id,(ae,G,P)=>{var re=ud(),Z=f(re),ce=f(Z,!0);l(Z);var ee=d(Z,2),De=f(ee),je=d(De,2);l(ee),l(re),H(()=>{Tt(Z,"title",r(G).scene.id),M(ce,r(G).scene.id)}),S("click",De,()=>t.restoreDeletedScene(r(P))),S("click",je,()=>t.permanentlyDeleteDeletedScene(r(P))),O(ae,re)}),l(ne),O(oe,ne)},Ce=oe=>{var ne=fd();O(oe,ne)};ie(Ne,oe=>{r(c)&&r(p).length>0?oe(_e):r(c)&&oe(Ce,1)})}l(F);var Ve=d(F,2),Se=f(Ve);er(2),l(Ve),l(g),H(()=>{M(Y,`(${r(p).length??""})`),M(ye,r(c)?"▼":"▶")}),In(b,()=>n().title,oe=>Va(st,rr(n).title=oe,rr(n))),S("click",h,function(...oe){var ne;(ne=t.addScene)==null||ne.apply(this,oe)}),Zt("consider",E,o),Zt("finalize",E,u),S("click",T,()=>y(c,!r(c))),S("click",Se,function(...oe){var ne;(ne=t.exportToHtmlGame)==null||ne.apply(this,oe)}),O(e,g),qr(),a()}Zr(["click"]);var md=N('<div class="bg-zinc-900 p-5 rounded-2xl flex items-center gap-4"><input class="flex-1 bg-zinc-800 p-4 rounded-xl"/> <input type="number" class="w-28 bg-zinc-800 p-4 rounded-xl text-center"/> <span class="text-[10px] text-emerald-400/70 px-2 py-0.5 bg-emerald-950/40 rounded whitespace-nowrap" title="Сцена введения характеристики"> </span> <button class="text-red-400 hover:text-red-500 px-4">✕</button></div>'),pd=N('<div class="bg-zinc-900/50 p-4 rounded-xl flex items-center gap-3 text-sm"><input class="flex-1 bg-zinc-800 p-3 rounded-xl text-sm"/> <input type="number" class="w-20 bg-zinc-800 p-2 rounded text-center"/> <span class="text-[9px] text-emerald-400/70 px-1.5 py-0.5 bg-emerald-950/30 rounded whitespace-nowrap" title="Сцена введения (для стартового — обычно начальная)"> </span> <button class="text-red-400 hover:text-red-500 px-2 text-sm">✕</button></div>'),bd=N('<div class="text-xs text-zinc-500 italic p-2">Нет сохранённых начальных значений (будут установлены при первом входе в превью или при добавлении здесь).</div>'),hd=N('<div class="mt-2 space-y-2 pl-2 border-l-2 border-zinc-700"><!> <!> <div class="mt-3 flex gap-2"><input placeholder="Название новой (в стартовый)" class="flex-1 bg-zinc-800 p-2.5 rounded-xl text-sm"/> <input type="number" class="w-20 bg-zinc-800 p-2.5 rounded-xl text-center text-sm"/> <button class="bg-emerald-600 hover:bg-emerald-500 px-4 rounded-xl text-sm">+ Добавить</button></div></div> <button class="mt-2 w-full text-sm bg-zinc-700 hover:bg-zinc-600 px-3 py-1.5 rounded-xl transition">Сбросить текущие характеристики к стартовым</button>',1),xd=N('<div class="p-8 overflow-auto"><div class="max-w-2xl mx-auto"><input class="w-full bg-zinc-900 p-5 rounded-2xl text-3xl font-bold mb-6" placeholder="Имя героя"/> <textarea rows="3" class="w-full bg-zinc-900 p-5 rounded-2xl text-lg mb-8" placeholder="Краткое описание персонажа..."></textarea> <h3 class="text-xl font-semibold mb-4">Характеристики</h3> <div class="space-y-3"></div> <div class="mt-8 flex gap-3"><input placeholder="Название новой характеристики" class="flex-1 bg-zinc-800 p-4 rounded-xl"/> <input type="number" class="w-24 bg-zinc-800 p-4 rounded-xl text-center"/> <button class="bg-emerald-600 hover:bg-emerald-500 px-8 rounded-xl">+ Добавить</button></div>   <div class="mt-8"><button class="w-full flex items-center justify-between px-4 py-3 bg-zinc-800 hover:bg-zinc-700 rounded-2xl text-left transition"><span class="font-medium">Стартовый объект (начальные значения)</span> <span class="text-sm opacity-60"> </span></button> <!></div></div></div>');function yd(e,t){Jr(t,!0);const n=()=>bn(st,"$storyStore",i),[i,s]=Kr();let a=Yt(t,"startingVariables",19,()=>({})),o=fe(""),u=fe(10),c=fe(""),p=fe(10),g=fe(!1);function I(){var Z;const P=r(o).trim();if(!P)return;const re=n().startScene||(((Z=n().scenes[0])==null?void 0:Z.id)??"scene1");Vc(P,r(u),re),y(o,""),y(u,10)}function b(P){Uc(P)}function h(P,re){ir(Z=>({...Z,[P]:re}))}function E(P,re){Wc(P,re)}function F(){const P=r(c).trim();P&&(t.onAddStartingVariable&&t.onAddStartingVariable(P,r(p)),y(c,""),y(p,10))}var T=xd(),C=f(T),V=f(C);Ee(V);var Y=d(V,2);Fa(Y);var Q=d(Y,4);xe(Q,5,()=>Object.keys(n().variables),P=>P,(P,re)=>{const Z=W(()=>n().variables[r(re)]),ce=W(()=>{var Te;return(Te=n().variableOrigins)==null?void 0:Te[r(re)]}),ee=W(()=>r(ce)?`введено в ${r(ce)}`:"базовая");var De=md(),je=f(De);Ee(je);var Re=d(je,2);Ee(Re);var ze=d(Re,2),Xe=f(ze,!0);l(ze);var Ue=d(ze,2);l(De),H(()=>{tt(je,r(re)),tt(Re,r(Z)),M(Xe,r(ee))}),S("input",je,Te=>E(r(re),Te.currentTarget.value)),S("input",Re,Te=>h(r(re),parseInt(Te.currentTarget.value)||0)),S("click",Ue,()=>b(r(re))),O(P,De)}),l(Q);var ye=d(Q,2),Ne=f(ye);Ee(Ne);var _e=d(Ne,2);Ee(_e);var Ce=d(_e,2);l(ye);var Ve=d(ye,2),Se=f(Ve),oe=d(f(Se),2),ne=f(oe,!0);l(oe),l(Se);var ae=d(Se,2);{var G=P=>{var re=hd(),Z=Xt(re),ce=f(Z);xe(ce,16,()=>Object.keys(a()),he=>he,(he,ke)=>{const gt=W(()=>a()[ke]),mt=W(()=>{var Qe;return(Qe=n().variableOrigins)==null?void 0:Qe[ke]}),yn=W(()=>r(mt)?`введено в ${r(mt)}`:"базовая");var Vt=pd(),yt=f(Vt);Ee(yt);var kt=d(yt,2);Ee(kt);var jt=d(kt,2),Tn=f(jt,!0);l(jt);var On=d(jt,2);l(Vt),H(()=>{tt(yt,ke),tt(kt,r(gt)),M(Tn,r(yn))}),S("input",yt,Qe=>{const At=Qe.currentTarget.value;t.onRenameStartingVariable&&t.onRenameStartingVariable(ke,At)}),S("input",kt,Qe=>{const At=parseInt(Qe.currentTarget.value)||0;t.onSetStartingVariable&&t.onSetStartingVariable(ke,At)}),S("click",On,()=>{t.onRemoveStartingVariable&&t.onRemoveStartingVariable(ke)}),O(he,Vt)});var ee=d(ce,2);{var De=he=>{var ke=bd();O(he,ke)},je=W(()=>Object.keys(a()).length===0);ie(ee,he=>{r(je)&&he(De)})}var Re=d(ee,2),ze=f(Re);Ee(ze);var Xe=d(ze,2);Ee(Xe);var Ue=d(Xe,2);l(Re),l(Z);var Te=d(Z,2);In(ze,()=>r(c),he=>y(c,he)),In(Xe,()=>r(p),he=>y(p,he)),S("click",Ue,F),S("click",Te,()=>{ir(()=>({...a()}))}),O(P,re)};ie(ae,P=>{r(g)&&P(G)})}l(Ve),l(C),l(T),H(()=>M(ne,r(g)?"▼":"▶")),In(V,()=>n().characterName,P=>Va(st,rr(n).characterName=P,rr(n))),In(Y,()=>n().characterDescription,P=>Va(st,rr(n).characterDescription=P,rr(n))),In(Ne,()=>r(o),P=>y(o,P)),In(_e,()=>r(u),P=>y(u,P)),S("click",Ce,I),S("click",Se,()=>y(g,!r(g))),O(e,T),qr(),s()}Zr(["input","click"]);var _d=N('<span class="px-3 py-0.5 text-xs bg-emerald-500/20 text-emerald-400 rounded-full font-medium">СТАРТОВАЯ (первая в стеке)</span>'),wd=N('<p class="text-xs text-emerald-400 mt-2 pl-3">Это первая сцена в стеке → она автоматически становится стартовой</p>'),Sd=N('<button class="px-2 py-0.5 text-xs bg-zinc-800 hover:bg-emerald-700 rounded"> </button>'),Id=N('<div class="flex flex-wrap gap-1 mb-2 pl-1"></div>'),Dd=N('<button class="px-2 py-0.5 text-xs bg-zinc-800 hover:bg-emerald-700 rounded"> </button>'),Ed=N('<div class="flex flex-wrap gap-1 mb-2 pl-1"></div>'),Td=N('<div class="mb-3 pl-3"><div class="flex items-center gap-2 mb-1"><span class="text-xs text-zinc-400 font-medium">Имя НПС (по умолчанию)</span> <input placeholder="Стражник" class="bg-zinc-800 px-3 py-1 rounded-xl text-sm w-64 border border-zinc-700 focus:outline-none"/> <span class="text-[10px] text-zinc-500">— для стартовой реплики</span></div> <!> <div class="flex items-center gap-2 mb-1"><span class="text-xs text-zinc-400 font-medium">Эмоция (по умолчанию)</span> <input placeholder="злой / радостный" class="bg-zinc-800 px-3 py-1 rounded-xl text-sm w-64 border border-zinc-700 focus:outline-none"/></div> <!></div>'),Od=N('<button class="px-3 py-1 text-xs bg-emerald-700 hover:bg-emerald-600 rounded-xl text-white"> </button>'),Nd=N('<button class="px-2 py-0.5 text-xs bg-emerald-700 hover:bg-emerald-600 rounded text-white"> </button>'),kd=N('<button class="px-3 py-1 text-xs bg-zinc-600 hover:bg-zinc-500 rounded-xl"> </button>'),Ad=N('<button class="px-2 py-0.5 text-xs bg-zinc-600 hover:bg-zinc-500 rounded" title="Из общего хранилища / кнопок"> </button>'),Cd=N('<div class="flex flex-col gap-1 mt-1"><div class="flex flex-wrap gap-1"><button class="px-2 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">and</button> <button class="px-2 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">or</button> <button class="px-2 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">not</button> <button class="px-2 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">(</button> <button class="px-2 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">)</button></div> <div class="flex flex-wrap gap-1"><!> <!> <!> <!></div></div>'),zd=N('<div class="flex flex-wrap gap-1 mt-1"><button class="px-3 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">&gt;</button> <button class="px-3 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">&gt;=</button> <button class="px-3 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">&lt;</button> <button class="px-3 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">&lt;=</button> <button class="px-3 py-0.5 text-xs bg-zinc-700 hover:bg-amber-600 rounded">==</button> <button class="px-3 py-0.5 text-xs bg-zinc-800 hover:bg-zinc-600 rounded">Отмена</button></div>'),Rd=N('<button class="px-3 py-1 text-xs bg-zinc-700 hover:bg-blue-600 rounded-xl transition"> </button>'),Ld=N('<div class="mb-4 p-2 bg-zinc-800/50 rounded-xl text-xs text-zinc-400">В диалоге ответы по умолчанию возвращают в эту сцену. Используй <code>next</code> для перехода на другую сцену (окончание диалога). Для условных ответов используй поле "Условие".</div>'),Pd=N('<span class="ml-2 text-zinc-500"> </span>'),Md=N('<div class="mb-1.5 text-[10px] text-zinc-400 font-mono leading-tight"> <!></div>'),Fd=N('<div class="text-[10px] text-red-400 mt-1">Ссылается на несуществующую характеристику или предмет — условие будет ложным</div>'),Vd=N('<span class="text-xs opacity-60 font-mono ml-2 truncate max-w-[120px]"> </span>'),jd=N('<button class="px-1.5 py-0.5 text-[9px] bg-zinc-700 hover:bg-blue-600 rounded text-zinc-300"> </button>'),Wd=N('<button class="px-2 py-0.5 text-[10px] bg-emerald-700 hover:bg-emerald-600 rounded text-white"> </button>'),Hd=N('<button class="px-2 py-0.5 text-[10px] bg-zinc-600 hover:bg-zinc-500 rounded"> </button>'),Ud=N('<div class="flex gap-0.5"><button class="px-1.5 py-0.5 text-[10px] bg-emerald-700 hover:bg-emerald-600 rounded text-white"> </button> <button class="px-1.5 py-0.5 text-[10px] bg-rose-700 hover:bg-rose-600 rounded text-white"> </button></div>'),Gd=N('<div class="flex gap-0.5" title="Из общего хранилища / кнопок"><button class="px-1.5 py-0.5 text-[10px] bg-zinc-600 hover:bg-zinc-500 rounded"> </button> <button class="px-1.5 py-0.5 text-[10px] bg-zinc-600 hover:bg-zinc-500 rounded"> </button></div>'),Yd=N('<div class="ml-4 mt-1 mb-2 p-3 bg-zinc-900/70 rounded-2xl text-xs border border-zinc-700"><div class="mb-2"><div class="text-[10px] text-zinc-400 mb-1">Характеристики (клик — вставить в effects тира)</div> <div class="flex flex-wrap gap-1 mb-1"><!> <!></div> <div class="flex gap-1"><input placeholder="Новая характеристика" class="flex-1 bg-zinc-800 p-1 rounded text-[10px]"/> <button class="px-2 bg-emerald-600 hover:bg-emerald-500 rounded text-[10px]">+</button></div></div> <div><div class="text-[10px] text-zinc-400 mb-1">Инвентарь (клик — вставить в effects тира)</div> <div class="flex flex-wrap gap-1 mb-1"><!> <!></div> <div class="flex gap-1"><input placeholder="Новый предмет" class="flex-1 bg-zinc-800 p-1 rounded text-[10px]"/> <button class="px-2 bg-emerald-600 hover:bg-emerald-500 rounded text-[10px]">+</button></div></div></div>'),Bd=N('<div class="flex flex-wrap items-center gap-2 bg-zinc-950/60 p-2 rounded-2xl"><div class="w-16 text-xs font-mono text-emerald-400 shrink-0"> </div> <div class="flex-1 min-w-[140px]"><input placeholder="sceneX или end" class="w-full bg-zinc-800 p-2 rounded-xl text-xs font-mono"/> <div class="flex flex-wrap gap-1 mt-1"></div></div> <div class="w-full sm:w-48"><input placeholder="effects (опц.)" class="w-full bg-zinc-800 p-2 rounded-xl text-xs"/></div></div> <!>',1),Jd=N('<div class="pl-3 border-l border-zinc-700 mt-1 space-y-3"><div><input placeholder="1d20+strength"/> <div class="text-[10px] text-zinc-500 mt-0.5 px-1">Нотация: NdS±mod. Процентные пороги считаются от макс. значения кубика.</div></div> <div class="space-y-2"><div class="text-[10px] text-zinc-400 px-1">Пороги успеха (нажми на % чтобы задать ветку и эффекты). 0 = 0-25% от макса броска.</div> <!></div> <div class="text-[10px] text-amber-400/70 px-1 leading-tight">Эффекты тира применяются только при достижении этого (или лучшего) порога.<br/> Базовые effects выбора применяются всегда перед броском.</div></div>'),qd=N('<button class="px-3 py-1 text-xs bg-emerald-700 hover:bg-emerald-600 rounded-xl text-white"> </button>'),Zd=N('<button class="px-3 py-1 text-xs bg-zinc-600 hover:bg-zinc-500 rounded-xl"> </button>'),Kd=N('<div class="flex gap-1"><button class="px-3 py-1 text-xs bg-emerald-700 hover:bg-emerald-600 rounded-xl text-white"> </button> <button class="px-3 py-1 text-xs bg-rose-700 hover:bg-rose-600 rounded-xl text-white"> </button></div>'),Xd=N('<div class="flex gap-1" title="Из общего хранилища / кнопок"><button class="px-3 py-1 text-xs bg-zinc-600 hover:bg-zinc-500 rounded-xl"> </button> <button class="px-3 py-1 text-xs bg-zinc-600 hover:bg-zinc-500 rounded-xl"> </button></div>'),Qd=N('<div class="bg-zinc-900 border border-zinc-700 rounded-3xl p-5 relative"><div class="flex items-center justify-between mb-4 pb-2 border-b border-zinc-700"><div class="flex items-center gap-3"><span class="drag-handle px-1 text-zinc-400 hover:text-zinc-200 cursor-grab active:cursor-grabbing select-none font-mono text-sm" title="Перетащить ответ">||</span> <div class="w-7 h-7 rounded-2xl bg-zinc-700 flex items-center justify-center text-amber-400 font-mono font-bold text-base ring-1 ring-amber-500/30"> </div> <span class="font-medium text-base"> </span></div> <div class="flex gap-1"><button class="text-emerald-400 hover:text-emerald-500 text-xl px-2 transition" title="Дублировать выбор">📋</button> <button class="text-blue-400 hover:text-blue-500 text-xl px-2 transition" title="Скопировать в буфер">📥</button> <button class="text-red-400 hover:text-red-500 text-3xl leading-none px-3 py-1 hover:bg-zinc-800 rounded-xl transition">✕</button></div></div> <div class="mb-4"><label class="block text-sm text-zinc-400 mb-1 text-xs"> <input class="w-full bg-zinc-800 p-4 rounded-2xl text-base mt-1"/></label></div> <div class="mb-4"><label class="block text-sm text-zinc-400 mb-2">ID следующей сцены <input placeholder="scene3 или end" class="w-full bg-zinc-800 p-4 rounded-2xl mb-2 font-mono text-sm mt-1"/></label> <div class="flex flex-wrap gap-2"></div></div> <!> <!> <div class="mb-4"><label class="block text-sm text-zinc-400 mb-2">Условие <input placeholder="health > 50 and gold >= 10 or not (Ключ == 0)"/></label> <!> <!></div> <div class="mb-4"><button type="button" class="w-full flex items-center justify-between text-sm text-zinc-400 hover:text-white mb-1 px-1"><span class="font-medium">🎲 Бросок куба</span> <!> <span class="text-xs ml-2"> </span></button> <!></div> <div class="mb-4"><label class="block text-sm text-zinc-400 mb-2">Эффекты характеристик <input placeholder="health:-10,gold:5" class="w-full bg-zinc-800 p-4 rounded-2xl mb-2 text-sm mt-1"/></label> <div class="flex flex-wrap gap-2 mb-2"><!> <!></div> <div class="flex gap-2"><input placeholder="Новая характеристика" class="flex-1 bg-zinc-800 p-3 rounded-2xl text-xs"/> <button class="px-5 bg-emerald-600 hover:bg-emerald-500 rounded-2xl text-xs">Добавить</button></div></div> <div><div class="block text-sm text-zinc-400 mb-2">Инвентарь</div> <div class="flex flex-wrap gap-2 mb-3"><!> <!></div> <div class="flex gap-2"><input placeholder="Новый предмет" class="flex-1 bg-zinc-800 p-3 rounded-2xl text-xs"/> <button class="px-5 bg-emerald-600 hover:bg-emerald-500 rounded-2xl text-xs">Добавить</button></div></div></div>'),$d=N('<button class="text-xs px-1.5 py-0.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition"> </button> <button class="text-xs px-2 py-0.5 bg-zinc-800 hover:bg-emerald-700 text-emerald-300 hover:text-white rounded transition" title="Свернуть или развернуть все ответы в сцене (стартовую реплику + все реплики НПС)"> </button>',1),ef=N('<button class="bg-emerald-600 hover:bg-emerald-500 px-8 py-3 rounded-2xl text-sm font-medium transition flex items-center gap-2">+ Реплика НПС</button>'),tf=N('<div role="list" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 pb-20 pt-12"></div>'),nf=N('<div role="button" tabindex="0" class="text-sm text-zinc-400 py-3 px-1 cursor-pointer hover:bg-zinc-900/50 rounded transition flex items-center gap-2 mb-4" title="Кликните или нажмите Enter/Space, чтобы развернуть ответы на стартовую реплику" aria-label="Развернуть ответы на стартовую реплику"><span>▸</span> <span> </span></div>'),rf=N('<div class="flex items-center justify-between gap-2"><div role="button" tabindex="0" class="text-sm text-zinc-300 py-2 px-1 flex-1 cursor-pointer hover:bg-zinc-800/40 rounded transition min-w-0" title="Кликните или нажмите Enter/Space, чтобы развернуть" aria-label="Развернуть реплику НПС"><span class="font-medium text-emerald-300/90"> </span> <span class="text-zinc-400"> </span> <span class="ml-2 text-[10px] text-zinc-500">(свёрнуто)</span></div> <button class="text-xs bg-emerald-700 hover:bg-emerald-600 px-2 py-1 rounded-xl shrink-0" title="Добавить ответ игрока для этой реплики (развернёт блок)">+ ответ</button></div>'),af=N('<button class="px-2 py-0.5 text-xs bg-zinc-800 hover:bg-emerald-700 rounded"> </button>'),sf=N('<div class="flex flex-wrap gap-1 mt-1"></div>'),of=N('<button class="px-2 py-0.5 text-xs bg-zinc-800 hover:bg-emerald-700 rounded"> </button>'),lf=N('<div class="flex flex-wrap gap-1 mt-1"></div>'),cf=N('<div class="text-[10px] text-red-400 mt-1">Ссылается на несуществующую характеристику или предмет — условие будет ложным</div>'),uf=N('<div class="italic text-xs text-zinc-500 p-3 bg-zinc-950/60 rounded-2xl">Нет ответов для этой реплики. Нажмите кнопку выше.</div>'),df=N('<div class="mb-2"><label class="block text-sm text-zinc-400 mb-1">Имя НПС для этой реплики <input placeholder="Стражник" class="w-full bg-zinc-800 p-2 rounded-xl text-sm mb-1 mt-1"/></label> <!></div> <div class="mb-2"><label class="block text-sm text-zinc-400 mb-1">Эмоция <input placeholder="злой / грустный / радостный" class="w-full bg-zinc-800 p-2 rounded-xl text-sm mb-1 mt-1"/></label> <!></div> <div class="text-sm text-zinc-400 mb-1"> </div> <textarea placeholder="Текст реплики НПС" class="w-full bg-zinc-800 p-3 rounded-2xl text-sm resize-y min-h-[80px]"></textarea> <div class="mt-3"><label class="block text-sm text-zinc-400 mb-1">Условия отображения этой реплики (пусто = всегда) <input placeholder="например: health > 50 and gold >= 10 or not (Ключ == 0)"/></label> <!> <!></div> <div class="mt-3"><div class="flex items-center justify-between mb-1"><div class="text-sm text-zinc-400">Ответы игрока для этой реплики</div> <button class="text-xs bg-emerald-700 hover:bg-emerald-600 px-3 py-1 rounded-xl">+ Добавить ответ игрока</button></div> <div role="list" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 pt-2"><!> <!></div></div> <div class="mt-2 pt-2 border-t border-zinc-700"><button class="text-xs bg-emerald-600 hover:bg-emerald-500 px-3 py-1 rounded-xl">+ Реплика НПС (следующий)</button></div>',1),ff=N('<div role="listitem" class="mt-4 p-4 border border-zinc-700 rounded-3xl bg-zinc-900/50"><div class="flex items-center justify-between -mt-2 mb-1"><div class="flex items-center gap-2"><span class="drag-handle px-1 text-zinc-400 hover:text-zinc-200 cursor-grab active:cursor-grabbing select-none font-mono text-sm" title="Перетащить реплику НПС (изменит порядок в диалоге и индексы ответов)">||</span> <button class="text-zinc-400 hover:text-white text-xs px-1.5 py-0.5 rounded hover:bg-zinc-800 transition"> </button></div> <button class="text-red-400 hover:text-red-500 text-3xl leading-none px-3 py-1 hover:bg-zinc-800 rounded-xl transition" title="Удалить реплику НПС">✕</button></div> <!></div>'),vf=N('<div class="mt-4"><div role="list" aria-label="Реплики НПС (перетаскивайте за || )"></div></div>'),gf=N('<div class="mb-8"><div class="flex items-center gap-3 mb-2"><div class="text-xs text-zinc-400 font-medium pl-3">ID сцены (уникальный)</div> <!></div> <input class="w-full bg-zinc-900 p-5 rounded-3xl text-3xl font-mono focus:outline-none border border-zinc-700"/> <!></div> <div class="mb-6 flex items-center gap-3 pl-3"><label class="flex items-center gap-2 text-sm text-zinc-300 cursor-pointer"><input type="checkbox" class="w-4 h-4 accent-emerald-600"/> <span>Диалоговый режим</span></label> <span class="text-xs text-zinc-500">— ответы по умолчанию возвращают в эту сцену</span></div> <!> <div class="mb-3 text-xs text-zinc-400 font-medium pl-3"> </div> <textarea class="w-full h-[42vh] min-h-[380px] bg-zinc-900 p-8 rounded-3xl text-xl leading-relaxed font-serif resize-y focus:outline-none border border-zinc-700"></textarea> <div class="mt-2"><div class="sticky top-0 z-30 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800 shadow-sm"><div class="flex justify-between items-center"><div class="flex items-center gap-2"><h3 class="text-2xl font-semibold"> </h3> <!> <p class="text-sm text-zinc-400"> </p></div> <div class="flex gap-2"><button class="bg-emerald-600 hover:bg-emerald-500 px-8 py-3 rounded-2xl text-sm font-medium transition flex items-center gap-2"> </button> <!></div></div></div> <!>  <!></div>',1);function mf(e,t){Jr(t,!0);const n=()=>bn(st,"$storyStore",o),i=()=>bn(Ii,"$collapsedNpcResponsesStore",o),s=()=>bn(Si,"$collapsedStartingStore",o),a=()=>bn(Pt,"$currentSceneId",o),[o,u]=Kr();let c=Yt(t,"liveVariables",3,void 0),p=Yt(t,"liveItems",3,void 0),g=Yt(t,"sceneStates",19,()=>({})),I=fe(null),b=fe(null),h=W(()=>n().suggestedVariables||[]),E=W(()=>n().suggestedItems||[]),F=W(()=>n().suggestedNpcNames||[]),T=W(()=>n().suggestedEmotions||[]),C=Mt({}),V=Mt({}),Y=Mt({}),Q=fe(null);function ye(v){t.selectedScene&&(Mc(t.selectedScene.id,v),setTimeout(()=>{if(!r(Q))return;const x=r(Q).lastElementChild;x==null||x.scrollIntoView({behavior:"smooth",block:"center"})},100))}function Ne(){if(!t.selectedScene)return;t.selectedScene.isDialogue&&(r(ot).set(t.selectedScene.id,!1),y(ot,new Map(r(ot)),!0));const v={text:"Новый ответ",next:""};t.selectedScene.isDialogue&&(v.npcLineIndex=0),Ps(t.selectedScene.id,v),setTimeout(()=>{if(!r(Q))return;const x=r(Q).lastElementChild;x&&(x.scrollIntoView({behavior:"smooth",block:"center"}),setTimeout(()=>{const _=x.querySelector('input[placeholder="Текст выбора"]');_&&(_.focus(),_.select()),x.style.transition="all 0.4s",x.style.boxShadow="0 0 0 4px rgb(16 185 129)",x.style.borderColor="rgb(16 185 129)",setTimeout(()=>{x.style.boxShadow="",x.style.borderColor=""},1600)},350))},120)}function _e(v){(v.ctrlKey||v.metaKey)&&v.key==="Enter"&&(v.preventDefault(),Ne())}pn(()=>(window.addEventListener("keydown",_e),()=>window.removeEventListener("keydown",_e)));function Ce(v){t.selectedScene&&Lc(t.selectedScene.id,v)}function Ve(v){t.selectedScene&&Pc(t.selectedScene.id,v)}function Se(v,x){if(!t.selectedScene)return;const w=(v.detail.items||[]).filter(j=>!String((j==null?void 0:j.id)||"").startsWith("dnd-shadow-placeholder")),U=w.filter(j=>j&&typeof j.text=="string"&&!j.hasOwnProperty("emotion")&&!j.hasOwnProperty("npcResponses"));U.length===w.length&&Rs(t.selectedScene.id,x,U)}function oe(v,x){if(!t.selectedScene)return;const U=(v.detail.items||[]).filter(j=>!String((j==null?void 0:j.id)||"").startsWith("dnd-shadow-placeholder")).filter(j=>j&&typeof j.text=="string"&&!j.hasOwnProperty("emotion")&&!j.hasOwnProperty("npcResponses"));Rs(t.selectedScene.id,x,U)}function ne(v){if(!t.selectedScene)return;const x=v.detail.items||[],_=x.filter(w=>w&&typeof w.text=="string"&&(w.hasOwnProperty("emotion")||w.hasOwnProperty("npcName")));_.length===x.length&&Ls(t.selectedScene.id,_)}function ae(v){if(!t.selectedScene)return;const _=(v.detail.items||[]).filter(w=>w&&typeof w.text=="string"&&(w.hasOwnProperty("emotion")||w.hasOwnProperty("npcName")));Ls(t.selectedScene.id,_)}function G(v,x){t.selectedScene&&Pn(t.selectedScene.id,v,_=>({..._,next:x}))}function P(v,x,_,w,U=null){const j=_();let D=(j?j.value:"").trimEnd();D&&!/[\s(]$/.test(D)&&(D+=" "),D+=x,j&&(j.value=D),w(D),U&&U(v),requestAnimationFrame(()=>{requestAnimationFrame(()=>{const q=_();q&&(q.focus(),q.setSelectionRange(D.length,D.length))})})}function re(v,x){t.selectedScene&&P(v,x,()=>C[v],_=>Pn(t.selectedScene.id,v,w=>({...w,condition:_})),_=>{y(I,_,!0)})}function Z(v,x){t.selectedScene&&P(v,x,()=>C[v],_=>Pn(t.selectedScene.id,v,w=>({...w,condition:_})))}function ce(v){if(r(I)===null||!t.selectedScene)return;const x=r(I);Z(x,v),y(I,null)}function ee(v,x){if(!t.selectedScene)return;const _=n().suggestedVariables||[];!Object.keys(n().variables||{}).includes(x)&&!_.includes(x)&&Fi(x),je(v,`${x}:`)}function De(v,x,_){if(!t.selectedScene)return;const U=`${x==="add"?"addItem:":"removeItem:"}${_}:1`;je(v,U)}function je(v,x){var j;if(!t.selectedScene)return;const _=Y[v];let U=(_?_.value:((j=t.selectedScene.choices[v])==null?void 0:j.effects)||"").trimEnd();U&&!U.endsWith(",")&&(U+=","),U+=x,_&&(_.value=U),Pn(t.selectedScene.id,v,m=>({...m,effects:U}))}function Re(v,x,_){var m,D;if(!t.selectedScene)return;const w=(D=(m=t.selectedScene.choices[v])==null?void 0:m.rollTiers)==null?void 0:D[x];let j=((w==null?void 0:w.effects)||"").trimEnd();j&&!j.endsWith(",")&&(j+=","),j+=_,Pn(t.selectedScene.id,v,q=>{var X;return{...q,rollTiers:{...q.rollTiers,[x]:{...((X=q.rollTiers)==null?void 0:X[x])||{},effects:j}}}})}let ze=fe(Mt(new Set));function Xe(v){r(ze).has(v)?r(ze).delete(v):r(ze).add(v),y(ze,new Set(r(ze)),!0)}function Ue(v){return r(ze).has(v)}function Te(v,x){return v?!n().scenes.some(_=>_.id===v&&_.id!==x):!1}function he(v){if(!(v!=null&&v.trim()))return!1;const x=n().variables||{},_=n().items||{};return!xc(v,x,_)}const ke=["0","25","50","85","100"];let gt=fe(null);function mt(v,x,_,w){t.selectedScene&&dt(t.selectedScene.id,U=>{const j=U.choices.map((m,D)=>{if(D!==v)return m;const q={...m},X=q.rollTiers??{};return X[x]||(X[x]={next:""}),X[x]={...X[x],[_]:w},q.rollTiers=X,q});return{...U,choices:j}})}function yn(v){t.selectedScene&&dt(t.selectedScene.id,x=>{const _=x.choices.map((w,U)=>{if(U!==v||w.rollTiers)return w;const j={};for(const m of ke)j[m]={next:""};return{...w,rollTiers:j}});return{...x,choices:_}})}function Vt(v,x,_){if(!t.selectedScene)return;const w=Object.keys(n().variables||{}),U=n().suggestedVariables||[];!w.includes(_)&&!U.includes(_)&&Fi(_),Re(v,x,`${_}:`)}function yt(v,x,_,w){if(!t.selectedScene)return;const j=`${_==="add"?"addItem:":"removeItem:"}${w}:1`;Re(v,x,j)}function kt(v,x){if(!t.selectedScene)return;const _=document.getElementById(`newTierVar-${v}-${x}`),w=_==null?void 0:_.value.trim();w&&(Fi(w),Vt(v,x,w),_.value="")}function jt(v,x){if(!t.selectedScene)return;const _=document.getElementById(`newTierItem-${v}-${x}`),w=_==null?void 0:_.value.trim();w&&(Ms(w),yt(v,x,"add",w),_.value="")}function Tn(){t.selectedScene&&(dt(t.selectedScene.id,v=>{const x=v.npcResponses||[],_=x.length>0?x[x.length-1]:null,w=(_==null?void 0:_.npcName)||v.npcName,U=(_==null?void 0:_.emotion)||v.npcEmotion,j={id:`${t.selectedScene.id}-nr${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`,text:"",condition:"",npcName:w||"",emotion:U||""};return{...v,npcResponses:[...x,j]}}),setTimeout(()=>{const v=document.querySelectorAll('textarea[placeholder="Текст реплики НПС"]');if(v.length>0){const x=v[v.length-1];x.focus(),x.select(),x.scrollIntoView({behavior:"smooth",block:"center"});const _=x.closest('[role="listitem"]');if(_){const w=_;w.style.transition="all 0.4s",w.style.boxShadow="0 0 0 4px rgb(16 185 129)",w.style.borderColor="rgb(16 185 129)",setTimeout(()=>{w.style.boxShadow="",w.style.borderColor=""},1600)}}},150))}function On(v){if(!t.selectedScene)return;const x=v-1;if(x>=0&&t.selectedScene.npcResponses&&x<t.selectedScene.npcResponses.length){const w=t.selectedScene.npcResponses[x],U=(w==null?void 0:w.id)||`idx-${x}`;r(Je).has(U)&&(r(Je).delete(U),y(Je,new Set(r(Je)),!0))}const _={text:"Новый ответ",next:"",npcLineIndex:v};Ps(t.selectedScene.id,_),setTimeout(()=>{const w=document.querySelectorAll('input[placeholder="Ответ игрока"]');if(w.length>0){const U=w[w.length-1];U.focus(),U.select(),U.scrollIntoView({behavior:"smooth",block:"center"});const j=U.closest(".bg-zinc-900.border.border-zinc-700");if(j){const m=j;m.style.transition="all 0.4s",m.style.boxShadow="0 0 0 4px rgb(16 185 129)",m.style.borderColor="rgb(16 185 129)",setTimeout(()=>{m.style.boxShadow="",m.style.borderColor=""},1600)}}},150)}function Qe(v,x){t.selectedScene&&dt(t.selectedScene.id,_=>{const w=_.npcResponses?[..._.npcResponses]:[];return w[v]&&(w[v]={...w[v],npcName:x||void 0}),{..._,npcResponses:w}})}function At(v,x){t.selectedScene&&dt(t.selectedScene.id,_=>{const w=_.npcResponses?[..._.npcResponses]:[];return w[v]&&(w[v]={...w[v],emotion:x||void 0}),{..._,npcResponses:w}})}function lr(v,x){t.selectedScene&&dt(t.selectedScene.id,_=>{const w=_.npcResponses?[..._.npcResponses]:[];return w[v]&&(w[v]={...w[v],text:x}),{..._,npcResponses:w}})}function cr(v,x){t.selectedScene&&dt(t.selectedScene.id,_=>{const w=_.npcResponses?[..._.npcResponses]:[];return w[v]&&(w[v]={...w[v],condition:x||void 0}),{..._,npcResponses:w}})}function Qr(v,x){t.selectedScene&&P(v,x,()=>V[v],_=>cr(v,_),_=>{y(b,_,!0)})}function $r(v){if(r(b)===null||!t.selectedScene)return;const x=r(b);Kn(x,v),y(b,null)}function Kn(v,x,_=!1){t.selectedScene&&P(v,x,()=>V[v],w=>cr(v,w),_?w=>{y(b,w,!0)}:null)}function ur(){var j;const v=n().variables||{},x=n().items||{},_=((j=n().characterName)==null?void 0:j.trim())||"Герой",w=Object.keys(v).length?Object.entries(v).map(([m,D])=>`${m}:${D}`).join(", "):"",U=Object.keys(x).length?"inv:"+Object.entries(x).map(([m,D])=>`${m}:${D}`).join(", "):"";return{name:_,varStr:w,invStr:U}}let Hn=W(()=>t.selectedScene?n().scenes.findIndex(v=>v.id===t.selectedScene.id):-1),Je=fe(Mt(new Set(i())));function Un(v,x){const _=v||`idx-${x}`;r(Je).has(_)?r(Je).delete(_):r(Je).add(_),y(Je,new Set(r(Je)),!0),Os(Ii,r(Je))}function Nn(v,x){const _=v||`idx-${x}`;return r(Je).has(_)}pn(()=>{y(ot,new Map(s()),!0)}),pn(()=>{y(Je,new Set(i()),!0)});let ot=fe(Mt(new Map(s())));function un(v){return r(ot).get(v)??!1}function Gn(v){const x=r(ot).get(v)??!1;r(ot).set(v,!x),y(ot,new Map(r(ot)),!0),Os(Si,r(ot))}let Xn=!1;pn(()=>{if(!Xn){try{const v=ts();v.starting&&y(ot,new Map(v.starting),!0),v.npc&&y(Je,new Set(v.npc),!0)}catch{}Xn=!0}}),pn(()=>{try{es(r(ot),r(Je))}catch{}});function dr(v,x){const w=!fr(v,x);r(ot).set(v,w),x.forEach((U,j)=>{const m=(U==null?void 0:U.id)||`idx-${j}`;w?r(Je).add(m):r(Je).delete(m)}),y(Je,new Set(r(Je)),!0),y(ot,new Map(r(ot)),!0)}function fr(v,x){return un(v)?x.every((_,w)=>{const U=(_==null?void 0:_.id)||`idx-${w}`;return r(Je).has(U)}):!1}let Yn=W(()=>t.selectedScene?t.selectedScene.choices.filter(v=>!t.selectedScene.isDialogue||!v.npcLineIndex||v.npcLineIndex===0):[]);function ei(v){if(!t.selectedScene)return;const x=JSON.parse(JSON.stringify(v));x.id=`buf-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,delete x.npcLineIndex,hi.update(_=>[..._,x])}let k=W(()=>{const v=n().variables||{},x=n().variableOrigins||{},_=n().scenes,w=r(Hn);return w<0?Object.keys(v):Object.keys(v).filter(U=>{const j=x[U];if(!j)return!0;const m=_.findIndex(D=>D.id===j);return m>=0&&m<=w})}),R=W(()=>{const v=n().items||{},x=n().itemOrigins||{},_=n().scenes,w=r(Hn);return w<0?Object.keys(v):Object.keys(v).filter(U=>{const j=x[U];if(!j)return!0;const m=_.findIndex(D=>D.id===j);return m>=0&&m<=w})}),B=W(()=>{const v=n().variables||{},x=n().variableOrigins||{},_=n().scenes,w=r(Hn);return w<0?[]:Object.keys(v).filter(U=>{const j=x[U];if(!j)return!1;const m=_.findIndex(D=>D.id===j);return m>=0&&m<=w})}),te=W(()=>{const v=n().items||{},x=n().itemOrigins||{},_=n().scenes,w=r(Hn);return w<0?[]:Object.keys(v).filter(U=>{const j=x[U];if(!j)return!1;const m=_.findIndex(D=>D.id===j);return m>=0&&m<=w})}),pe=W(()=>r(h).filter(v=>!r(B).includes(v))),de=W(()=>r(E).filter(v=>!r(te).includes(v))),$=W(()=>{const v=r(k).filter(w=>!r(B).includes(w)),x=new Set(v),_=[...v];for(const w of r(pe))x.has(w)||(_.push(w),x.add(w));return _}),ue=W(()=>{const v=r(R).filter(w=>!r(te).includes(w)),x=new Set(v),_=[...v];for(const w of r(de))x.has(w)||(_.push(w),x.add(w));return _});var be=mi(),qe=Xt(be);{var Pe=v=>{var x=gf(),_=Xt(x),w=f(_),U=d(f(w),2);{var j=ct=>{var We=_d();O(ct,We)};ie(U,ct=>{var We;((We=n().scenes[0])==null?void 0:We.id)===t.selectedScene.id&&ct(j)})}l(w);var m=d(w,2);Ee(m);var D=d(m,2);{var q=ct=>{var We=wd();O(ct,We)};ie(D,ct=>{var We;((We=n().scenes[0])==null?void 0:We.id)===t.selectedScene.id&&ct(q)})}l(_);var X=d(_,2),we=f(X),ve=f(we);Ee(ve),er(2),l(we),er(2),l(X);var $e=d(X,2);{var Wt=ct=>{var We=Td(),Oe=f(We),le=d(f(Oe),2);Ee(le),er(2),l(Oe);var A=d(Oe,2);{var He=Ge=>{var Ae=Id();xe(Ae,21,()=>[...new Set(r(F))],Fe,(Ht,rt)=>{var et=Sd(),Ct=f(et,!0);l(et),H(()=>M(Ct,r(rt))),S("click",et,()=>{const It=a();It&&dt(It,tn=>({...tn,npcName:r(rt)}))}),O(Ht,et)}),l(Ae),O(Ge,Ae)};ie(A,Ge=>{r(F).length>0&&Ge(He)})}var se=d(A,2),me=d(f(se),2);Ee(me),l(se);var wn=d(se,2);{var dn=Ge=>{var Ae=Ed();xe(Ae,21,()=>[...new Set(r(T))],Fe,(Ht,rt)=>{var et=Dd(),Ct=f(et,!0);l(et),H(()=>M(Ct,r(rt))),S("click",et,()=>{const It=a();It&&dt(It,tn=>({...tn,npcEmotion:r(rt)}))}),O(Ht,et)}),l(Ae),O(Ge,Ae)};ie(wn,Ge=>{r(T).length>0&&Ge(dn)})}l(We),H(()=>{tt(le,t.selectedScene.npcName||""),tt(me,t.selectedScene.npcEmotion||"")}),S("input",le,Ge=>{const Ae=a();if(!Ae)return;const Ht=Ge.currentTarget.value.trim()||void 0;dt(Ae,rt=>({...rt,npcName:Ht}))}),Zt("blur",le,Ge=>{const Ae=Ge.currentTarget.value.trim();Ae&&!r(F).includes(Ae)&&Fs(Ae)}),S("input",me,Ge=>{const Ae=a();if(!Ae)return;const Ht=Ge.currentTarget.value.trim()||void 0;dt(Ae,rt=>({...rt,npcEmotion:Ht}))}),Zt("blur",me,Ge=>{const Ae=Ge.currentTarget.value.trim();Ae&&!r(T).includes(Ae)&&Vs(Ae)}),O(ct,We)};ie($e,ct=>{t.selectedScene.isDialogue&&ct(Wt)})}var ge=d($e,2),pt=f(ge,!0);l(ge);var bt=d(ge,2);Fa(bt);var nt=d(bt,2);{const ct=(Oe,le=_r,A=_r,He=_r,se=_r,me=_r,wn=_r)=>{var dn=mi(),Ge=Xt(dn);{var Ae=rt=>{var et=Cd(),Ct=f(et),It=f(Ct),tn=d(It,2),Dt=d(tn,2),zt=d(Dt,2),Rt=d(zt,2);l(Ct);var nn=d(Ct,2),fn=f(nn);xe(fn,17,()=>r(B),Fe,(ht,Ze)=>{const ut=W(()=>{var an;return(an=n().variableOrigins)==null?void 0:an[r(Ze)]});var Ye=Od(),rn=f(Ye);l(Ye),H(()=>{Tt(Ye,"title",r(ut)?`Введено в ${r(ut)} (из превью)`:"Добавлено в превью"),M(rn,`${r(Ze)??""}${r(ut)?"↓":""}`)}),S("click",Ye,()=>se()(r(Ze))),O(ht,Ye)});var Jn=d(fn,2);xe(Jn,17,()=>r(te),Fe,(ht,Ze)=>{const ut=W(()=>{var an;return(an=n().itemOrigins)==null?void 0:an[r(Ze)]});var Ye=Nd(),rn=f(Ye,!0);l(Ye),H(()=>{Tt(Ye,"title",r(ut)?`Введено в ${r(ut)} (из превью)`:"Добавлено в превью"),M(rn,r(Ze))}),S("click",Ye,()=>se()(`'${r(Ze)}'`)),O(ht,Ye)});var Cn=d(Jn,2);xe(Cn,17,()=>r($),Fe,(ht,Ze)=>{const ut=W(()=>{var an;return(an=n().variableOrigins)==null?void 0:an[r(Ze)]});var Ye=kd(),rn=f(Ye);l(Ye),H(()=>{Tt(Ye,"title",r(ut)?`Введено в ${r(ut)}`:"Из общего хранилища / кнопок"),M(rn,`${r(Ze)??""}${r(ut)?"↓":""}`)}),S("click",Ye,()=>se()(r(Ze))),O(ht,Ye)});var zn=d(Cn,2);xe(zn,17,()=>r(ue),Fe,(ht,Ze)=>{var ut=Ad(),Ye=f(ut,!0);l(ut),H(()=>M(Ye,r(Ze))),S("click",ut,()=>se()(`'${r(Ze)}'`)),O(ht,ut)}),l(nn),l(et),S("click",It,()=>He()("and ")),S("click",tn,()=>He()("or ")),S("click",Dt,()=>He()("not ")),S("click",zt,()=>He()("(")),S("click",Rt,()=>He()(") ")),O(rt,et)},Ht=rt=>{var et=zd(),Ct=f(et),It=d(Ct,2),tn=d(It,2),Dt=d(tn,2),zt=d(Dt,2),Rt=d(zt,2);l(et),S("click",Ct,()=>me()("> ")),S("click",It,()=>me()(">= ")),S("click",tn,()=>me()("< ")),S("click",Dt,()=>me()("<= ")),S("click",zt,()=>me()("== ")),S("click",Rt,()=>wn()()),O(rt,et)};ie(Ge,rt=>{A()?rt(Ht,!1):rt(Ae)})}O(Oe,dn)},We=(Oe,le=_r)=>{const A=W(()=>t.selectedScene.choices.indexOf(le())),He=W(ur),se=W(()=>{var L;return t.selectedScene?(L=g())==null?void 0:L[t.selectedScene.id]:void 0}),me=W(()=>{var L;return c()??((L=r(se))==null?void 0:L.variables)??n().variables??{}}),wn=W(()=>{var L;return p()??((L=r(se))==null?void 0:L.items)??n().items??{}}),dn=W(()=>Object.fromEntries(Object.entries(r(me)).filter(([L])=>r(k).includes(L)))),Ge=W(()=>Object.fromEntries(Object.entries(r(wn)).filter(([L])=>r(R).includes(L)))),Ae=W(()=>r(k).map(L=>`${L}:${r(dn)[L]??0}`).join(", ")),Ht=W(()=>r(R).map(L=>`${L}:${r(Ge)[L]??0}`).join(", "));var rt=Qd(),et=f(rt),Ct=f(et),It=d(f(Ct),2),tn=f(It,!0);l(It);var Dt=d(It,2),zt=f(Dt);l(Dt),l(Ct);var Rt=d(Ct,2),nn=f(Rt),fn=d(nn,2),Jn=d(fn,2);l(Rt),l(et);var Cn=d(et,2),zn=f(Cn),ht=f(zn),Ze=d(ht);Ee(Ze),l(zn),l(Cn);var ut=d(Cn,2),Ye=f(ut),rn=d(f(Ye));Ee(rn),l(Ye);var an=d(Ye,2);xe(an,5,()=>n().scenes,Fe,(L,K)=>{var Le=mi(),it=Xt(Le);{var sn=Ut=>{var Be=Rd(),vn=f(Be,!0);l(Be),H(()=>M(vn,r(K).id)),S("click",Be,()=>G(r(A),r(K).id)),O(Ut,Be)};ie(it,Ut=>{r(K).id!==t.selectedScene.id&&Ut(sn)})}O(L,Le)}),l(an),l(ut);var gr=d(ut,2);{var ni=L=>{var K=Ld();O(L,K)};ie(gr,L=>{t.selectedScene.isDialogue&&L(ni)})}var Ar=d(gr,2);{var mr=L=>{var K=Md(),Le=f(K),it=d(Le);{var sn=Ut=>{var Be=Pd(),vn=f(Be);l(Be),H(()=>M(vn,`inv:${r(Ht)??""}`)),O(Ut,Be)};ie(it,Ut=>{r(Ht)&&Ut(sn)})}l(K),H(()=>M(Le,`${r(He).name??""}: ${r(Ae)??""}`)),O(L,K)};ie(Ar,L=>{(r(Ae)||r(Ht))&&L(mr)})}var Cr=d(Ar,2),zr=f(Cr),pr=d(f(zr));Ee(pr);let ki;Mi(pr,L=>C[r(A)]=L,()=>C==null?void 0:C[r(A)]),l(zr);var Ai=d(zr,2);{var ri=L=>{var K=Fd();O(L,K)},ii=W(()=>he(le().condition));ie(Ai,L=>{r(ii)&&L(ri)})}var ma=d(Ai,2);ct(ma,()=>r(A),()=>r(I)===r(A),()=>L=>Z(r(A),L),()=>L=>re(r(A),L),()=>L=>ce(L),()=>()=>{y(I,null)}),l(Cr);var Rn=d(Cr,2),br=f(Rn),Ci=d(f(br),2);{var pa=L=>{var K=Vd(),Le=f(K,!0);l(K),H(()=>M(Le,le().roll)),O(L,K)};ie(Ci,L=>{le().roll&&L(pa)})}var zi=d(Ci,2),Ri=f(zi,!0);l(zi),l(br);var ba=d(br,2);{var J=L=>{var K=Jd(),Le=f(K),it=f(Le);Ee(it),er(2),l(Le);var sn=d(Le,2),Ut=d(f(sn),2);xe(Ut,16,()=>["0","25","50","85","100"],Be=>Be,(Be,vn)=>{const at=W(()=>vn),ps=W(()=>{var Gt;return(Gt=le().rollTiers)==null?void 0:Gt[r(at)]});var bs=Bd(),xa=Xt(bs),ya=f(xa),sl=f(ya);l(ya);var _a=d(ya,2),Li=f(_a);Ee(Li);var hs=d(Li,2);xe(hs,5,()=>n().scenes,Fe,(Gt,Ln)=>{var Rr=mi(),si=Xt(Rr);{var Pi=oi=>{var yr=jd(),li=f(yr,!0);l(yr),H(()=>M(li,r(Ln).id)),S("click",yr,()=>mt(r(A),r(at),"next",r(Ln).id)),O(oi,yr)};ie(si,oi=>{r(Ln).id!==t.selectedScene.id&&oi(Pi)})}O(Gt,Rr)}),l(hs),l(_a);var xs=d(_a,2),ai=f(xs);Ee(ai),l(xs),l(xa);var ol=d(xa,2);{var ll=Gt=>{var Ln=Yd(),Rr=f(Ln),si=d(f(Rr),2),Pi=f(si);xe(Pi,17,()=>r(B),Fe,(Sn,Lt)=>{var Et=Wd(),on=f(Et);l(Et),H(()=>M(on,`${r(Lt)??""}:`)),S("click",Et,()=>Vt(r(A),r(at),r(Lt))),O(Sn,Et)});var oi=d(Pi,2);xe(oi,17,()=>r($),Fe,(Sn,Lt)=>{var Et=Hd(),on=f(Et);l(Et),H(()=>M(on,`${r(Lt)??""}:`)),S("click",Et,()=>Vt(r(A),r(at),r(Lt))),O(Sn,Et)}),l(si);var yr=d(si,2),li=f(yr),cl=d(li,2);l(yr),l(Rr);var ys=d(Rr,2),wa=d(f(ys),2),_s=f(wa);xe(_s,17,()=>r(te),Fe,(Sn,Lt)=>{const Et=W(()=>{var Ss;return(Ss=n().itemOrigins)==null?void 0:Ss[r(Lt)]});var on=Ud(),Lr=f(on),ci=f(Lr);l(Lr);var ui=d(Lr,2),fl=f(ui);l(ui),l(on),H(()=>{Tt(on,"title",r(Et)?`Введено в ${r(Et)} (из превью)`:"Из превью"),M(ci,`+ ${r(Lt)??""}${r(Et)?"↓":""}`),M(fl,`– ${r(Lt)??""}`)}),S("click",Lr,()=>yt(r(A),r(at),"add",r(Lt))),S("click",ui,()=>yt(r(A),r(at),"remove",r(Lt))),O(Sn,on)});var ul=d(_s,2);xe(ul,17,()=>r(ue),Fe,(Sn,Lt)=>{var Et=Gd(),on=f(Et),Lr=f(on);l(on);var ci=d(on,2),ui=f(ci);l(ci),l(Et),H(()=>{M(Lr,`+ ${r(Lt)??""}`),M(ui,`– ${r(Lt)??""}`)}),S("click",on,()=>yt(r(A),r(at),"add",r(Lt))),S("click",ci,()=>yt(r(A),r(at),"remove",r(Lt))),O(Sn,Et)}),l(wa);var ws=d(wa,2),Sa=f(ws),dl=d(Sa,2);l(ws),l(ys),l(Ln),H(()=>{Tt(li,"id",`newTierVar-${r(A)}-${r(at)}`),Tt(Sa,"id",`newTierItem-${r(A)}-${r(at)}`)}),S("keydown",li,Sn=>{Sn.key==="Enter"&&kt(r(A),r(at))}),S("click",cl,()=>kt(r(A),r(at))),S("keydown",Sa,Sn=>{Sn.key==="Enter"&&jt(r(A),r(at))}),S("click",dl,()=>jt(r(A),r(at))),O(Gt,Ln)};ie(ol,Gt=>{r(gt)&&r(gt).index===r(A)&&r(gt).pct===r(at)&&Gt(ll)})}H(()=>{var Gt,Ln;M(sl,`${vn??""}%${vn==="100"?" (крит)":vn==="0"?" (слабый)":""}`),tt(Li,((Gt=r(ps))==null?void 0:Gt.next)||""),tt(ai,((Ln=r(ps))==null?void 0:Ln.effects)||"")}),S("input",Li,Gt=>mt(r(A),r(at),"next",Gt.currentTarget.value)),S("input",ai,Gt=>mt(r(A),r(at),"effects",Gt.currentTarget.value)),Zt("focus",ai,()=>{y(gt,{index:r(A),pct:r(at)},!0)}),S("click",ai,()=>{y(gt,{index:r(A),pct:r(at)},!0)}),O(Be,bs)}),l(sn),er(2),l(K),H(Be=>{tt(it,le().roll),jn(it,1,`w-full bg-zinc-800 p-3 rounded-2xl text-sm font-mono ${Be??""}`)},[()=>{var Be;return(Be=le().roll)!=null&&Be.trim()?"":"border-2 border-red-500"}]),S("input",it,Be=>{Pn(t.selectedScene.id,r(A),vn=>({...vn,roll:Be.currentTarget.value})),yn(r(A))}),O(L,K)},Ie=W(()=>Ue(r(A)));ie(ba,L=>{r(Ie)&&L(J)})}l(Rn);var hr=d(Rn,2),qn=f(hr),qt=d(f(qn));Ee(qt),Mi(qt,L=>Y[r(A)]=L,()=>Y==null?void 0:Y[r(A)]),l(qn);var xr=d(qn,2),cs=f(xr);xe(cs,17,()=>r(B),Fe,(L,K)=>{var Le=qd(),it=f(Le);l(Le),H(()=>M(it,`${r(K)??""}:`)),S("click",Le,()=>ee(r(A),r(K))),O(L,Le)});var nl=d(cs,2);xe(nl,17,()=>r($),Fe,(L,K)=>{var Le=Zd(),it=f(Le);l(Le),H(()=>M(it,`${r(K)??""}:`)),S("click",Le,()=>ee(r(A),r(K))),O(L,Le)}),l(xr);var us=d(xr,2),ds=f(us),rl=d(ds,2);l(us),l(hr);var fs=d(hr,2),ha=d(f(fs),2),vs=f(ha);xe(vs,17,()=>r(te),Fe,(L,K)=>{const Le=W(()=>{var at;return(at=n().itemOrigins)==null?void 0:at[r(K)]});var it=Kd(),sn=f(it),Ut=f(sn);l(sn);var Be=d(sn,2),vn=f(Be);l(Be),l(it),H(()=>{Tt(it,"title",r(Le)?`Введено в ${r(Le)} (из превью)`:"Из превью"),M(Ut,`+ ${r(K)??""}${r(Le)?"↓":""}`),M(vn,`– ${r(K)??""}`)}),S("click",sn,()=>De(r(A),"add",r(K))),S("click",Be,()=>De(r(A),"remove",r(K))),O(L,it)});var il=d(vs,2);xe(il,17,()=>r(ue),Fe,(L,K)=>{var Le=Xd(),it=f(Le),sn=f(it);l(it);var Ut=d(it,2),Be=f(Ut);l(Ut),l(Le),H(()=>{M(sn,`+ ${r(K)??""}`),M(Be,`– ${r(K)??""}`)}),S("click",it,()=>De(r(A),"add",r(K))),S("click",Ut,()=>De(r(A),"remove",r(K))),O(L,Le)}),l(ha);var gs=d(ha,2),ms=f(gs),al=d(ms,2);l(gs),l(fs),l(rt),H((L,K)=>{M(tn,r(A)+1),M(zt,`${t.selectedScene.isDialogue?"Ответ":"Выбор"} ${r(A)+1}`),M(ht,`${t.selectedScene.isDialogue?"Ответ игрока":"Текст выбора"} `),tt(Ze,le().text),Tt(Ze,"placeholder",t.selectedScene.isDialogue?"Ответ игрока":"Текст выбора"),tt(rn,le().next),tt(pr,le().condition),ki=jn(pr,1,"w-full bg-zinc-800 p-4 rounded-2xl mb-2 text-sm border mt-1",null,ki,L),M(Ri,K),tt(qt,le().effects),Tt(ds,"id",`newVariable-${r(A)??""}`),Tt(ms,"id",`newInventoryItem-${r(A)??""}`)},[()=>({"border-red-500":he(le().condition),"border-2":he(le().condition),"border-zinc-700":!he(le().condition)}),()=>Ue(r(A))?"▲":"▼"]),S("click",nn,()=>ye(r(A))),S("click",fn,()=>ei(le())),S("click",Jn,()=>Ce(r(A))),S("input",Ze,L=>Pn(t.selectedScene.id,r(A),K=>({...K,text:L.currentTarget.value}))),S("input",rn,L=>Pn(t.selectedScene.id,r(A),K=>({...K,next:L.currentTarget.value}))),S("input",pr,L=>Pn(t.selectedScene.id,r(A),K=>({...K,condition:L.currentTarget.value}))),S("click",br,()=>{yn(r(A)),Xe(r(A))}),S("input",qt,L=>Pn(t.selectedScene.id,r(A),K=>({...K,effects:L.currentTarget.value}))),S("click",rl,()=>{const L=document.getElementById(`newVariable-${r(A)}`),K=L==null?void 0:L.value.trim();K&&(Fi(K),ee(r(A),K),L.value="")}),S("click",al,()=>{const L=document.getElementById(`newInventoryItem-${r(A)}`),K=L==null?void 0:L.value.trim();K&&(Ms(K),De(r(A),"add",K),L.value="")}),O(Oe,rt)};var lt=f(nt),en=f(lt),Jt=f(en),kn=f(Jt),Qn=f(kn,!0);l(kn);var Me=d(kn,2);{var _n=Oe=>{var le=$d(),A=Xt(le),He=f(A,!0);l(A);var se=d(A,2),me=f(se,!0);l(se),H((wn,dn,Ge)=>{Tt(A,"title",wn),M(He,dn),M(me,Ge)},[()=>un(t.selectedScene.id)?"Развернуть ответы на стартовую реплику":"Свернуть ответы на стартовую реплику (для удобства перетаскивания реплик НПС)",()=>un(t.selectedScene.id)?"▸":"▾",()=>fr(t.selectedScene.id,t.selectedScene.npcResponses||[])?"Развернуть все":"Свернуть все"]),S("click",A,()=>Gn(t.selectedScene.id)),S("click",se,()=>dr(t.selectedScene.id,t.selectedScene.npcResponses||[])),O(Oe,le)};ie(Me,Oe=>{t.selectedScene.isDialogue&&Oe(_n)})}var An=d(Me,2),ti=f(An);l(An),l(Jt);var Tr=d(Jt,2),Bn=f(Tr),Or=f(Bn);l(Bn);var vr=d(Bn,2);{var Nr=Oe=>{var le=ef();S("click",le,Tn),O(Oe,le)};ie(vr,Oe=>{t.selectedScene.isDialogue&&Oe(Nr)})}l(Tr),l(en),l(lt);var kr=d(lt,2);{var Xo=Oe=>{var le=tf();xe(le,23,()=>r(Yn),(A,He)=>A.id?`${A.id}-${He}`:`no-id-${He}`,(A,He)=>{We(A,()=>r(He))}),l(le),Mi(le,A=>y(Q,A),()=>r(Q)),Bi(le,(A,He)=>gn==null?void 0:gn(A,He),()=>({items:r(Yn),flipDurationMs:200,type:"player-answer"})),H(()=>Tt(le,"aria-label",t.selectedScene.isDialogue?"Ответы на стартовую реплику":"Выборы")),Zt("consider",le,A=>Se(A,0)),Zt("finalize",le,A=>oe(A,0)),O(Oe,le)},Qo=W(()=>!un(t.selectedScene.id)||!t.selectedScene.isDialogue),$o=Oe=>{var le=nf(),A=d(f(le),2),He=f(A);l(A),l(le),H(()=>M(He,`${r(Yn).length??""} ответов на стартовую реплику (свёрнуто)`)),S("click",le,()=>Gn(t.selectedScene.id)),S("keydown",le,se=>{(se.key==="Enter"||se.key===" ")&&(se.preventDefault(),Gn(t.selectedScene.id))}),O(Oe,le)};ie(kr,Oe=>{r(Qo)?Oe(Xo):Oe($o,!1)})}var el=d(kr,2);{var tl=Oe=>{var le=vf(),A=f(le);xe(A,23,()=>t.selectedScene.npcResponses||[],(He,se)=>He.id?`${He.id}-${se}`:se,(He,se,me)=>{var wn=ff(),dn=f(wn),Ge=f(dn),Ae=d(f(Ge),2),Ht=f(Ae,!0);l(Ae),l(Ge);var rt=d(Ge,2);l(dn);var et=d(dn,2);{var Ct=Dt=>{var zt=rf(),Rt=f(zt),nn=f(Rt),fn=f(nn);l(nn);var Jn=d(nn,2),Cn=f(Jn);l(Jn),er(2),l(Rt);var zn=d(Rt,2);l(zt),H(ht=>{M(fn,`${(r(se).npcName||t.selectedScene.npcName||"НПС")??""}${r(se).emotion?` (${r(se).emotion})`:""}:`),M(Cn,`${ht??""}${(r(se).text||"").length>75?"…":""}`)},[()=>(r(se).text||"").replace(/\s*\n\s*/g," ").slice(0,75)]),S("click",Rt,()=>Un(r(se).id,r(me))),S("keydown",Rt,ht=>{(ht.key==="Enter"||ht.key===" ")&&(ht.preventDefault(),Un(r(se).id,r(me)))}),S("click",zn,()=>On(r(me)+1)),O(Dt,zt)},It=W(()=>Nn(r(se).id,r(me))),tn=Dt=>{var zt=df(),Rt=Xt(zt),nn=f(Rt),fn=d(f(nn));Ee(fn),l(nn);var Jn=d(nn,2);{var Cn=J=>{var Ie=sf();xe(Ie,21,()=>[...new Set(r(F))],Fe,(hr,qn)=>{var qt=af(),xr=f(qt,!0);l(qt),H(()=>M(xr,r(qn))),S("click",qt,()=>Qe(r(me),r(qn))),O(hr,qt)}),l(Ie),O(J,Ie)};ie(Jn,J=>{r(F).length>0&&J(Cn)})}l(Rt);var zn=d(Rt,2),ht=f(zn),Ze=d(f(ht));Ee(Ze),l(ht);var ut=d(ht,2);{var Ye=J=>{var Ie=lf();xe(Ie,21,()=>[...new Set(r(T))],Fe,(hr,qn)=>{var qt=of(),xr=f(qt,!0);l(qt),H(()=>M(xr,r(qn))),S("click",qt,()=>At(r(me),r(qn))),O(hr,qt)}),l(Ie),O(J,Ie)};ie(ut,J=>{r(T).length>0&&J(Ye)})}l(zn);var rn=d(zn,2),an=f(rn);l(rn);var gr=d(rn,2);Fa(gr);var ni=d(gr,2),Ar=f(ni),mr=d(f(Ar));Ee(mr);let Cr;Mi(mr,(J,Ie)=>V[Ie]=J,J=>V==null?void 0:V[J],()=>[r(me)]),l(Ar);var zr=d(Ar,2);{var pr=J=>{var Ie=cf();O(J,Ie)},ki=W(()=>he(r(se).condition));ie(zr,J=>{r(ki)&&J(pr)})}var Ai=d(zr,2);ct(Ai,()=>r(me),()=>r(b)===r(me),()=>J=>Kn(r(me),J),()=>J=>Qr(r(me),J),()=>J=>$r(J),()=>()=>{y(b,null)}),l(ni);var ri=d(ni,2),ii=f(ri),ma=d(f(ii),2);l(ii);var Rn=d(ii,2),br=f(Rn);xe(br,19,()=>t.selectedScene.choices.filter(J=>J.npcLineIndex===r(me)+1),(J,Ie)=>J.id?`${J.id}-${Ie}`:`no-id-a${Ie}`,(J,Ie)=>{We(J,()=>r(Ie))});var Ci=d(br,2);{var pa=J=>{var Ie=uf();O(J,Ie)},zi=W(()=>!t.selectedScene.choices.some(J=>J.npcLineIndex===r(me)+1));ie(Ci,J=>{r(zi)&&J(pa)})}l(Rn),Bi(Rn,(J,Ie)=>gn==null?void 0:gn(J,Ie),()=>({items:t.selectedScene.choices.filter(J=>J.npcLineIndex===r(me)+1),flipDurationMs:200,type:"player-answer"})),l(ri);var Ri=d(ri,2),ba=f(Ri);l(Ri),H(J=>{tt(fn,r(se).npcName||""),tt(Ze,r(se).emotion||""),M(an,`${(r(se).npcName||t.selectedScene.npcName||"НПС")??""}${r(se).emotion?` (${r(se).emotion})`:""}: Реплика НПС`),tt(gr,r(se).text),tt(mr,r(se).condition||""),Cr=jn(mr,1,"w-full bg-zinc-800 p-2 rounded-xl text-sm mb-1 border mt-1",null,Cr,J),Tt(Rn,"aria-label",`Ответы игрока для реплики ${r(me)+1}`)},[()=>({"border-red-500":he(r(se).condition),"border-2":he(r(se).condition),"border-zinc-700":!he(r(se).condition)})]),S("input",fn,J=>{const Ie=J.currentTarget.value.trim()||void 0;Qe(r(me),Ie)}),Zt("blur",fn,J=>{const Ie=J.currentTarget.value.trim();Ie&&!r(F).includes(Ie)&&Fs(Ie)}),S("input",Ze,J=>{const Ie=J.currentTarget.value.trim()||void 0;At(r(me),Ie)}),Zt("blur",Ze,J=>{const Ie=J.currentTarget.value.trim();Ie&&!r(T).includes(Ie)&&Vs(Ie)}),S("input",gr,J=>lr(r(me),J.currentTarget.value)),S("input",mr,J=>cr(r(me),J.currentTarget.value.trim()||void 0)),S("click",ma,()=>On(r(me)+1)),Zt("consider",Rn,J=>Se(J,r(me)+1)),Zt("finalize",Rn,J=>oe(J,r(me)+1)),S("click",ba,Tn),O(Dt,zt)};ie(et,Dt=>{r(It)?Dt(Ct):Dt(tn,!1)})}l(wn),H((Dt,zt)=>{Tt(Ae,"title",Dt),M(Ht,zt)},[()=>Nn(r(se).id,r(me))?"Развернуть реплику (показать полный текст и ответы)":"Свернуть реплику (компактно для удобства переноса)",()=>Nn(r(se).id,r(me))?"▸":"▾"]),S("click",Ae,()=>Un(r(se).id,r(me))),S("click",rt,()=>Ve(r(me))),O(He,wn)}),l(A),Bi(A,(He,se)=>gn==null?void 0:gn(He,se),()=>({items:t.selectedScene.npcResponses||[],flipDurationMs:200,type:"npc-response"})),l(le),Zt("consider",A,ne),Zt("finalize",A,ae),O(Oe,le)};ie(el,Oe=>{t.selectedScene.isDialogue&&Oe(tl)})}l(nt),H(()=>{M(Qn,t.selectedScene.isDialogue?"Ответы на стартовую реплику":"Выборы"),M(ti,`Всего: ${t.selectedScene.choices.length??""} шт.`),M(Or,`+ ${t.selectedScene.isDialogue?"Добавить ответ":"Добавить выбор"}`)}),S("click",Bn,Ne)}H(()=>{tt(m,t.selectedScene.id),mo(ve,!!t.selectedScene.isDialogue),M(pt,t.selectedScene.isDialogue?"Стартовая реплика НПС":"Текст сцены"),tt(bt,t.selectedScene.text)}),Zt("blur",m,ct=>{const We=ct.currentTarget.value.trim();if(!t.selectedScene||!We||We===t.selectedScene.id)return;if(!Te(We,t.selectedScene.id)){alert("❌ ID сцены должен быть уникальным!"),ct.currentTarget.value=t.selectedScene.id;return}const Oe=t.selectedScene.id;Fc(Oe,We),n().scenes.length>0,Pt.set(We)}),S("change",ve,ct=>{if(!t.selectedScene)return;const We=t.selectedScene.id;dt(We,Oe=>({...Oe,isDialogue:ct.currentTarget.checked}))}),S("input",bt,ct=>{const We=a();We&&dt(We,Oe=>({...Oe,text:ct.currentTarget.value}))}),O(v,x)};ie(qe,v=>{t.selectedScene&&v(Pe)})}O(e,be),qr(),u()}Zr(["change","input","click","keydown"]);const pf="ist-game-save-slot-",Wo="ist-game-autosave";function Ho(e){return`${pf}${e}`}const aa=Xr(1);function Uo(e,t,n,i,s="",a=0,o={}){const u={slot:e,sceneId:t,variables:{...n},items:{...i},timestamp:new Date().toLocaleString("ru-RU"),dialogueHistory:s,currentDialogueStep:a,sceneStates:o&&Object.keys(o).length>0?{...o}:void 0};localStorage.setItem(Ho(e),JSON.stringify(u)),aa.set(e)}function bf(e,t,n,i="",s=0,a={}){const o=Er(aa);Uo(o,e,t,n,i,s,a)}function Go(e){const t=localStorage.getItem(Ho(e));if(!t)return null;const n=JSON.parse(t);return n.dialogueHistory=n.dialogueHistory||"",n.currentDialogueStep=n.currentDialogueStep||0,n}function Wi(){const e=[];for(let t=1;t<=4;t++)e.push(Go(t));return e}function eo(e,t,n,i="",s=0,a={}){const o={slot:0,sceneId:e,variables:{...t},items:{...n},timestamp:new Date().toLocaleString("ru-RU"),dialogueHistory:i,currentDialogueStep:s,sceneStates:a&&Object.keys(a).length>0?{...a}:void 0};localStorage.setItem(Wo,JSON.stringify(o))}function Hi(){const e=localStorage.getItem(Wo);if(!e)return null;const t=JSON.parse(e);return t.dialogueHistory=t.dialogueHistory||"",t.currentDialogueStep=t.currentDialogueStep||0,t}var hf=N('<div class="text-center"><div class="text-xs opacity-60 uppercase"> </div> <div class="text-2xl font-bold text-emerald-400"> </div></div>'),xf=N('<div class="text-center"><div class="text-sm text-amber-300"> </div> <div class="text-2xl font-bold text-amber-400"> </div></div>'),yf=N('<label class="flex items-center gap-1.5 cursor-pointer select-none"><input type="checkbox"/> <span class="font-mono"> </span></label>'),_f=N('<button class="ml-2 px-2 py-0.5 text-red-400 hover:text-red-300 hover:bg-zinc-800 rounded text-[10px] transition">Clear force</button>'),wf=N('<div class="text-center text-sm"><div class="text-xs opacity-60"> </div> <div class="font-bold text-emerald-400"> </div></div>'),Sf=N('<div class="text-center text-sm"><div class="text-xs opacity-60"> </div> <div class="font-bold text-amber-400"> </div></div>'),If=N('<div class="mt-2 space-y-2 pl-4 border-l-2 border-zinc-700"><div><div class="text-xs opacity-60 uppercase mb-1">Характеристики (старт)</div> <div class="flex flex-wrap gap-4"></div></div> <div><div class="text-xs opacity-60 uppercase mb-1">Инвентарь (старт)</div> <div class="flex flex-wrap gap-4"></div></div></div>'),Df=N('<button class="text-blue-400 hover:text-blue-300 underline transition">✏️ Редактировать в редакторе</button>'),Ef=N('<button title="Вернуться к состоянию при прибытии в эту сцену"> </button>'),Tf=N('<div class="mb-3 text-sm"><details><summary class="cursor-pointer font-medium text-xs opacity-70">📜 История прохождения — вернуться к сцене</summary> <div class="mt-1 flex flex-wrap gap-1"></div></details></div>'),Of=N('<button class="mt-4 bg-amber-600 hover:bg-amber-500 px-8 py-3 rounded-2xl text-sm font-medium transition"> </button>'),Nf=N('<button class="mt-4 bg-zinc-700 hover:bg-zinc-600 px-8 py-3 rounded-2xl text-sm font-medium transition">✏️ Редактировать эту сцену</button>'),kf=N('<div class="text-center py-20"><div class="text-[120px] mb-8">🏁</div> <h2 class="text-5xl font-bold mb-4 text-amber-300">Конец истории</h2> <p class="text-2xl text-zinc-400 max-w-md mx-auto mb-12">Ты дошёл до финала этой ветки.<br/> Спасибо за игру!</p> <button class="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 px-16 py-6 rounded-3xl text-2xl font-medium transition-all active:scale-95 shadow-2xl">Начать историю заново</button> <!> <!></div>'),Af=N('<span class="text-xs opacity-60 ml-2"> </span>'),Cf=N('<button class="w-full bg-zinc-800 hover:bg-blue-600 p-6 rounded-2xl text-left transition text-lg"> <!></button>'),zf=N('<div class="text-center text-sm text-zinc-500 mt-4">Ветка диалога завершена (нет больше ответов для текущей реплики НПС).</div>'),Rf=N('<div class="grid gap-4"></div> <!>',1),Lf=N('<div class="text-sm font-medium text-emerald-400 truncate"> </div> <div class="text-[10px] opacity-50"> </div>',1),Pf=N('<div class="text-sm text-zinc-500 italic">Пусто</div>'),Mf=N('<button><div class="text-xs opacity-60"> </div> <!></button>'),Ff=N('<span class="text-emerald-400 font-medium"> </span>'),Vf=N('<span class="text-zinc-500">нет</span>'),jf=N('<div class="text-xs text-emerald-400 mt-1"> </div>'),Wf=N('<button class="p-6 bg-zinc-800 hover:bg-zinc-700 rounded-2xl text-left"> <!></button>'),Hf=N('<div class="fixed inset-0 bg-black/80 flex items-center justify-center z-50"><div class="bg-zinc-900 rounded-3xl p-8 max-w-md w-full"><h3 class="text-xl font-semibold mb-6">Сохранить в слот</h3> <div class="grid grid-cols-2 gap-4"></div> <button class="mt-6 w-full py-3 text-zinc-400 hover:text-white">Отмена</button></div></div>'),Uf=N('<div class="p-12 max-w-3xl mx-auto flex-1 flex flex-col"><div class="bg-zinc-900/80 p-4 rounded-2xl mb-6 flex gap-6 justify-center text-sm"></div> <div class="bg-zinc-900/80 p-4 rounded-2xl mb-6"><div class="text-xs opacity-60 uppercase mb-2">🎒 Инвентарь</div> <div class="flex flex-wrap gap-x-8 gap-y-2"></div></div> <div class="mb-4 p-3 bg-zinc-900/60 rounded-2xl text-xs border border-zinc-700"><div class="opacity-70 mb-1.5 font-medium">Test tiers (preview only — forces outcome, no random roll):</div> <div class="flex gap-4 flex-wrap items-center"><!> <!></div> <div class="text-[10px] opacity-50 mt-1">When a roll choice is clicked, the selected tier will be used instead of rolling.</div></div> <div class="mb-4"><button class="w-full flex items-center justify-between px-4 py-3 bg-zinc-900/60 hover:bg-zinc-900/80 rounded-2xl text-left transition border border-zinc-700"><span class="font-medium">Стартовый объект (начальные значения)</span> <span class="text-sm opacity-60"> </span></button> <!></div> <div class="flex justify-between items-center mb-2 px-1 text-xs"><div class="text-zinc-500">Текущая сцена: <span class="font-mono text-zinc-400"> </span></div> <!></div> <!> <div class="bg-zinc-900 p-12 rounded-3xl shadow-2xl border border-zinc-700 min-h-[50vh] font-serif text-xl leading-relaxed flex-1 whitespace-pre-wrap"><!></div> <div class="mt-8"><!></div> <div class="mt-8 bg-zinc-900 border border-zinc-700 rounded-3xl p-6"><div class="flex items-center justify-between mb-4"><h3 class="text-lg font-medium">💾 Сохранения</h3> <div class="flex gap-3"><button class="bg-emerald-600 hover:bg-emerald-500 px-6 py-2 rounded-2xl text-sm font-medium">Сохранить</button> <button class="bg-amber-600 hover:bg-amber-500 px-6 py-2 rounded-2xl text-sm font-medium">Сохранить в слот...</button></div></div> <div class="grid grid-cols-4 gap-3"></div> <div class="mt-4 pt-4 border-t border-zinc-700 flex items-center justify-between text-xs"><div>Автосохранение: <!></div> <button class="bg-zinc-700 hover:bg-zinc-600 px-3 py-1 rounded-xl text-xs transition">Загрузить автосохранение</button></div></div></div> <!>',1);function Gf(e,t){Jr(t,!0);const n=()=>bn(st,"$storyStore",i),[i,s]=Kr();let a=Yt(t,"previewSceneId",7),o=Yt(t,"previewVars",7),u=Yt(t,"previewItems",7),c=Yt(t,"dialogueHistory",7,""),p=Yt(t,"currentDialogueStep",7,0),g=Yt(t,"previousSceneId",3,null),I=Yt(t,"forcedRollTier",3,null),b=Yt(t,"startingVariables",19,()=>({})),h=Yt(t,"startingItems",19,()=>({})),E=Yt(t,"sceneStates",19,()=>({})),F=fe(!1);function T(k){var pe;const R=(pe=E())==null?void 0:pe[k];if(!R)return;const B={...R.variables},te={...R.items};t.onPreviewVarsChange&&t.onPreviewVarsChange(B),t.onPreviewItemsChange&&t.onPreviewItemsChange(te),o(B),u(te),t.onPreviewSceneIdChange&&t.onPreviewSceneIdChange(k),a(k),t.onDialogueHistoryChange&&t.onDialogueHistoryChange(""),t.onCurrentDialogueStepChange&&t.onCurrentDialogueStepChange(0),c(""),p(0)}let C=W(()=>a()==="end"?null:n().scenes.find(k=>k.id===a())||n().scenes[0]||null),V=fe(!1),Y=fe(Mt(Wi())),Q=fe(Mt(Hi()));pn(()=>{const k=r(C);if(!(k!=null&&k.text))return;const R={variables:{...o()},items:{...u()}},B=mc(k.text,R);JSON.stringify(B.items)!==JSON.stringify(R.items)&&wo(B.items,a()),So(B.variables||{},a())});function ye(k){const R={variables:{...o()},items:{...u()}};return gc(k,R,n().characterName)}let Ne=W(()=>{var k;return(((k=r(C))==null?void 0:k.choices)||[]).filter(R=>{var de;const B={variables:{...o()},items:{...u()}},te=vc(R.condition,B);if(!((de=r(C))!=null&&de.isDialogue))return te;const pe=R.npcLineIndex||0;return te&&pe===p()})}),_e=W(()=>{var k;return a()==="end"||r(Ne).length===0&&!((k=r(C))!=null&&k.isDialogue)});pn(()=>{a()&&(eo(a(),o(),u(),c(),p(),E()),y(Q,Hi(),!0))}),setInterval(()=>{a()&&(eo(a(),o(),u(),c(),p(),E()),y(Q,Hi(),!0))},3e4);function Ce(){bf(a(),o(),u(),c(),p(),E()),y(Y,Wi(),!0),alert(`💾 Быстрое сохранение в слот ${Er(aa)}`)}function Ve(){y(V,!0),y(Y,Wi(),!0)}function Se(k){Uo(k,a(),o(),u(),c(),p(),E()),y(Y,Wi(),!0),y(V,!1),alert(`💾 Сохранено в слот ${k}`)}function oe(k){var ue;const R=Go(k);if(!R)return alert("❌ Слот пустой");const B=R.sceneId||((ue=n().scenes[0])==null?void 0:ue.id)||"";t.onPreviewSceneIdChange&&t.onPreviewSceneIdChange(B),a(B);const te={...R.variables},pe={...R.items};t.onPreviewVarsChange&&t.onPreviewVarsChange(te),t.onPreviewItemsChange&&t.onPreviewItemsChange(pe),o(te),u(pe),Wn(()=>({...R.items}));const de=R.dialogueHistory||"",$=R.currentDialogueStep||0;t.onDialogueHistoryChange&&t.onDialogueHistoryChange(de),t.onCurrentDialogueStepChange&&t.onCurrentDialogueStepChange($),c(de),p($),R.sceneStates&&t.onSceneStatesChange&&t.onSceneStatesChange({...R.sceneStates}),aa.set(k),y(V,!1),alert(`✅ Загружен слот ${k}`)}function ne(){var $;const k=Hi();if(!k)return alert("❌ Автосохранение пустое");const R=k.sceneId||(($=n().scenes[0])==null?void 0:$.id)||"";t.onPreviewSceneIdChange&&t.onPreviewSceneIdChange(R),a(R);const B={...k.variables},te={...k.items};t.onPreviewVarsChange&&t.onPreviewVarsChange(B),t.onPreviewItemsChange&&t.onPreviewItemsChange(te),o(B),u(te),Wn(()=>({...k.items}));const pe=k.dialogueHistory||"",de=k.currentDialogueStep||0;t.onDialogueHistoryChange&&t.onDialogueHistoryChange(pe),t.onCurrentDialogueStepChange&&t.onCurrentDialogueStepChange(de),c(pe),p(de),k.sceneStates&&t.onSceneStatesChange&&t.onSceneStatesChange({...k.sceneStates}),y(Q,k,!0),alert("✅ Загружено автосохранение")}var ae=Uf(),G=Xt(ae),P=f(G);xe(P,21,()=>Object.entries(o()).filter(([,k])=>k!==0),Fe,(k,R)=>{var B=W(()=>jr(r(R),2));let te=()=>r(B)[0],pe=()=>r(B)[1];var de=hf(),$=f(de),ue=f($,!0);l($);var be=d($,2),qe=f(be,!0);l(be),l(de),H(()=>{M(ue,te()),M(qe,pe())}),O(k,de)}),l(P);var re=d(P,2),Z=d(f(re),2);xe(Z,21,()=>Object.entries(u()),Fe,(k,R)=>{var B=W(()=>jr(r(R),2));let te=()=>r(B)[0],pe=()=>r(B)[1];var de=mi(),$=Xt(de);{var ue=be=>{var qe=xf(),Pe=f(qe),v=f(Pe,!0);l(Pe);var x=d(Pe,2),_=f(x,!0);l(x),l(qe),H(()=>{M(v,te()),M(_,pe())}),O(be,qe)};ie($,be=>{pe()!==0&&be(ue)})}O(k,de)}),l(Z),l(re);var ce=d(re,2),ee=d(f(ce),2),De=f(ee);xe(De,16,()=>[0,25,50,85,100],k=>k,(k,R)=>{var B=yf(),te=f(B);Ee(te);var pe=d(te,2),de=f(pe);l(pe),l(B),H(()=>{mo(te,I()===R),M(de,`${R??""}%`)}),S("change",te,$=>{var ue,be;$.currentTarget.checked?(ue=t.onForcedRollTierChange)==null||ue.call(t,R):I()===R&&((be=t.onForcedRollTierChange)==null||be.call(t,null))}),O(k,B)});var je=d(De,2);{var Re=k=>{var R=_f();S("click",R,()=>{var B;return(B=t.onForcedRollTierChange)==null?void 0:B.call(t,null)}),O(k,R)};ie(je,k=>{I()!=null&&k(Re)})}l(ee),er(2),l(ce);var ze=d(ce,2),Xe=f(ze),Ue=d(f(Xe),2),Te=f(Ue,!0);l(Ue),l(Xe);var he=d(Xe,2);{var ke=k=>{var R=If(),B=f(R),te=d(f(B),2);xe(te,21,()=>Object.entries(b()),Fe,($,ue)=>{var be=W(()=>jr(r(ue),2));let qe=()=>r(be)[0],Pe=()=>r(be)[1];var v=wf(),x=f(v),_=f(x,!0);l(x);var w=d(x,2),U=f(w,!0);l(w),l(v),H(()=>{M(_,qe()),M(U,Pe())}),O($,v)}),l(te),l(B);var pe=d(B,2),de=d(f(pe),2);xe(de,21,()=>Object.entries(h()),Fe,($,ue)=>{var be=W(()=>jr(r(ue),2));let qe=()=>r(be)[0],Pe=()=>r(be)[1];var v=Sf(),x=f(v),_=f(x,!0);l(x);var w=d(x,2),U=f(w,!0);l(w),l(v),H(()=>{M(_,qe()),M(U,Pe())}),O($,v)}),l(de),l(pe),l(R),O(k,R)};ie(he,k=>{r(F)&&k(ke)})}l(ze);var gt=d(ze,2),mt=f(gt),yn=d(f(mt)),Vt=f(yn,!0);l(yn),l(mt);var yt=d(mt,2);{var kt=k=>{var R=Df();S("click",R,function(...B){var te;(te=t.onEditCurrent)==null||te.apply(this,B)}),O(k,R)};ie(yt,k=>{t.onEditCurrent&&k(kt)})}l(gt);var jt=d(gt,2);{var Tn=k=>{var R=Tf(),B=f(R),te=d(f(B),2);xe(te,21,()=>Object.keys(E()),Fe,(pe,de)=>{var $=Ef(),ue=f($,!0);l($),H(()=>{jn($,1,`text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 ${r(de)===a()?"bg-blue-800 text-white":""}`),M(ue,r(de))}),S("click",$,()=>T(r(de))),O(pe,$)}),l(te),l(B),l(R),O(k,R)},On=W(()=>Object.keys(E()||{}).length>1);ie(jt,k=>{r(On)&&k(Tn)})}var Qe=d(jt,2),At=f(Qe);Kl(At,()=>{var k,R;return ye((k=r(C))!=null&&k.isDialogue&&c()?c():((R=r(C))==null?void 0:R.text)||"🏁 Конец истории...")}),l(Qe);var lr=d(Qe,2),cr=f(lr);{var Qr=k=>{var R=kf(),B=d(f(R),6),te=d(B,2);{var pe=ue=>{var be=Of(),qe=f(be);l(be),H(()=>M(qe,`↩️ Вернуться в предыдущую сцену ${g()??""}`)),S("click",be,function(...Pe){var v;(v=t.onReturnToPreviousScene)==null||v.apply(this,Pe)}),O(ue,be)};ie(te,ue=>{g()&&t.onReturnToPreviousScene&&ue(pe)})}var de=d(te,2);{var $=ue=>{var be=Nf();S("click",be,function(...qe){var Pe;(Pe=t.onEditCurrent)==null||Pe.apply(this,qe)}),O(ue,be)};ie(de,ue=>{t.onEditCurrent&&ue($)})}l(R),S("click",B,function(...ue){var be;(be=t.onRestart)==null||be.apply(this,ue)}),O(k,R)},$r=k=>{var R=Rf(),B=Xt(R);xe(B,21,()=>r(Ne),Fe,(de,$)=>{var ue=Cf(),be=f(ue),qe=d(be);{var Pe=v=>{var x=Af(),_=f(x);l(x),H(()=>M(_,`(${r($).roll??""})`)),O(v,x)};ie(qe,v=>{r($).roll&&v(Pe)})}l(ue),H(()=>{var v;return M(be,`${(v=r(C))!=null&&v.isDialogue?"Вы: ":""}${r($).text??""} `)}),S("click",ue,()=>t.makeChoice(r($))),O(de,ue)}),l(B);var te=d(B,2);{var pe=de=>{var $=zf();O(de,$)};ie(te,de=>{var $;($=r(C))!=null&&$.isDialogue&&r(Ne).length===0&&de(pe)})}O(k,R)};ie(cr,k=>{r(_e)?k(Qr):k($r,!1)})}l(lr);var Kn=d(lr,2),ur=f(Kn),Hn=d(f(ur),2),Je=f(Hn),Un=d(Je,2);l(Hn),l(ur);var Nn=d(ur,2);xe(Nn,21,()=>r(Y),Fe,(k,R,B)=>{const te=W(()=>B+1);var pe=Mf(),de=f(pe),$=f(de);l(de);var ue=d(de,2);{var be=Pe=>{var v=Lf(),x=Xt(v),_=f(x,!0);l(x);var w=d(x,2),U=f(w,!0);l(w),H(()=>{M(_,r(R).sceneId),M(U,r(R).timestamp)}),O(Pe,v)},qe=Pe=>{var v=Pf();O(Pe,v)};ie(ue,Pe=>{r(R)?Pe(be):Pe(qe,!1)})}l(pe),H(()=>{jn(pe,1,`p-4 rounded-2xl border transition text-left ${r(R)?"border-emerald-600 bg-emerald-950/50":"border-zinc-700 bg-zinc-950"}`),M($,`Слот ${r(te)??""}`)}),S("click",pe,()=>oe(r(te))),O(k,pe)}),l(Nn);var ot=d(Nn,2),un=f(ot),Gn=d(f(un));{var Xn=k=>{var R=Ff(),B=f(R);l(R),H(()=>M(B,`${r(Q).timestamp??""} — ${r(Q).sceneId??""}`)),O(k,R)},dr=k=>{var R=Vf();O(k,R)};ie(Gn,k=>{r(Q)?k(Xn):k(dr,!1)})}l(un);var fr=d(un,2);l(ot),l(Kn),l(G);var Yn=d(G,2);{var ei=k=>{var R=Hf(),B=f(R),te=d(f(B),2);xe(te,20,()=>Array.from({length:4},(de,$)=>$+1),Fe,(de,$)=>{var ue=Wf(),be=f(ue),qe=d(be);{var Pe=v=>{var x=jf(),_=f(x,!0);l(x),H(()=>M(_,r(Y)[$-1].timestamp)),O(v,x)};ie(qe,v=>{r(Y)[$-1]&&v(Pe)})}l(ue),H(()=>M(be,`Слот ${$??""} `)),S("click",ue,()=>Se($)),O(de,ue)}),l(te);var pe=d(te,2);l(B),l(R),S("click",pe,()=>y(V,!1)),O(k,R)};ie(Yn,k=>{r(V)&&k(ei)})}H(()=>{M(Te,r(F)?"▼":"▶"),M(Vt,a())}),S("click",Xe,()=>y(F,!r(F))),S("click",Je,Ce),S("click",Un,Ve),S("click",fr,ne),O(e,ae),qr(),s()}Zr(["change","click"]);var Yf=N('<div class="bg-zinc-900 p-5 rounded-2xl flex items-center gap-4"><input class="flex-1 bg-zinc-800 p-4 rounded-xl"/> <input type="number" class="w-24 bg-zinc-800 p-4 rounded-xl text-center"/> <span class="text-[10px] text-amber-400/70 px-2 py-0.5 bg-amber-950/40 rounded whitespace-nowrap" title="Сцена введения предмета"> </span> <button class="text-red-400 hover:text-red-500 px-4">✕</button></div>'),Bf=N('<div class="bg-zinc-900/50 p-4 rounded-xl flex items-center gap-3 text-sm"><input class="flex-1 bg-zinc-800 p-3 rounded-xl text-sm"/> <input type="number" class="w-20 bg-zinc-800 p-2 rounded text-center"/> <span class="text-[9px] text-amber-400/70 px-1.5 py-0.5 bg-amber-950/30 rounded whitespace-nowrap" title="Сцена введения (для стартового)"> </span> <button class="text-red-400 hover:text-red-500 px-2 text-sm">✕</button></div>'),Jf=N('<div class="text-xs text-zinc-500 italic p-2">Нет сохранённых начальных значений (будут установлены при первом входе в превью или при добавлении здесь).</div>'),qf=N('<div class="mt-2 space-y-2 pl-2 border-l-2 border-zinc-700"><!> <!> <div class="mt-3 flex gap-2"><input placeholder="Название предмета (в стартовый)" class="flex-1 bg-zinc-800 p-2.5 rounded-xl text-sm"/> <input type="number" class="w-20 bg-zinc-800 p-2.5 rounded-xl text-center text-sm"/> <button class="bg-emerald-600 hover:bg-emerald-500 px-4 rounded-xl text-sm">+ Добавить</button></div></div> <button class="mt-2 w-full text-sm bg-zinc-700 hover:bg-zinc-600 px-3 py-1.5 rounded-xl transition">Сбросить текущий инвентарь к стартовому</button>',1),Zf=N('<div class="p-8 overflow-auto"><div class="max-w-2xl mx-auto"><h3 class="text-xl font-semibold mb-6">🎒 Инвентарь</h3> <div class="space-y-3 mb-8"></div> <div class="flex gap-3"><input placeholder="Название предмета" class="flex-1 bg-zinc-800 p-4 rounded-xl"/> <input type="number" class="w-24 bg-zinc-800 p-4 rounded-xl text-center"/> <button class="bg-emerald-600 hover:bg-emerald-500 px-8 rounded-xl">+ Добавить</button></div>   <div class="mt-8"><button class="w-full flex items-center justify-between px-4 py-3 bg-zinc-800 hover:bg-zinc-700 rounded-2xl text-left transition"><span class="font-medium">Стартовый объект (начальные значения)</span> <span class="text-sm opacity-60"> </span></button> <!></div></div></div>');function Kf(e,t){Jr(t,!0);const n=()=>bn(st,"$storyStore",i),[i,s]=Kr();let a=Yt(t,"startingItems",19,()=>({})),o=fe(""),u=fe(1),c=fe(""),p=fe(1),g=fe(!1);function I(){var P;const ae=r(o).trim();if(!ae)return;const G=n().startScene||(((P=n().scenes[0])==null?void 0:P.id)??"scene1");jc(ae,r(u),G),y(o,""),y(u,1)}function b(ae){Gc(ae)}function h(ae,G){G<0&&(G=0),Wn(P=>({...P,[ae]:G}))}function E(ae,G){Hc(ae,G)}function F(){const ae=r(c).trim();ae&&(t.onAddStartingItem&&t.onAddStartingItem(ae,r(p)),y(c,""),y(p,1))}var T=Zf(),C=f(T),V=d(f(C),2);xe(V,5,()=>Object.entries(n().items),Fe,(ae,G)=>{var P=W(()=>jr(r(G),2));let re=()=>r(P)[0],Z=()=>r(P)[1];const ce=W(()=>{var Te;return(Te=n().itemOrigins)==null?void 0:Te[re()]}),ee=W(()=>r(ce)?`введено в ${r(ce)}`:"базовый");var De=Yf(),je=f(De);Ee(je);var Re=d(je,2);Ee(Re);var ze=d(Re,2),Xe=f(ze,!0);l(ze);var Ue=d(ze,2);l(De),H(()=>{tt(je,re()),tt(Re,Z()),M(Xe,r(ee))}),S("input",je,Te=>E(re(),Te.currentTarget.value)),S("input",Re,Te=>h(re(),parseInt(Te.currentTarget.value)||0)),S("click",Ue,()=>b(re())),O(ae,De)}),l(V);var Y=d(V,2),Q=f(Y);Ee(Q);var ye=d(Q,2);Ee(ye);var Ne=d(ye,2);l(Y);var _e=d(Y,2),Ce=f(_e),Ve=d(f(Ce),2),Se=f(Ve,!0);l(Ve),l(Ce);var oe=d(Ce,2);{var ne=ae=>{var G=qf(),P=Xt(G),re=f(P);xe(re,17,()=>Object.entries(a()),Fe,(Ue,Te)=>{var he=W(()=>jr(r(Te),2));let ke=()=>r(he)[0],gt=()=>r(he)[1];const mt=W(()=>{var Qe;return(Qe=n().itemOrigins)==null?void 0:Qe[ke()]}),yn=W(()=>r(mt)?`введено в ${r(mt)}`:"базовый");var Vt=Bf(),yt=f(Vt);Ee(yt);var kt=d(yt,2);Ee(kt);var jt=d(kt,2),Tn=f(jt,!0);l(jt);var On=d(jt,2);l(Vt),H(()=>{tt(yt,ke()),tt(kt,gt()),M(Tn,r(yn))}),S("input",yt,Qe=>{const At=Qe.currentTarget.value;t.onRenameStartingItem&&t.onRenameStartingItem(ke(),At)}),S("input",kt,Qe=>{let At=parseInt(Qe.currentTarget.value)||0;At<0&&(At=0),t.onSetStartingItem&&t.onSetStartingItem(ke(),At)}),S("click",On,()=>{t.onRemoveStartingItem&&t.onRemoveStartingItem(ke())}),O(Ue,Vt)});var Z=d(re,2);{var ce=Ue=>{var Te=Jf();O(Ue,Te)},ee=W(()=>Object.keys(a()).length===0);ie(Z,Ue=>{r(ee)&&Ue(ce)})}var De=d(Z,2),je=f(De);Ee(je);var Re=d(je,2);Ee(Re);var ze=d(Re,2);l(De),l(P);var Xe=d(P,2);In(je,()=>r(c),Ue=>y(c,Ue)),In(Re,()=>r(p),Ue=>y(p,Ue)),S("click",ze,F),S("click",Xe,()=>{Wn(()=>({...a()}))}),O(ae,G)};ie(oe,ae=>{r(g)&&ae(ne)})}l(_e),l(C),l(T),H(()=>M(Se,r(g)?"▼":"▶")),In(Q,()=>r(o),ae=>y(o,ae)),In(ye,()=>r(u),ae=>y(u,ae)),S("click",Ne,I),S("click",Ce,()=>y(g,!r(g))),O(e,T),qr(),s()}Zr(["input","click"]);class Yo{constructor(...t){this.type="Logical",t.length===1?"Logical"in t[0]?(this.width=t[0].Logical.width,this.height=t[0].Logical.height):(this.width=t[0].width,this.height=t[0].height):(this.width=t[0],this.height=t[1])}toPhysical(t){return new _i(this.width*t,this.height*t)}[xn](){return{width:this.width,height:this.height}}toJSON(){return this[xn]()}}class _i{constructor(...t){this.type="Physical",t.length===1?"Physical"in t[0]?(this.width=t[0].Physical.width,this.height=t[0].Physical.height):(this.width=t[0].width,this.height=t[0].height):(this.width=t[0],this.height=t[1])}toLogical(t){return new Yo(this.width/t,this.height/t)}[xn](){return{width:this.width,height:this.height}}toJSON(){return this[xn]()}}class Mr{constructor(t){this.size=t}toLogical(t){return this.size instanceof Yo?this.size:this.size.toLogical(t)}toPhysical(t){return this.size instanceof _i?this.size:this.size.toPhysical(t)}[xn](){return{[`${this.size.type}`]:{width:this.size.width,height:this.size.height}}}toJSON(){return this[xn]()}}class Bo{constructor(...t){this.type="Logical",t.length===1?"Logical"in t[0]?(this.x=t[0].Logical.x,this.y=t[0].Logical.y):(this.x=t[0].x,this.y=t[0].y):(this.x=t[0],this.y=t[1])}toPhysical(t){return new nr(this.x*t,this.y*t)}[xn](){return{x:this.x,y:this.y}}toJSON(){return this[xn]()}}class nr{constructor(...t){this.type="Physical",t.length===1?"Physical"in t[0]?(this.x=t[0].Physical.x,this.y=t[0].Physical.y):(this.x=t[0].x,this.y=t[0].y):(this.x=t[0],this.y=t[1])}toLogical(t){return new Bo(this.x/t,this.y/t)}[xn](){return{x:this.x,y:this.y}}toJSON(){return this[xn]()}}class Ui{constructor(t){this.position=t}toLogical(t){return this.position instanceof Bo?this.position:this.position.toLogical(t)}toPhysical(t){return this.position instanceof nr?this.position:this.position.toPhysical(t)}[xn](){return{[`${this.position.type}`]:{x:this.position.x,y:this.position.y}}}toJSON(){return this[xn]()}}var ln;(function(e){e.WINDOW_RESIZED="tauri://resize",e.WINDOW_MOVED="tauri://move",e.WINDOW_CLOSE_REQUESTED="tauri://close-requested",e.WINDOW_DESTROYED="tauri://destroyed",e.WINDOW_FOCUS="tauri://focus",e.WINDOW_BLUR="tauri://blur",e.WINDOW_SCALE_FACTOR_CHANGED="tauri://scale-change",e.WINDOW_THEME_CHANGED="tauri://theme-changed",e.WINDOW_CREATED="tauri://window-created",e.WEBVIEW_CREATED="tauri://webview-created",e.DRAG_ENTER="tauri://drag-enter",e.DRAG_OVER="tauri://drag-over",e.DRAG_DROP="tauri://drag-drop",e.DRAG_LEAVE="tauri://drag-leave"})(ln||(ln={}));async function Jo(e,t){window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e,t),await z("plugin:event|unlisten",{event:e,eventId:t})}async function qo(e,t,n){var i;const s=typeof(n==null?void 0:n.target)=="string"?{kind:"AnyLabel",label:n.target}:(i=n==null?void 0:n.target)!==null&&i!==void 0?i:{kind:"Any"};return z("plugin:event|listen",{event:e,target:s,handler:qc(t)}).then(a=>async()=>Jo(e,a))}async function Xf(e,t,n){return qo(e,i=>{Jo(e,i.id),t(i)},n)}async function Qf(e,t){await z("plugin:event|emit",{event:e,payload:t})}async function $f(e,t,n){await z("plugin:event|emit_to",{target:typeof e=="string"?{kind:"AnyLabel",label:e}:e,event:t,payload:n})}class wi extends Zc{constructor(t){super(t)}static async new(t,n,i){return z("plugin:image|new",{rgba:sa(t),width:n,height:i}).then(s=>new wi(s))}static async fromBytes(t){return z("plugin:image|from_bytes",{bytes:sa(t)}).then(n=>new wi(n))}static async fromPath(t){return z("plugin:image|from_path",{path:t}).then(n=>new wi(n))}async rgba(){return z("plugin:image|rgba",{rid:this.rid}).then(t=>new Uint8Array(t))}async size(){return z("plugin:image|size",{rid:this.rid})}}function sa(e){return e==null?null:typeof e=="string"?e:e instanceof wi?e.rid:e}var Xa;(function(e){e[e.Critical=1]="Critical",e[e.Informational=2]="Informational"})(Xa||(Xa={}));class ev{constructor(t){this._preventDefault=!1,this.event=t.event,this.id=t.id}preventDefault(){this._preventDefault=!0}isPreventDefault(){return this._preventDefault}}var to;(function(e){e.None="none",e.Normal="normal",e.Indeterminate="indeterminate",e.Paused="paused",e.Error="error"})(to||(to={}));function Zo(){return new Ko(window.__TAURI_INTERNALS__.metadata.currentWindow.label,{skip:!0})}async function Ra(){return z("plugin:window|get_all_windows").then(e=>e.map(t=>new Ko(t,{skip:!0})))}const La=["tauri://created","tauri://error"];class Ko{constructor(t,n={}){var i;this.label=t,this.listeners=Object.create(null),n!=null&&n.skip||z("plugin:window|create",{options:{...n,parent:typeof n.parent=="string"?n.parent:(i=n.parent)===null||i===void 0?void 0:i.label,label:t}}).then(async()=>this.emit("tauri://created")).catch(async s=>this.emit("tauri://error",s))}static async getByLabel(t){var n;return(n=(await Ra()).find(i=>i.label===t))!==null&&n!==void 0?n:null}static getCurrent(){return Zo()}static async getAll(){return Ra()}static async getFocusedWindow(){for(const t of await Ra())if(await t.isFocused())return t;return null}async listen(t,n){return this._handleTauriEvent(t,n)?()=>{const i=this.listeners[t];i.splice(i.indexOf(n),1)}:qo(t,n,{target:{kind:"Window",label:this.label}})}async once(t,n){return this._handleTauriEvent(t,n)?()=>{const i=this.listeners[t];i.splice(i.indexOf(n),1)}:Xf(t,n,{target:{kind:"Window",label:this.label}})}async emit(t,n){if(La.includes(t)){for(const i of this.listeners[t]||[])i({event:t,id:-1,payload:n});return}return Qf(t,n)}async emitTo(t,n,i){if(La.includes(n)){for(const s of this.listeners[n]||[])s({event:n,id:-1,payload:i});return}return $f(t,n,i)}_handleTauriEvent(t,n){return La.includes(t)?(t in this.listeners?this.listeners[t].push(n):this.listeners[t]=[n],!0):!1}async scaleFactor(){return z("plugin:window|scale_factor",{label:this.label})}async innerPosition(){return z("plugin:window|inner_position",{label:this.label}).then(t=>new nr(t))}async outerPosition(){return z("plugin:window|outer_position",{label:this.label}).then(t=>new nr(t))}async innerSize(){return z("plugin:window|inner_size",{label:this.label}).then(t=>new _i(t))}async outerSize(){return z("plugin:window|outer_size",{label:this.label}).then(t=>new _i(t))}async isFullscreen(){return z("plugin:window|is_fullscreen",{label:this.label})}async isMinimized(){return z("plugin:window|is_minimized",{label:this.label})}async isMaximized(){return z("plugin:window|is_maximized",{label:this.label})}async isFocused(){return z("plugin:window|is_focused",{label:this.label})}async isDecorated(){return z("plugin:window|is_decorated",{label:this.label})}async isResizable(){return z("plugin:window|is_resizable",{label:this.label})}async isMaximizable(){return z("plugin:window|is_maximizable",{label:this.label})}async isMinimizable(){return z("plugin:window|is_minimizable",{label:this.label})}async isClosable(){return z("plugin:window|is_closable",{label:this.label})}async isVisible(){return z("plugin:window|is_visible",{label:this.label})}async title(){return z("plugin:window|title",{label:this.label})}async theme(){return z("plugin:window|theme",{label:this.label})}async isAlwaysOnTop(){return z("plugin:window|is_always_on_top",{label:this.label})}async center(){return z("plugin:window|center",{label:this.label})}async requestUserAttention(t){let n=null;return t&&(t===Xa.Critical?n={type:"Critical"}:n={type:"Informational"}),z("plugin:window|request_user_attention",{label:this.label,value:n})}async setResizable(t){return z("plugin:window|set_resizable",{label:this.label,value:t})}async setEnabled(t){return z("plugin:window|set_enabled",{label:this.label,value:t})}async isEnabled(){return z("plugin:window|is_enabled",{label:this.label})}async setMaximizable(t){return z("plugin:window|set_maximizable",{label:this.label,value:t})}async setMinimizable(t){return z("plugin:window|set_minimizable",{label:this.label,value:t})}async setClosable(t){return z("plugin:window|set_closable",{label:this.label,value:t})}async setTitle(t){return z("plugin:window|set_title",{label:this.label,value:t})}async maximize(){return z("plugin:window|maximize",{label:this.label})}async unmaximize(){return z("plugin:window|unmaximize",{label:this.label})}async toggleMaximize(){return z("plugin:window|toggle_maximize",{label:this.label})}async minimize(){return z("plugin:window|minimize",{label:this.label})}async unminimize(){return z("plugin:window|unminimize",{label:this.label})}async show(){return z("plugin:window|show",{label:this.label})}async hide(){return z("plugin:window|hide",{label:this.label})}async close(){return z("plugin:window|close",{label:this.label})}async destroy(){return z("plugin:window|destroy",{label:this.label})}async setDecorations(t){return z("plugin:window|set_decorations",{label:this.label,value:t})}async setShadow(t){return z("plugin:window|set_shadow",{label:this.label,value:t})}async setEffects(t){return z("plugin:window|set_effects",{label:this.label,value:t})}async clearEffects(){return z("plugin:window|set_effects",{label:this.label,value:null})}async setAlwaysOnTop(t){return z("plugin:window|set_always_on_top",{label:this.label,value:t})}async setAlwaysOnBottom(t){return z("plugin:window|set_always_on_bottom",{label:this.label,value:t})}async setContentProtected(t){return z("plugin:window|set_content_protected",{label:this.label,value:t})}async setSize(t){return z("plugin:window|set_size",{label:this.label,value:t instanceof Mr?t:new Mr(t)})}async setMinSize(t){return z("plugin:window|set_min_size",{label:this.label,value:t instanceof Mr?t:t?new Mr(t):null})}async setMaxSize(t){return z("plugin:window|set_max_size",{label:this.label,value:t instanceof Mr?t:t?new Mr(t):null})}async setSizeConstraints(t){function n(i){return i?{Logical:i}:null}return z("plugin:window|set_size_constraints",{label:this.label,value:{minWidth:n(t==null?void 0:t.minWidth),minHeight:n(t==null?void 0:t.minHeight),maxWidth:n(t==null?void 0:t.maxWidth),maxHeight:n(t==null?void 0:t.maxHeight)}})}async setPosition(t){return z("plugin:window|set_position",{label:this.label,value:t instanceof Ui?t:new Ui(t)})}async setFullscreen(t){return z("plugin:window|set_fullscreen",{label:this.label,value:t})}async setSimpleFullscreen(t){return z("plugin:window|set_simple_fullscreen",{label:this.label,value:t})}async setFocus(){return z("plugin:window|set_focus",{label:this.label})}async setFocusable(t){return z("plugin:window|set_focusable",{label:this.label,value:t})}async setIcon(t){return z("plugin:window|set_icon",{label:this.label,value:sa(t)})}async setSkipTaskbar(t){return z("plugin:window|set_skip_taskbar",{label:this.label,value:t})}async setCursorGrab(t){return z("plugin:window|set_cursor_grab",{label:this.label,value:t})}async setCursorVisible(t){return z("plugin:window|set_cursor_visible",{label:this.label,value:t})}async setCursorIcon(t){return z("plugin:window|set_cursor_icon",{label:this.label,value:t})}async setBackgroundColor(t){return z("plugin:window|set_background_color",{color:t})}async setCursorPosition(t){return z("plugin:window|set_cursor_position",{label:this.label,value:t instanceof Ui?t:new Ui(t)})}async setIgnoreCursorEvents(t){return z("plugin:window|set_ignore_cursor_events",{label:this.label,value:t})}async startDragging(){return z("plugin:window|start_dragging",{label:this.label})}async startResizeDragging(t){return z("plugin:window|start_resize_dragging",{label:this.label,value:t})}async setBadgeCount(t){return z("plugin:window|set_badge_count",{label:this.label,value:t})}async setBadgeLabel(t){return z("plugin:window|set_badge_label",{label:this.label,value:t})}async setOverlayIcon(t){return z("plugin:window|set_overlay_icon",{label:this.label,value:t?sa(t):void 0})}async setProgressBar(t){return z("plugin:window|set_progress_bar",{label:this.label,value:t})}async setVisibleOnAllWorkspaces(t){return z("plugin:window|set_visible_on_all_workspaces",{label:this.label,value:t})}async setTitleBarStyle(t){return z("plugin:window|set_title_bar_style",{label:this.label,value:t})}async setTheme(t){return z("plugin:window|set_theme",{label:this.label,value:t})}async onResized(t){return this.listen(ln.WINDOW_RESIZED,n=>{n.payload=new _i(n.payload),t(n)})}async onMoved(t){return this.listen(ln.WINDOW_MOVED,n=>{n.payload=new nr(n.payload),t(n)})}async onCloseRequested(t){return this.listen(ln.WINDOW_CLOSE_REQUESTED,async n=>{const i=new ev(n);await t(i),i.isPreventDefault()||await this.destroy()})}async onDragDropEvent(t){const n=await this.listen(ln.DRAG_ENTER,o=>{t({...o,payload:{type:"enter",paths:o.payload.paths,position:new nr(o.payload.position)}})}),i=await this.listen(ln.DRAG_OVER,o=>{t({...o,payload:{type:"over",position:new nr(o.payload.position)}})}),s=await this.listen(ln.DRAG_DROP,o=>{t({...o,payload:{type:"drop",paths:o.payload.paths,position:new nr(o.payload.position)}})}),a=await this.listen(ln.DRAG_LEAVE,o=>{t({...o,payload:{type:"leave"}})});return()=>{n(),s(),i(),a()}}async onFocusChanged(t){const n=await this.listen(ln.WINDOW_FOCUS,s=>{t({...s,payload:!0})}),i=await this.listen(ln.WINDOW_BLUR,s=>{t({...s,payload:!1})});return()=>{n(),i()}}async onScaleChanged(t){return this.listen(ln.WINDOW_SCALE_FACTOR_CHANGED,t)}async onThemeChanged(t){return this.listen(ln.WINDOW_THEME_CHANGED,t)}}var no;(function(e){e.Disabled="disabled",e.Throttle="throttle",e.Suspend="suspend"})(no||(no={}));var ro;(function(e){e.Default="default",e.FluentOverlay="fluentOverlay"})(ro||(ro={}));var io;(function(e){e.AppearanceBased="appearanceBased",e.Light="light",e.Dark="dark",e.MediumLight="mediumLight",e.UltraDark="ultraDark",e.Titlebar="titlebar",e.Selection="selection",e.Menu="menu",e.Popover="popover",e.Sidebar="sidebar",e.HeaderView="headerView",e.Sheet="sheet",e.WindowBackground="windowBackground",e.HudWindow="hudWindow",e.FullScreenUI="fullScreenUI",e.Tooltip="tooltip",e.ContentBackground="contentBackground",e.UnderWindowBackground="underWindowBackground",e.UnderPageBackground="underPageBackground",e.Mica="mica",e.Blur="blur",e.Acrylic="acrylic",e.Tabbed="tabbed",e.TabbedDark="tabbedDark",e.TabbedLight="tabbedLight"})(io||(io={}));var ao;(function(e){e.FollowsWindowActiveState="followsWindowActiveState",e.Active="active",e.Inactive="inactive"})(ao||(ao={}));var tv=N('<div class="text-sm text-zinc-500">Буфер пуст. Используйте кнопку 📥 в карточках ответов, чтобы копировать.</div>'),nv=N('<div class="text-[10px] text-emerald-400 mt-0.5 truncate"> </div>'),rv=N('<div class="bg-zinc-800 border border-zinc-700 rounded-2xl p-3 text-sm relative group"><div class="flex justify-between gap-2"><div class="min-w-0 flex-1"><div class="font-medium truncate"> </div> <!></div> <button class="text-red-400 hover:text-red-500 text-lg leading-none opacity-60 group-hover:opacity-100 transition shrink-0">✕</button></div> <div class="mt-2 flex items-center gap-1"><span class="drag-handle px-1 text-zinc-500 hover:text-zinc-300 cursor-grab active:cursor-grabbing select-none text-xs" title="Визуальная ручка (DnD отключён)">||</span> <button class="text-[10px] bg-emerald-700 hover:bg-emerald-600 px-2 py-0.5 rounded transition">Вставить</button></div></div>'),iv=N('<div class="grid grid-cols-2 md:grid-cols-4 gap-3 max-h-52 overflow-auto pr-1"></div>'),av=N('<div class="border-t border-zinc-700 bg-zinc-900 p-4"><div class="flex justify-between items-center mb-3"><div class="font-medium"> </div> <button class="text-red-400 hover:text-red-500 px-3 py-1 rounded hover:bg-zinc-800 transition">✕ Закрыть</button></div> <!></div>'),sv=N('<div class="flex h-screen bg-zinc-950 text-[#f5e6c4] font-serif overflow-hidden"><!> <div class="flex-1 flex flex-col"><div class="flex border-b border-zinc-800 bg-zinc-900"><button>📝 Редактор</button> <button>👤 Персонаж</button> <button>🎒 Инвентарь</button> <button>▶ Просмотр</button></div> <div class="flex-1 overflow-y-auto bg-zinc-950 px-6"><!></div> <!> <div class="border-t border-[#8b4513] p-6 flex gap-4 bg-[#2a1f17]"><button class="flex-1 bg-[#8b4513] hover:bg-[#a0522d] py-4 rounded-2xl font-medium text-lg transition shadow-lg">💾 Сохранить .story</button> <button class="flex-1 bg-emerald-600 hover:bg-emerald-500 py-4 rounded-2xl font-medium text-lg transition shadow-lg">📤 Экспорт чистой версии</button> <button class="flex-1 bg-[#3a2a1f] hover:bg-[#4a3a2f] py-4 rounded-2xl font-medium text-lg transition">📂 Загрузить .story</button> <button class="flex-1 bg-rose-700 hover:bg-rose-600 py-4 rounded-2xl font-medium text-lg transition shadow-lg flex items-center justify-center gap-2">♻ Сбросить черновик</button> <button class="flex-1 bg-amber-600 hover:bg-amber-500 py-4 rounded-2xl font-medium text-lg transition shadow-lg">⏪ Восстановить из бэкапа</button> <button class="flex-1 bg-zinc-700 hover:bg-zinc-600 py-4 rounded-2xl font-medium text-lg transition shadow-lg flex items-center justify-center gap-2" title="Ручной сброс глобального состояния к начальным значениям (как при переходе в редактор из превью).">🔄 Сбросить глобал</button> <button class="bg-zinc-700 hover:bg-zinc-600 px-4 py-4 rounded-2xl font-medium text-sm transition shadow-lg flex items-center justify-center gap-2 min-w-[120px]" title="Открыть панель буфера скопированных ответов"> </button> <button class="bg-rose-700 hover:bg-rose-600 px-4 py-4 rounded-2xl font-medium text-sm transition shadow-lg flex items-center justify-center gap-2 min-w-[140px]" title="Очистить текущее сохранение состояния редактора (вкладка, сцена, свёртки, буфер)">🗑 Очистить сохранение</button></div></div></div>');function vv(e,t){var j;Jr(t,!0);const n=()=>bn(st,"$storyStore",a),i=()=>bn(Pt,"$currentSceneId",a),s=()=>bn(hi,"$answerBufferStore",a),[a,o]=Kr();let u=fe("editor"),c=fe(!1);try{const m=Cc();m.tab&&["editor","character","inventory","preview"].includes(m.tab)&&y(u,m.tab,!0),m.currentSceneId&&Pt.set(m.currentSceneId)}catch{}let p=fe(Mt(n().startScene)),g=fe(Mt({...n().variables})),I=fe(Mt({...n().items||{}})),b=fe(Mt({})),h=fe(""),E=fe(null),F=fe(null),T=fe(null),C=fe(null),V=fe(""),Y=fe(0),Q=fe(null),ye=W(()=>n().scenes.find(m=>m.id===i())??null),Ne=fe(""),_e=W(()=>r(u)==="preview"&&r(p)===i());function Ce(){try{Ac({tab:r(u),currentSceneId:i()})}catch{}}pn(()=>{Ce()}),window.addEventListener("beforeunload",Ce),(async()=>{try{const m=Zo();await m.onCloseRequested(async D=>{D.preventDefault();try{Ce(),wc()}catch{}try{await m.destroy()}catch{try{await m.close()}catch{}}})}catch{}})();function Ve(m){if(!i())return;const D=JSON.parse(JSON.stringify(m));D.id=`${i()}-c${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,D.npcLineIndex=0,Oc(i(),D)}function Se(){var m;try{localStorage.removeItem("kniga-engine-editor-ui"),localStorage.removeItem("kniga-engine-collapses"),localStorage.removeItem("kniga-engine-answer-buffer"),hi.set([]),Si.set(new Map),Ii.set(new Set),y(u,"editor");const D=n().startScene||(((m=n().scenes[0])==null?void 0:m.id)??"scene1");Pt.set(D),y(c,!1)}catch{}}function oe(m,D){const q={...m};for(const[X,we]of Object.entries(D||{}))X in m||(q[X]=we);return q}function ne(){var we;if(y(G,{},!0),y(P,{},!0),Object.keys(r(ce)).length>0)y(G,{...r(ce)},!0),y(P,{...r(ee)},!0);else{const ve=Er(st);y(G,{...ve.variables||{}},!0),y(P,{...ve.items||{}},!0)}Object.keys(r(G)).length>0||Object.keys(r(P)).length>0?(ir(()=>({...r(G)})),Wn(()=>({...r(P)}))):Yc();const m=Er(st),D=m.variables||{},q=m.items||{};Object.keys(D).length===0&&Object.keys(q).length===0&&(Object.keys(r(G)).length>0||Object.keys(r(P)).length>0)&&(ir(()=>({...r(G)})),Wn(()=>({...r(P)})));const X=n().startScene||(((we=n().scenes[0])==null?void 0:we.id)??"");X&&st.update(ve=>{const $e={...ve.variableOrigins||{}};Object.keys(r(G)||{}).forEach(ge=>{$e[ge]=X});const Wt={...ve.itemOrigins||{}};return Object.keys(r(P)||{}).forEach(ge=>{Wt[ge]=X}),{...ve,variableOrigins:$e,itemOrigins:Wt}})}function ae(){Object.keys(r(G)).length>0&&(ir(()=>oe(r(G),r(g))),Wn(()=>oe(r(P),r(I))))}pn(()=>{if(r(p)&&r(p)!==r(Ne)){y(V,""),y(Y,0),y(Ne,r(p),!0);const m=n().scenes.find(D=>D.id===r(p));if(m!=null&&m.isDialogue&&m.text){const D=fi(m,0);y(V,Pr(D,m.text),!0)}}}),pn(()=>{if(r(u)==="preview"&&r(p)&&r(p)!=="end"){const m={variables:{...r(g)},items:{...r(I)}};r(b)[r(p)]=m}});let G=fe(Mt({})),P=fe(Mt({}));function re(m){var ve,$e,Wt;const D=m.startScene||((($e=(ve=m.scenes)==null?void 0:ve[0])==null?void 0:$e.id)??""),q=((Wt=m.scenes)==null?void 0:Wt.findIndex(ge=>ge.id===D))??-1,X={};Object.entries(m.variables||{}).forEach(([ge,pt])=>{var nt,lt;const bt=(nt=m.variableOrigins)==null?void 0:nt[ge];if(!bt)X[ge]=pt;else{const en=((lt=m.scenes)==null?void 0:lt.findIndex(Jt=>Jt.id===bt))??-1;en>=0&&en<=q&&(X[ge]=pt)}});const we={};return Object.entries(m.items||{}).forEach(([ge,pt])=>{var nt,lt;const bt=(nt=m.itemOrigins)==null?void 0:nt[ge];if(!bt)we[ge]=pt;else{const en=((lt=m.scenes)==null?void 0:lt.findIndex(Jt=>Jt.id===bt))??-1;en>=0&&en<=q&&(we[ge]=pt)}}),{variables:X,items:we}}const Z=re(n());let ce=fe(Mt({...Z.variables})),ee=fe(Mt({...Z.items}));const De=n().startScene||(((j=n().scenes[0])==null?void 0:j.id)??"");De&&st.update(m=>{const D={...m.variableOrigins||{}};Object.keys(Z.variables).forEach(X=>{X in Z.variables&&(D[X]=De)});const q={...m.itemOrigins||{}};return Object.keys(Z.items).forEach(X=>{X in Z.items&&(q[X]=De)}),{...m,variableOrigins:D,itemOrigins:q}});function je(m,D){y(ce,{...r(ce),[m]:D},!0)}function Re(m,D){const q=D.trim();if(!q||q===m||!(m in r(ce)))return;const X=r(ce)[m],we={...r(ce)};delete we[m],we[q]=X,y(ce,we,!0)}function ze(m){const D={...r(ce)};delete D[m],y(ce,D,!0)}function Xe(m,D){y(ce,{...r(ce),[m]:D},!0)}function Ue(m,D){y(ee,{...r(ee),[m]:D},!0)}function Te(m,D){const q=D.trim();if(!q||q===m||!(m in r(ee)))return;const X=r(ee)[m],we={...r(ee)};delete we[m],we[q]=X,y(ee,we,!0)}function he(m){const D={...r(ee)};delete D[m],y(ee,D,!0)}function ke(m,D){y(ee,{...r(ee),[m]:D},!0)}let gt=fe("editor"),mt=fe(!1);function yn(){const m=`scene${Date.now()}`;Sc({id:m,text:"Новая сцена...",choices:[]}),Pt.set(m)}function Vt(m){const D=`scene${Date.now()}`;Ic(m,{id:D,text:"Новая сцена...",choices:[]}),Pt.set(D)}function yt(m){Dc(m)}function kt(m){Ec(m)}function jt(m){Tc(m)}function Tn(m){r(u)==="editor"&&m&&(r(b)[m]?y(b,{[m]:r(b)[m]},!0):y(b,{},!0)),Pt.set(m)}function On(){y(mt,!1),y(Q,null),ne();const m=r(h)||n().startScene;y(p,m,!0),y(g,Object.keys(r(G)).length>0?{...r(G)}:{...n().variables},!0),y(I,Object.keys(r(P)).length>0?{...r(P)}:{...n().items||{}},!0),y(b,{},!0),y(V,""),y(Y,0),y(Ne,r(p),!0);const D=n().scenes.find(q=>q.id===r(p));if(D!=null&&D.isDialogue&&D.text&&r(V)===""){const q=fi(D,0);y(V,Pr(q,D.text),!0)}r(b)[r(p)]={variables:{...r(g)},items:{...r(I)}}}async function Qe(){const m=await Ca({filters:[{name:"История",extensions:["story"]}]});m&&(await Aa(m,JSON.stringify(n(),null,2)),alert("✅ История сохранена!"))}async function At(){var $e,Wt;const m=await Xc({filters:[{name:"История",extensions:["story"]}]});if(!m||typeof m!="string")return;const D=await Kc(m),q=JSON.parse(D),X=Ir(q);st.set(X),Pt.set(X.startScene),y(p,X.startScene,!0);const we=re(X);y(ce,{...we.variables},!0),y(ee,{...we.items},!0);const ve=X.startScene||(((Wt=($e=X.scenes)==null?void 0:$e[0])==null?void 0:Wt.id)??"");ve&&st.update(ge=>{const pt={...ge.variableOrigins||{}};Object.keys(we.variables).forEach(nt=>{pt[nt]=ve});const bt={...ge.itemOrigins||{}};return Object.keys(we.items).forEach(nt=>{bt[nt]=ve}),{...ge,variableOrigins:pt,itemOrigins:bt}})}async function lr(m){var en,Jt,kn,Qn;const D=r(p),q={variables:{...r(g)},items:{...r(I)}},X={variables:{...r(g)},items:{...n().items||{}}};let we=m.effects,ve=m.next||"",$e,Wt="";if(m.roll){const Me=pc(m,r(g),r(Q));we=Me.effects,ve=Me.nextId,$e=Me.rollValue,Me.tier!=null&&(Wt=` (${Me.tier}%)`)}const ge=n().scenes.find(Me=>Me.id===r(p)),pt=!!(ge!=null&&ge.isDialogue);if(pt&&!ve&&(ve=r(p)),ve==="end"||!ve?(y(E,D,!0),y(F,q,!0)):ve&&ve!==D&&(y(E,D,!0),y(F,q,!0)),pt){const Me=fi(ge,r(Y)),_n=r(Y)===0?(ge==null?void 0:ge.text)||"":((Jt=(en=ge==null?void 0:ge.npcResponses)==null?void 0:en[r(Y)-1])==null?void 0:Jt.text)||"",An=`${Pr(Me,_n)}

${Pr(void 0,m.text,!0)}`;y(V,(r(V)?r(V)+`

`:"")+An);const ti=zs(we,{variables:{...r(g)},items:{...n().items||{}}}),Tr=m.npcLineIndex||0;y(Y,bc(Tr,ge==null?void 0:ge.npcResponses,ti),!0);const Bn=fi(ge,r(Y)),Or=r(Y)===0?"":((Qn=(kn=ge==null?void 0:ge.npcResponses)==null?void 0:kn[r(Y)-1])==null?void 0:Qn.text)||"";Or&&y(V,r(V)+`

${Pr(Bn,Or)}`)}else y(V,""),y(Y,0);const nt=zs(we,X),lt=ve&&ve!=="end"&&n().scenes.some(Me=>Me.id===ve)?ve:null;if(lt){{const Me={};for(const[_n,An]of Object.entries(nt.items))_n in r(P)||(Me[_n]=An);Object.keys(Me).length>0&&wo(Me,lt)}y(g,{...nt.variables},!0);{const Me={};for(const[_n,An]of Object.entries(r(g)))_n in r(G)||(Me[_n]=An);Object.keys(Me).length>0&&So(Me,lt)}y(I,{...nt.items},!0)}else y(g,{...nt.variables},!0),y(I,{...nt.items},!0);lt&&lt!=="end"&&(r(b)[lt]={variables:{...r(g)},items:{...r(I)}}),m.roll&&$e!==void 0&&alert(`🎲 Бросок: ${m.roll} → ${$e}${Wt}`),ve==="end"||!ve?(y(p,"end"),y(V,"")):ve!==r(p)&&n().scenes.some(Me=>Me.id===ve)&&y(p,ve,!0)}function cr(){if(r(E)&&r(F)){y(p,r(E),!0),y(g,{...r(F).variables},!0),y(I,{...r(F).items},!0),y(V,""),y(Y,0);const m=n().scenes.find(D=>D.id===r(p));if(m!=null&&m.isDialogue&&m.text){const D=fi(m,0);y(V,Pr(D,m.text),!0)}y(E,null),y(F,null)}}function Qr(m){y(p,m,!0),m!=="end"&&(y(E,null),y(F,null),y(T,null),y(C,null)),y(Ne,"")}pn(()=>{r(gt)==="preview"&&r(u)!=="preview"&&(r(u)==="editor"?(r(mt)?(ae(),y(mt,!1)):(ne(),y(mt,!1)),y(V,""),y(Y,0)):Object.keys(r(G)).length>0&&(ae(),r(p)&&r(p)!=="end"&&Pt.set(r(p)))),y(gt,r(u),!0)}),pn(()=>{r(u)==="preview"&&Object.keys(r(G)).length===0&&(y(G,{...n().variables},!0),y(P,{...n().items||{}},!0),r(h)||y(h,i()||n().startScene,!0))});async function $r(){if(Object.keys(r(G)).length===0){await Qe();return}const m={...n(),variables:{...r(G)},items:{...r(P)}},D=await Ca({filters:[{name:"История",extensions:["story"]}]});D&&(await Aa(D,JSON.stringify(m,null,2)),alert("📤 Чистая история успешно экспортирована!"))}function Kn(){var D;if(y(mt,!1),y(Q,null),Object.keys(r(ce)).length>0&&r(u)==="preview"){ir(()=>({...r(ce)})),Wn(()=>({...r(ee)}));const q=n().startScene||(((D=n().scenes[0])==null?void 0:D.id)??"");q&&st.update(X=>{const we={...X.variableOrigins||{}};Object.keys(r(ce)||{}).forEach($e=>{we[$e]=q});const ve={...X.itemOrigins||{}};return Object.keys(r(ee)||{}).forEach($e=>{ve[$e]=q}),{...X,variableOrigins:we,itemOrigins:ve}})}y(G,{...n().variables},!0),y(P,{...n().items||{}},!0),y(u,"preview");const m=i()||n().startScene;y(h,m,!0),y(p,m,!0),y(g,{...n().variables},!0),y(I,{...n().items||{}},!0),y(b,{},!0),r(b)[m]={variables:{...r(g)},items:{...r(I)}}}function ur(){if(r(u)==="editor"||r(gt)==="editor"){Kn();return}r(p)&&Object.keys(r(G)).length>0?y(u,"preview"):Kn()}function Hn(){r(p)&&Pt.set(r(p)),y(mt,!0),y(u,"editor")}async function Je(){let m=(n().title||"Интерактивная_история").trim().replace(/[^a-zA-Z0-9а-яА-ЯёЁ\s\-_]/g,"").replace(/\s+/g,"_").replace(/_+/g,"_").replace(/^_|_$/g,"");m||(m="Интерактивная_история");const D=`${m}.html`,q=await Ca({filters:[{name:"HTML Игра",extensions:["html"]}],defaultPath:D});if(!q)return;let X=n();const we=Object.keys(r(ce)).length>0?r(ce):r(G),ve=Object.keys(r(ee)).length>0?r(ee):r(P);Object.keys(we).length>0&&(X={...n(),variables:{...we},items:{...ve}});const $e=ic(X);await Aa(q,$e),alert(`✅ Игра успешно экспортирована в HTML!

Файл сохранён как:
${D}`)}var Un=sv(),Nn=f(Un);gd(Nn,{addScene:yn,selectScene:Tn,exportToHtmlGame:Je,addSceneAfter:Vt,deleteScene:yt,restoreDeletedScene:kt,permanentlyDeleteDeletedScene:jt});var ot=d(Nn,2),un=f(ot),Gn=f(un),Xn=d(Gn,2),dr=d(Xn,2),fr=d(dr,2);l(un);var Yn=d(un,2),ei=f(Yn);{var k=m=>{yd(m,{get startingVariables(){return r(ce)},onSetStartingVariable:je,onRenameStartingVariable:Re,onRemoveStartingVariable:ze,onAddStartingVariable:Xe})},R=m=>{Kf(m,{get startingItems(){return r(ee)},onSetStartingItem:Ue,onRenameStartingItem:Te,onRemoveStartingItem:he,onAddStartingItem:ke})},B=m=>{{let D=W(()=>r(_e)?r(g):void 0),q=W(()=>r(_e)?r(I):void 0);mf(m,{get selectedScene(){return r(ye)},get liveVariables(){return r(D)},get liveItems(){return r(q)},get sceneStates(){return r(b)}})}},te=m=>{Gf(m,{get previewSceneId(){return r(p)},get previewVars(){return r(g)},get previewItems(){return r(I)},makeChoice:lr,onRestart:On,onEditCurrent:Hn,get dialogueHistory(){return r(V)},get currentDialogueStep(){return r(Y)},onPreviewVarsChange:D=>y(g,D,!0),onPreviewItemsChange:D=>y(I,D,!0),onDialogueHistoryChange:D=>y(V,D,!0),onCurrentDialogueStepChange:D=>y(Y,D,!0),get previousSceneId(){return r(E)},onReturnToPreviousScene:cr,get forcedRollTier(){return r(Q)},onForcedRollTierChange:D=>y(Q,D,!0),get startingVariables(){return r(ce)},get startingItems(){return r(ee)},get sceneStates(){return r(b)},onSceneStatesChange:D=>{y(b,D,!0)},onPreviewSceneIdChange:Qr})};ie(ei,m=>{r(u)==="character"?m(k):r(u)==="inventory"?m(R,1):r(u)==="editor"?m(B,2):r(u)==="preview"&&m(te,3)})}l(Yn);var pe=d(Yn,2);{var de=m=>{var D=av(),q=f(D),X=f(q),we=f(X);l(X);var ve=d(X,2);l(q);var $e=d(q,2);{var Wt=pt=>{var bt=tv();O(pt,bt)},ge=pt=>{var bt=iv();xe(bt,7,s,nt=>nt.id,(nt,lt,en)=>{var Jt=rv(),kn=f(Jt),Qn=f(kn),Me=f(Qn),_n=f(Me,!0);l(Me);var An=d(Me,2);{var ti=vr=>{var Nr=nv(),kr=f(Nr);l(Nr),H(()=>M(kr,`🎲 ${r(lt).roll??""}`)),O(vr,Nr)};ie(An,vr=>{r(lt).roll&&vr(ti)})}l(Qn);var Tr=d(Qn,2);l(kn);var Bn=d(kn,2),Or=d(f(Bn),2);l(Bn),l(Jt),H(()=>M(_n,r(lt).text||"(пустой ответ)")),S("click",Tr,()=>hi.update(vr=>vr.filter((Nr,kr)=>kr!==r(en)))),S("click",Or,()=>Ve(r(lt))),O(nt,Jt)}),l(bt),O(pt,bt)};ie($e,pt=>{s().length===0?pt(Wt):pt(ge,!1)})}l(D),H(()=>M(we,`Буфер ответов (${s().length??""})`)),S("click",ve,()=>y(c,!1)),O(m,D)};ie(pe,m=>{r(c)&&m(de)})}var $=d(pe,2),ue=f($),be=d(ue,2),qe=d(be,2),Pe=d(qe,2),v=d(Pe,2),x=d(v,2),_=d(x,2),w=f(_);l(_);var U=d(_,2);l($),l(ot),l(Un),H(()=>{jn(Gn,1,`flex-1 py-4 text-sm font-medium transition ${r(u)==="editor"?"border-b-2 border-blue-500 text-white":"text-zinc-400 hover:text-zinc-200"}`),jn(Xn,1,`flex-1 py-4 text-sm font-medium transition ${r(u)==="character"?"border-b-2 border-blue-500 text-white":"text-zinc-400 hover:text-zinc-200"}`),jn(dr,1,`flex-1 py-4 text-sm font-medium transition ${r(u)==="inventory"?"border-b-2 border-blue-500 text-white":"text-zinc-400 hover:text-zinc-200"}`),jn(fr,1,`flex-1 py-4 text-sm font-medium transition ${r(u)==="preview"?"border-b-2 border-blue-500 text-white":"text-zinc-400 hover:text-zinc-200"}`),M(w,`📋 Буфер (${s().length??""})`)}),S("click",Gn,()=>y(u,"editor")),S("click",Xn,()=>y(u,"character")),S("click",dr,()=>y(u,"inventory")),S("click",fr,ur),S("click",ue,Qe),S("click",be,$r),S("click",qe,At),S("click",Pe,function(...m){Na==null||Na.apply(this,m)}),S("click",v,function(...m){ka==null||ka.apply(this,m)}),S("click",x,ne),S("click",_,()=>y(c,!r(c))),S("click",U,Se),O(e,Un),qr(),o()}Zr(["click"]);export{vv as component};
