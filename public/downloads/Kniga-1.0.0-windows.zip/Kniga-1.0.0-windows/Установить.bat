@echo off
cd /d "%~dp0"
Kniga.exe --install
echo.
echo Ярлык «Книга» на рабочем столе. Можно закрыть это окно.
pause
